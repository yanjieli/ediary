#!/bin/bash
#set -x

generic_check_all_logs ()
{
	TOTAL_LOGS=0
	LOGS_WITH_ERROR_COUNT=0
	NOK_LOGS=""
	echo "=============== BEGIN log inspection: `date`  ==============" > $LOGFILE
	echo "" >> $LOGFILE

	# for each directory in "LOG_FILE_LOCATIONS" from config file
	for log_dir in ${LOG_FILE_LOCATIONS}
	do
		if [ -d $log_dir ]; then
        		# for each file in the log_dir according to pattern
        		for log_file in `find $log_dir -type f -regex ${LOG_FILE_PATTERNS} | grep -vi "\.old$"` 
        		do
				# print file name
				echo "Checking log : $log_file " | tee -a $LOGFILE 
				TOTAL_LOGS=$((${TOTAL_LOGS}+1))
             
				# extract all the valid error from  log file 
				msg=`egrep -v "${SEARCH_EXCLUDES}" $log_file | egrep -i "${SEARCH_INCLUDES}"`

				# extract special oracle compilation errors that are printed on multiple lines
				compilation_err_msg=`awk '/^OBJECTS WITH ERRORS|^ERRORS DURING RECOMPILATION/,/[0-9]$/ {if($1 !~/^---/) printf $0; if($1 ~/[0-9]/) print "\n" }' $log_file | egrep -v " 0$|^$"`
			
				if [ -z "$msg"  -a -z "$compilation_err_msg" ]; then
					echo "OK, no errors found."   | tee -a $LOGFILE  
				else
					ERROR_STR_PRINT=`echo -e "${msg}" | sed -e 's%^[[:space:]]*%\\t%' `
                                        COMPILE_ERROR_PRINT=`echo -e "${compilation_err_msg}" | sed -e 's%^[[:space:]]*%\\t%' `
                                        echo "The following errors appear:" | tee -a $LOGFILE
                                        echo -e "${ERROR_STR_PRINT}" | tee -a $LOGFILE
                                        echo -e "${COMPILE_ERROR_PRINT}" | tee -a $LOGFILE
                                        echo ""	| tee -a $LOGFILE
					echo "NOK, please refer to detailed log: ${log_file}" | tee -a $LOGFILE
					LOGS_WITH_ERROR_COUNT=$((${LOGS_WITH_ERROR_COUNT}+1))
					NOK_LOGS=`echo -e "${NOK_LOGS}\n\t${log_file}"`

					# refine the search on the valid errors found
					if [ ! -z "$msg" ]; then
						# build up a list of major issues to be highlighted in summary
						err_msg=`echo "$msg"|egrep "${SEARCH_ERRORS_FOR_SUMMARY}"`
						if [ "${err_msg}" != "" ]; then
							ERRORS_FOR_SUMMARY=`echo -e "${ERRORS_FOR_SUMMARY}\n${err_msg}"`
						fi
	
						# build up a list of failed rpms to be printed in summary
						failed_rpm=`echo "$msg"|egrep "${SEARCH_CD3_RPM_FAILED}"|awk -F": " '{print "\t"$2}'`
						if [ "${failed_rpm}" != "" ]; then
							CD3_FAILED_RPMS=`echo -e "${CD3_FAILED_RPMS}\n$failed_rpm"`
						fi
					fi
				fi
				echo ""  | tee -a $LOGFILE
        		done # end for each file in the log_dir according to pattern
		fi
         
	done # end for each directory in "location"


	echo "" | tee -a $LOGFILE
	echo "====================== DONE log inspection: `date`  ====================" | tee -a $LOGFILE
	echo "" | tee -a $LOGFILE
	echo "Totally ${TOTAL_LOGS} trace files are inspected." | tee -a $LOGFILE
	echo "${LOGS_WITH_ERROR_COUNT} trace files contain errors." | tee -a $LOGFILE
	if [ "${NOK_LOGS}" != "" ]; then
		echo "" | tee -a $LOGFILE
		echo "For the NOK files, please see the following detailed logs:" | tee -a $LOGFILE
		echo -e "\t${NOK_LOGS}" | tee -a $LOGFILE
		echo "" | tee -a $LOGFILE
	fi
}

check_ISO_version_rpms () 
{
	# check  that the version packages for our ISOs are installed on server according with its type
	list="${SERVER_TYPE}_ISO_VERSION_PACKAGES"
	for ver_rpm in ${!list}
	do
		rpmname=`echo $ver_rpm | awk -F"|" '{print $2}'`
		dbpath=`echo $ver_rpm | awk -F"|" '{print $1}'`	
		result=`rpm -qa --dbpath ${dbpath} $rpmname`
		if [ -z ${result} ]; then
			VER_RPM_MISSING=`echo -e "${VER_RPM_MISSING}\n\t${rpmname}"`
		fi
	done # end for each ISO version package 
}

print_failed_rpms_summary ()
{
	# print the list of failed rpms  
	if [ "${VER_RPM_MISSING}" != "" -o "${CD3_FAILED_RPMS}" != "" ]; then
		echo "The following packages failed to install:" | tee -a $LOGFILE
		STR_PRINT=`echo -e "${CD3_FAILED_RPMS}${VER_RPM_MISSING}" | sed -e 's%^[[:space:]]*%\\t%' `
		echo -e "${STR_PRINT}" | tee -a $LOGFILE
		echo "" | tee -a $LOGFILE
	fi

}

print_important_errors_summary ()
{
	#  print the list of major errors that user should be aware of 
        if [ "${ERRORS_FOR_SUMMARY}" != "" ]; then
                echo "The following major issues appeared during installation:" | tee -a $LOGFILE
		SUMMARY_PRINT=`echo -e "${ERRORS_FOR_SUMMARY}" | sed -e 's%^[[:space:]]*%\\t%' `
                echo -e "${SUMMARY_PRINT}" | tee -a $LOGFILE
                echo "" | tee -a $LOGFILE
        fi

}

################# MAIN ###########################
HERE=`pwd`
SERVER_TYPE=`grep TYPE /etc/MUSE.signature | cut -f2 -d ' '`
LOGFILE="install_result_`date '+%d_%m_%y__%H-%M-%S'`.txt"
config_file=${HERE}/config.cfg
CD3_FAILED_RPMS=""
VER_RPM_MISSING=""
ERRORS_FOR_SUMMARY=""

if [ -f $config_file ]; then
        . $config_file
else
        echo "ERROR: Missing configuration file: $config_file!" > $LOGFILE
        echo "Cannot check logs" >> $LOGFILE
fi

generic_check_all_logs
check_ISO_version_rpms
print_important_errors_summary
print_failed_rpms_summary

echo "" | tee -a $LOGFILE
echo "Log file for this inspection: ${HERE}/${LOGFILE}" | tee -a $LOGFILE
echo "" | tee -a $LOGFILE
