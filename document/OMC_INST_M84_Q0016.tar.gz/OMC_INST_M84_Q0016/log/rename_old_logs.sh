#!/bin/bash
#set -x
server_install_current=`ls -t /alcatel/install/log | grep server_install | head -1`
HERE=`pwd`
config_file=${HERE}/config.cfg
type=`grep TYPE /etc/MUSE.signature | cut -f2 -d ' '`
if [ -f $config_file ]; then
        . $config_file
else
        echo "ERROR: Missing configuration file: $config_file!"
fi

for log_dir in ${LOG_FILE_LOCATIONS}
do

	if [ -d $log_dir ]
	then
		cd $log_dir
		for log in `find . -type f -regex $LOG_FILE_PATTERNS | egrep -v "old"`
		do
			if [ "$log" = "./NA_import_results.txt" ] || [ "$log" = "./LTE_import_results.txt" ] || [ "$log" = "./EPC_import_results.txt" ] || [ "$log" = "./ALL_import_results.txt" ]
				then
				log_clean=`echo "$log" | sed 's/\.\///g'`
				mv "${log_clean}" "${log_clean}_`date '+%Y%m%d_%H%M%S'`.old"
			elif [ "$log" = "./install_PATCHES.log" ]
				then
				echo "  Ignoring $log"
			else
				if [ "$log" != "./$server_install_current" ]
                                then
					old_log="$log"".old"
					mv "$log" "$old_log"
					ver=`echo "$old_log" | sed 's/.log/-log/'`
					if [ "$old_log" != "$ver" ]
                                	then
                                        	mv -f "$old_log" "$ver"
                                	fi
				fi
			fi
		done
	fi
done
