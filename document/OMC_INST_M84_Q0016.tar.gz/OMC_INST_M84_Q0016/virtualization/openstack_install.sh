#!/bin/bash

typeset -A WWN CONFIG_INTERFACES
typeset -A disk_size disk_size_selected dest

LOG=/alcatel/install/log/$(basename $0)_log_$$

ORACLE_BASE="/opt/app/oracle"
ORACLE_ADMIN="/alcatel/oracle/admin"
TIME_LOG=/var/log/time.log
AI_ISO_DIR=/alcatel/iso
LOG_DIR=/alcatel/install/log
idate=`date '+%Y%m%d_%H%M%S'`
omc_inst_tgz=`find $AI_ISO_DIR -type f -name OMC_INST_*`
filename=`basename $omc_inst_tgz`
relevant_name=`echo $filename | sed -e "s/\([a-zA-Z0-9_]*\).*/\1/"`
OS_TYPE=$(uname -s)
AI_NPO_MAIN_IPADDR=$(ifconfig eth0 | grep -w "inet" | awk '{n=split($2,a,":");print a[n]}')
VAR_PRE_DIR=/root/DVD1L_install


RHEL_VERS=$(awk '{split($(NF-1),a,".");print a[1]}' /etc/redhat-release)

if [ "$RHEL_VERS" -eq 7 ];then
        PART_ENTRY_TYPE=ID_PART_ENTRY_UUID
else
        PART_ENTRY_TYPE=UDISKS_PARTITION_UUID
fi





init_vars () {

if [ -s /alcatel/iso/NPO_profile ];then
	echo "NPO profile found ..."
	dos2unix /alcatel/iso/NPO_profile
	set -a
	. /alcatel/iso/NPO_profile
	set +a
else
	echo "NPO profile (/alcatel/iso/NPO_profile) not found. Cannot continue !"
	exit 1
fi	

PART_MAX_SIZE=2000
RAW_RULES_FILE=/etc/udev/rules.d/81-raw.rules
USERS_HOME=/alcatel/var/home

mkdir -p $AI_ISO_DIR
mkdir -p $USERS_HOME

}


{
echo_line () {

echo "---------------------------------------------------------------------------"

}


#--------------------------------------------------------------------------------
#Create /etc/MUSE.signature file
#--------------------------------------------------------------------------------
create_muse_signature()
{
        cat >> /etc/MUSE.signature << EOT
TYPE $SERVER_TYPE
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    NOKIA Customized Operating System
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EOT
}

function checkErr () {
        ERR_CODE=$1
        ERR_MSG=$2

        if [ "$ERR_CODE" -ne "0" ]; then
                PRINT_MSG="ERROR: `date '+[%m/%d/%g-%H:%M:%S]'` $ERR_MSG."
                echo "${PRINT_MSG} Exiting with error:[$ERR_CODE]." | tee -ai $LOG
                wall " `date '+[%m/%d/%g-%H:%M:%S]'` : FAILED TO LAUNCH INSTALLATION. Check details in log file: $LOG"
                echo -e "\nLog file is: $LOG"
                exit $ERR_CODE
        fi
}

function check_server_type () {
	
	mkdir -p /install/data

	case $SERVER_TYPE in

		"NPO")
                	echo -e "ASM=1\nRAC=0\nSAN=0" >/install/data/cluster.conf
		;;
		
	        "AUX_GL2"|"AUX_PCMD")
              		echo -e "ASM=0\nRAC=0\nSAN=0" >/install/data/cluster.conf
        	;;
		
		*)
			checkErr 1 "The option $SERVER_TYPE is unknown.Please check the variable SERVER_TYPE."	
		;;

	esac	

	echo " `date '+DATE: %m/%d/%g TIME: %H:%M:%S'` You are installing:$SERVER_TYPE."

}

function extract_omc () {

	      #by this time, the OMC_INST is already extracted, keeping for compatibility purposes only
              echo "$(date '+DATE: %m/%d/%g TIME: %H:%M:%S') Extracting $omc_inst_tgz to /alcatel directory" 
              tar -xvf $omc_inst_tgz -C /alcatel >>$LOG 2>&1
		status=$?

              if [ $status -ne 0 ];then
                  checkErr 1 "Failed to extract $omc_inst_tgz to /alcatel directory"
	      fi
}


function gen_profile () {

	if [ -f /var/tmp/server.profile ];then
		mv /var/tmp/server.profile /var/tmp/server.profile.old
	fi
	
	if [ "$AI_ORACLE_COMPRESSION" = "Y" -a $SERVER_TYPE = "NPO" ]; then
		compression="-e $AI_ORACLE_COMPRESSION"
	else
		compression=""
	fi
	#FQDN (both vars) set only by NPO_profile, gen_profile will take from enviroment those vars ...

	if [ -f /alcatel/$relevant_name/gen_profile ];then
		echo "$(date '+DATE: %m/%d/%g TIME: %H:%M:%S') Running /alcatel/$relevant_name/gen_profile" 
		echo "Generating profile with command:"
		echo "$(date '+DATE: %m/%d/%g TIME: %H:%M:%S') ./gen_profile -a $AI_INSTALL_TYPE -d $AI_ISO_DIR -w $AI_WEEKLY_CONSO_DAY -c $AI_CI_MODE -h $AI_HISTO_PARTITION -b $AI_BACKUP_TYPE -m $AI_MARKET_INFO -i true -n $AI_NPO_MAIN_IPADDR -q $AI_FQDN -f $AI_USE_FQDN $compression -z $AI_NA_METADATA_CHOICE"	
		/alcatel/$relevant_name/gen_profile -a $AI_INSTALL_TYPE -d $AI_ISO_DIR -w $AI_WEEKLY_CONSO_DAY -c $AI_CI_MODE -h $AI_HISTO_PARTITION -b $AI_BACKUP_TYPE -m $AI_MARKET_INFO -i true -n $AI_NPO_MAIN_IPADDR -q $AI_FQDN -f $AI_USE_FQDN $compression -z $AI_NA_METADATA_CHOICE


	else
		checkErr 1 "/alcatel/$relevant_name/gen_profile not found"
	fi
	

	if [ ! -f /var/tmp/server.profile ];then
		checkErr 1  "/var/tmp/server.profile was not generated"
	fi

}

function server_autoinstall () {

        if [ -f /alcatel/$relevant_name/server_install ]
        then
            echo "Running /alcatel/$relevant_name/server_install" >> $LOG
            wall "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` *** LAUNCHING NPO INSTALLATION ***"
            /alcatel/$relevant_name/server_install -y /var/tmp/server.profile
            if [ $? -ne 0 ]
            then
                  checkErr 1 "server_install script failed with error code $?. Check installation logs in /alcatel/install/log"
            fi
        else
                  checkErr 1 "/alcatel/$relevant_name/server_install not found"
        fi

}


install_OS_rpms() {
#set -x
sleep 20
echo_line
echo "[`date '+%d-%m-%y %H:%M'`] Install the needed OS rpm's"
#RCA: avoid java-openjdk packages to be installed
if [ "$RHEL_VERS" -eq 6 ];then
	yum -y install $(cat /alcatel/$relevant_name/virtualization/NPO_OS_rpms6) -x $(yum list available|grep openjdk|awk '{printf $1","}') --skip-broken

else
	yum -y install $(cat /alcatel/$relevant_name/virtualization/NPO_OS_rpms) -x $(yum list available|grep openjdk|awk '{printf $1","}') --skip-broken

fi	

}

create_oracle_user()
{
        ###create oracle user

        /usr/sbin/groupadd -g 501 oinstall
        /usr/sbin/groupadd -g 502 dba
        /usr/sbin/groupadd -g 503 asmdba
        /usr/sbin/groupadd -g 504 asmadmin
        /usr/sbin/groupadd -g 505 oper
        /usr/sbin/useradd -p '$6$pWqiF0Ck$X1G77fju0yQIHLhnhYVp335W1cUsIXstAwzj0.CSd3TDjWqUFObtZIuRGgmwdRwljxb7QXRbnPW3AB9Y3hG0A1' -m -g oinstall -G dba,asmdba,asmadmin,oper -d $USERS_HOME/oracle oracle
        echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`: oracle user was successfully created"                   
}

get_disks () {
#set -x
for disk in $(sfdisk -s 2>/dev/null|awk '!/blocks/{gsub(":","");if($NF/(1024*1024) > 80){print $1}}');do
	mount |grep -q $disk 
	if [ $? -eq 0 ];then continue;fi

	grep -q "^$disk" /etc/fstab
	if [ $? -eq 0 ];then continue;fi

	for uuid in $(awk '/^UUID=/{print $1}' /etc/fstab);do
		findfs $uuid|grep -q $disk 
		if [ $? -eq 0 ];then continue 2;fi
	done

	grep $disk /proc/swaps
	if [ $? -eq 0 ];then continue;fi

	disk_size[$disk]=$(($(sfdisk -s $disk 2>/dev/null)/(1024*1024)))
	echo "Disk: $disk size: ${disk_size[$disk]}"
done

echo_line
echo "Available disks: ${#disk_size[@]}"
echo_line
}

set_disk_destination () {
#set -x
#----------------------------------------------------------------------------------------
#  Number of available disks:
#    NPO)
#	1,2: XS/S config, take in order (bigger first) DATA
#	3+     : MEDIUM config, take in order (first 3, bigger first) DATA,  
#		 RECO, REDO
#    AUX)
#	* take the biggest and create alcatel
#----------------------------------------------------------------------------------------

#partitions to allocate, in order, size descendent

if [ "${#disk_size[@]}" -lt 3 ];then
	PARTITIONS="DATA"
else
	PARTITIONS="DATA RECO REDO"
fi

mkdir -p /install/data

	if [ "${#disk_size[@]}" -eq 0 ];then
		echo "There are no available disks for Oracle ASM; exiting ..."
		exit 1
	fi

	for part in $PARTITIONS;do
	    max_size=0
	    unset max_disk
	    for disk in ${!disk_size[@]};do
                if [ ${disk_size[$disk]} -gt $max_size ]; then 
		  max_size=${disk_size[$disk]}; 
		  max_disk=$disk
       		fi
	    done
	    echo "$part diskgroup will be hosted on: $max_disk size: $max_size"

	    dest[$part]=$max_disk
	    disk_size_selected[$max_disk]=${disk_size[$max_disk]}
	    unset disk_size[$max_disk]		
	done
	echo_line

	if [ ${#disk_size[@]} -gt 0 ];then
       		echo "Other disks are: ${!disk_size[@]}"
	else
       		echo "All candidate disks assigned ..."
	fi


}

reload_udev () {

#RCA: trigger partitioning attributes (ID_PART_ENTRY_UUID,ID_SERIAL)
udevadm control --reload-rules 2>/dev/null
udevadm trigger --type=devices --action=change 2>/dev/null
sleep 1

}




update_cluster_conf () {

# Prepare the VAR.pre file (will be needed during O/S migration)
VAR_PRE_FILE=$VAR_PRE_DIR/VAR.pre
mkdir -p $VAR_PRE_DIR
echo "# This reduced VAR.pre file is used during O/S migration" > $VAR_PRE_FILE

#In case license.xml is in /alcatel/iso
mv -f $AI_ISO_DIR/license.xml /install/data

echo "#raw rules by $0 on $(date)" > $RAW_RULES_FILE
#set -x
n=1
for part in $PARTITIONS;do

	k=0	
	unset index
	disk=$(echo "${dest[$part]}"|sed "s/\/dev\///")
	dest_byid=$(ls -l /dev/disk/by-id/|awk '{n=split($NF,a,"/");if(a[n]=="'$disk'"){print "/dev/disk/by-id/"$(NF-2)}}')
	parted -s ${dest[$part]} mklabel gpt
        echo "parted mklabel exit $? on ${dest[$part]}"

	#default one partition, whole ld
	partitions=$((${disk_size_selected[${dest[$part]}]}/$PART_MAX_SIZE))
	if [ ${disk_size_selected[${dest[$part]}]} -gt $(($PART_MAX_SIZE * $partitions)) ]; then
		let partitions++
	fi
	start_percent=0
	each_part_percent=$((100 / $partitions))
	echo_line
	echo "Disk: ${dest[$part]} size: ${disk_size_selected[${dest[$part]}]} partitions: $partitions"
	for ((p=1;p<=$partitions;p++));do
                if [ $k -gt 0 ];then 
			index=$k
		fi
                end_percent=$(( $start_percent + $each_part_percent ))
		echo "Running: parted -s -a optimal $dest_byid mkpart CLUSTER_$part$index $start_percent% $end_percent%"
                parted -s -a optimal $dest_byid mkpart CLUSTER_$part$index $start_percent% $end_percent%
                echo -e "\n>>>>>> parted mkpart returned $? on ${dest[$part]} partition $p" >>$LOG
		partprobe ${dest[$part]} >>$LOG 2>&1
		sleep 1
                echo -e "\n>>>>>> partprobe returned $? on $dest_byid partition $p" >>$LOG
		start_percent=$end_percent
		latest_part=$(partprobe -sd $dest_byid |awk '{print $NF}'|sed 's/<//g;s/>//g')
		asm_part=${dest_byid}-part$latest_part
		reload_udev
		if [ "$asm_part" ];then
                        dd if=/dev/zero of=$asm_part bs=16384 count=1 >>$LOG 2>&1
                        echo -e "\n>>>>>> destroy part $asm_part returned $?" >>$LOG
                fi

		let k++
		echo "CLUSTER_${part}$index=/dev/raw/raw$n" >>/install/data/cluster.conf

		#RCA: wait bellow udisk partition uuid assignement ...
		echo "Creating raw rule for: CLUSTER_${part}$index on $asm_part ..."
		c=0
		while sleep 2;do

			reload_udev
			udisks_partition_uuid=$(udevadm info -q all -n $asm_part|awk '{split($2,a,"=");if(a[1]=="'$PART_ENTRY_TYPE'"){print a[2]}}')
			if [ "$udisks_partition_uuid" ];then
				echo "ACTION==\"add|change\", SUBSYSTEM==\"block\", ENV{$PART_ENTRY_TYPE}==\"$udisks_partition_uuid\", RUN+=\"/bin/raw /dev/raw/raw$n %N\"" >>$RAW_RULES_FILE
				echo "ASM_PART$n=$asm_part" >>$VAR_PRE_FILE
				printf "OK\n"
				break
			else
				printf "."
			fi
			if [ $c -gt 30 ];then 
				echo "ERROR: Could not get partition UUID, cannot create raw device !"	
				exit 1
			fi
			let c++
		done
		let n++
	done
	
done

awk 'BEGIN{FS="="}{if(($1=="CLUSTER_DATA")||($1=="CLUSTER_RECO")||($1=="CLUSTER_REDO")){asm_type+=1}}END{print "ASM_TYPE="asm_type}' /install/data/cluster.conf >> /install/data/cluster.conf
echo "ACTION==\"add\", KERNEL==\"raw*\", OWNER==\"oracle\", GROUP==\"dba\", MODE==\"0660\"" >>$RAW_RULES_FILE

echo_line
reload_udev
raw -qa

}

customize_services () {

#first special ones, in house built

mkdir -p /install/script


#generic ones
chkconfig --level 12356 rpcbind off
chkconfig --level 12356 nfslock off
chkconfig --level 12356 rpcgssd off
chkconfig --level 12356 rpcidmapd off
chkconfig --level 12356 autofs off
chkconfig --level 12356 rhnsd off
chkconfig --level 12356 rhsmcertd off

chkconfig --level 4 rpcbind on
chkconfig --level 4 nfslock on
chkconfig --level 4 rpcgssd on
chkconfig --level 4 rpcidmapd on
chkconfig --level 4 autofs on

echo "Installing hostid ..."

python << END

from struct import pack
import os, fcntl, socket, struct

def getHwAddr(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    info = fcntl.ioctl(s.fileno(), 0x8927,  struct.pack('256s', ifname[:15]))
    return ''.join(['%02x' % ord(char) for char in info[20:24]])

hwaddr = "0x"+getHwAddr('eth0')
filename = "/etc/hostid"
hostid = pack("I",int(hwaddr,16))
open(filename,"wb").write(hostid)
os.chmod(filename, 0444)

END

}

customize_sysctl_conf() {

echo  "#Customizing /etc/sysctl.conf ..."

#https://access.redhat.com/site/solutions/46529 sysctl -p errors
grep -v "bridge.bridge-nf-call" /etc/sysctl.conf > /tmp/sysctl.conf_$$
cp /tmp/sysctl.conf_$$ /etc/sysctl.conf


###
#add new pamaterers for /etc/sysctl here
cat >> /etc/sysctl.conf << EOF

##############################
# Oracle Database requirements
##############################

# The max value for shmmax on a 32bit machine is 4294967295
kernel.shmmni = 4096
kernel.sem = 250 32000 100 128
fs.aio-max-nr = 1048576
fs.file-max = 6815744
#DCTPD01351263
net.ipv4.ip_local_port_range = 36001 65500
net.core.rmem_default = 4194304
net.core.wmem_default = 262144
net.core.rmem_max = 4194304
net.core.wmem_max = 1048576
net.ipv4.tcp_rmem = 4194304 4194304 4194304
net.ipv4.tcp_wmem = 262144 262144 262144
dev.raid.speed_limit_max = 20000
EOF
#########################

echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`: The new oracle parameters were added to the '/etc/sysctl.conf' file."    

}


create_axadmin_user()
{

        ###create other group
        /usr/sbin/groupadd other -g 1002

        ###create gadmin group and axadmin user:
        /usr/sbin/groupadd -g 1001 gadmin
        /usr/sbin/useradd -p '$6$VQk3k648$L.hgK7b36DHZnTIOIxS4hdhF2LtNJOGwt.xpfuaA0Kk8ky92I5l/p1G96CGVpoVKyD6Y835GF50ZlgYH2HfB9.' -m --uid 2500 -g gadmin -s /bin/ksh -d $USERS_HOME/axadmin axadmin
        chown axadmin:gadmin $USERS_HOME/axadmin
        chmod 755 $USERS_HOME/axadmin
        echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`: axadmin user was successfully created"                

}

create_oracle_directories()
{
        ###create oracle install dir
        mkdir -p $ORACLE_BASE
        chown oracle:oinstall $ORACLE_BASE
        chmod 755 $ORACLE_BASE
        echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`: Oracle install directory was successfully created"       

        ###addtional directory for user oracle
        mkdir -p $ORACLE_ADMIN
        chown oracle:oinstall $ORACLE_ADMIN
        echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`: Additional directory for user oracle was successfully created"     
}

customize_oracle_bashrc() {

        #Set oracle account environment variables
        echo "#Customizing $USERS_HOME/oracle/.bashrc ..."
        cat >> $USERS_HOME/oracle/.bashrc << EOF
# Oracle environment variables
export ORACLE_BASE=$ORACLE_BASE
export ORACLE_HOME=\$ORACLE_BASE/product/11.2.0.4
export LD_LIBRARY_PATH=\$ORACLE_HOME/lib
export PATH=\$PATH:\$ORACLE_HOME/bin
EOF
        echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`: The '.bashrc' file was successfully customized" 
}


customize_limits_conf() {

        echo "#Customizing /etc/security/limits.conf ..."

        echo "oracle    hard    nofile    65536" >> /etc/security/limits.conf

        echo "axadmin   soft    nproc     10240" >> /etc/security/limits.d/90-nproc.conf
        echo "oracle   soft    nproc     65536" >> /etc/security/limits.d/90-nproc.conf
        echo "nobody   soft    nproc     10240" >> /etc/security/limits.d/90-nproc.conf

        echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`: The 'limits.conf' file was successfully customized"      
}


customize_save_files () {

## Use of FQDN
#AI_USE_FQDN=N

# Domain Name
#AI_FQDN=nokia.com
#new /etc/hosts file

#RCA: disable cloud-init hostname update ....
echo "Disabling cloud-init hostname and etc_hosts update each reboot ..."
cp /etc/cloud/cloud.cfg /etc/cloud/cloud.cfg_saved
if [ $? -eq 0 ];then
	awk '{if($0~/update_hostname/ || $0~/update_etc_hosts/){print "#"$0}else{print}}' /etc/cloud/cloud.cfg_saved > /etc/cloud/cloud.cfg
fi
	

S_HOSTNAME=$(echo $(hostname)|awk '{split($1,a,".");print a[1];exit}')

echo -e "127.0.0.1\tlocalhost"    > /etc/hosts
if [ "$AI_USE_FQDN" = "N" ];then
	echo -e "$AI_NPO_MAIN_IPADDR\t${S_HOSTNAME}" >> /etc/hosts	
	grep -v HOSTNAME /etc/sysconfig/network >/tmp/network.$$
	echo "HOSTNAME=${S_HOSTNAME}" >> /tmp/network.$$
	echo "${S_HOSTNAME}" >/etc/hostname
	cp /tmp/network.$$ /etc/sysconfig/network
	hostname ${S_HOSTNAME}
	echo "Machine hostname: $(hostname)"
else
	echo -e "$AI_NPO_MAIN_IPADDR\t${S_HOSTNAME}.${AI_FQDN}\t${S_HOSTNAME}" >> /etc/hosts
	grep -v HOSTNAME /etc/sysconfig/network >/tmp/network.$$
        echo "HOSTNAME=${S_HOSTNAME}.${AI_FQDN}" >> /tmp/network.$$
	echo "${S_HOSTNAME}.${AI_FQDN}" >/etc/hostname
        cp /tmp/network.$$ /etc/sysconfig/network
	hostname ${S_HOSTNAME}.${AI_FQDN}
	echo "Machine hostname: $(hostname)"
fi


#cdrom_version
mkdir -p /usr/local/data/


#fstab cdrom mount entry
mkdir -p /media/cdrom
grep -q "/media/cdrom" /etc/fstab
if [ $? -ne 0 ];then
	echo -e "/dev/cdrom     /media/cdrom    auto    ro,noauto,nouser,exec 0 0" >>/etc/fstab
fi

ls /usr/bin/ksh >/dev/null 2>&1
status=$?
if [ $status -ne 0 ]
then
echo "Creating symbolik link"
ln -s /bin/ksh /usr/bin/ksh
         if [ $? -ne 0 ]
            then
                  checkErr 1 "Failed to created symbolik link."
         fi
else
echo "Symbolik link created. No nedd to create symbolik link."

fi

}



# -------------------------------------- main MAIN ----------------------------------------

#set -x

echo_line
echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`:Starting $0 on $(date) ..."
echo_line

extract_omc
install_OS_rpms
init_vars
check_server_type


create_oracle_user 2>>$LOG

if [ "$SERVER_TYPE" = "NPO" ];then
  #####Partitioning

	get_disks
	set_disk_destination
	update_cluster_conf
  ####

fi

####chroot
customize_services
customize_sysctl_conf
create_oracle_directories
customize_oracle_bashrc
create_axadmin_user
customize_limits_conf
customize_save_files
create_muse_signature
####


echo_line
echo "Log file: $LOG"
echo_line
####
echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` *** END OF CUSTOMIZATION SCRIPT ***" 

###launch install
gen_profile
server_autoinstall

}|tee -a $LOG

