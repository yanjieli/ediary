#!/bin/bash

echo "$(date) Starting $(dirname $0)/openstack_install.sh ..." 
mkdir -p /alcatel/install/log
nohup $(dirname $0)/openstack_install.sh >/alcatel/install/log/$(basename $0)_log_$$ 2>&1 &
echo "Installation will continue in background ..."
echo "Log dir: /alcatel/install/log"
