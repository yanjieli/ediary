#!/bin/ksh
#set -x

#####################################################################
## function to log messages                                         #
#####################################################################
writeLog() {
    MESSAGE="[`date '+%Y-%m-%d %H:%M:%S'`] $2"
    echo -e "[$1] ${MESSAGE}" >> ${LOGFILE}
    echo -e "${MESSAGE}"
}

#####################################################################
# ASM disk group name: ASMdgname[12]                                #
#####################################################################
readASMDiskGroupName() {
    tmpfile=/tmp/tmp.txt
    touch $tmpfile
    chmod 777 $tmpfile
    su - oracle <<- ! > $tmpfile
      . .grid_profile
      export ORACLE_SID=+ASM
      asmcmd lsdg
!
    #get the number of disk groups
    dgnumber=`cat $tmpfile | grep -v "Name" | wc -l`
    writeLog "INFO" "The number of Oracle Disk Groups is: $dgnumber "
    if [ $dgnumber -eq 1 ];then
    	#only one disk group - DATA
        stringarray=`cat $tmpfile | grep -A 1 Name | grep -v "Name"`
    	ASMdgname=($stringarray)
    	writeLog "INFO" "--- ASM Disk Group Name: ${ASMdgname[12]} "
    	ASM_DISKGROUP=${ASMdgname[12]}
    	asmlength=${#ASM_DISKGROUP}
    	ASM_DISKGROUP=${ASM_DISKGROUP:0:asmlength-1}
	writeLog "INFO" "The Oracle Disk Group is: $ASM_DISKGROUP "
    else
    	stringarray=`cat $tmpfile | grep -v "Name" | awk '{print $13}'`
        ASMdgname=($stringarray)
	count=0
        for index in "${ASMdgname[@]}"; do
            indexlength=${#index}
            indexvalue=${index:0:indexlength-1}
	    ASMdgname[${count}]=${indexvalue}
	    writeLog "INFO" "Oracle Disk Group: ${indexvalue} "
	    count=${count}+1
        done
	
    fi

}

#####################################################################
# SNM spfile name.location on ASM storage:			    #
#####################################################################
readSNMspfile() {
    tmpfile=/tmp/tmp1.txt
    touch $tmpfile
    chmod 777 $tmpfile
    su - oracle -c "
      . .profile
      export ORACLE_SID=SNM
      sqlplus -s / as sysdba <<-EOI
      spool $tmpfile
      show parameter spfile
      spool off
      exit
    EOI
    "
    stringarray=`cat $tmpfile | grep -v NAME | grep -v VALUE | grep -v "\-\-" | grep -v "^$"`
    SNMspfile=($stringarray)
    SNMspfilename=${SNMspfile[0]}
    SNMspfilevalue=${SNMspfile[2]}
    writeLog "INFO" "--- SNM spfile name is: $SNMspfilename and the value is $SNMspfilevalue"
}

#####################################################################
# Reconfigure ora has						    #	
#####################################################################
oracleReconfiguration() {
    ${GRID_HOME}/bin/srvctl status listener | grep "is running"
    listener_status=$?
    writeLog "INFO" "listener status $listener_status"
    if [ $listener_status -eq 0 ] ; then
        writeLog "INFO" "Oracle Listener is running" 
        writeLog "INFO" "Stopping listener" 
        su - oracle -c "
            . .grid_profile
            ${GRID_HOME}/bin/srvctl stop listener" 
    else
        writeLog "INFO" "Oracle Listener is stopped" 
    fi

    rh_ver=`lsb_release -r | awk -F' ' '{print $2}' | awk -F. '{print $1}'`
    if [ "$rh_ver" = "7" ]
    then
         dirpath=${GRID_HOME}/install/usm/Oracle/EL7/x86_64
         binpath=`find $dirpath -name "bin"`
         FILES=/tmp/files

         # create new location
         firstpart=`uname -r|awk '{split($1,a,"-");split(a[2],b,".");print a[1]"-"b[1]}'`
         secondpart=`uname -r|sed 's/.x86_64$/-x86_64/'`
         newlocation=${GRID_HOME}/install/usm/Oracle/EL7/x86_64/$firstpart/$secondpart/bin
         mkdir -p $newlocation

         #for loop for the 3 drivers
         for dir in $binpath; do
              find $dir -name "*.ko" >> $FILES
         done

         #for each file copy to new location
         for filename in `cat $FILES`; do
              cp $filename $newlocation
         done
         chown -R oracle:oinstall ${GRID_HOME}/install/usm/Oracle/EL7/x86_64/$firstpart
         rm -rf $FILES
    fi

    sudo $GRID_HOME/crs/install/roothas.pl -deconfig -force -verbose 
}                   

#####################################################################
# change hostname in /alcatel /opt /etc /root
#####################################################################
changeHostnameOnFiles() {
	
    OLD_HOSTNAME=$1
    NEW_HOSTNAME=$2

    FILES=/tmp/files
    DIR="/alcatel /opt /etc /root /install/data"
    writeLog "INFO" "Starting change the 'hostname change' process in all impacted files"
    writeLog "INFO" "Old HOSTNAME is '$OLD_HOSTNAME' and New HOSTNAME is '$NEW_HOSTNAME'"
    writeLog "INFO" "Finding all files that contain current hostname:"
    rm -f $FILES
    for dir in $DIR; do
        writeLog "INFO" "Searching $dir ..."
        find $dir -type f ! -iname "*.trace" ! -iname "*.log" ! -iname "*.dbf" ! -iname "*.jar" | xargs grep "$OLD_HOSTNAME" 2>/dev/null | cut -f1 -d":" | grep -v "core" | grep -v "Binary" | grep -v ".aud" | sort -u >> $FILES
    done

    #for each file , apply the replace
    for filename in `cat $FILES`; do
        wfile=${filename}
        writeLog "INFO" "Substituting in $wfile"
        substitute $wfile ${OLD_HOSTNAME} ${NEW_HOSTNAME}
    done
    rm -f $FILES
}

#####################################################################
# USAGE         : substitute <file> <old_value> <new_value>
#####################################################################
substitute() {
    real_file=$1
    old_value=$2
    new_value=$3
    tmp_file=/tmp/`/bin/basename ${real_file}`".tmp"

    #- the temporary file must be removed if it exists
    [[ -f ${tmp_file} ]] && rm -f ${tmp_file}

#    /bin/cat ${real_file} | /bin/sed -e "s/${old_value}/${new_value}/g" > ${tmp_file}	
	sed -i -e "s/\b${old_value}\b/${new_value}/g" $real_file
	
    if [ $? -eq 0 ]; then
        writeLog "INFO" "Substitution in file : ${real_file} succeeded ... Continuing"    
    else
        writeLog "ERROR" "Substitution in file : ${real_file} failed ... Aborting"
        return ${_abort_installation}
    fi
}

#####################################################################
# Add/Start ASM 
#####################################################################
add_start_ASM() {
    su - oracle -c "
        . .grid_profile
        ${GRID_HOME}/bin/srvctl add asm"

    ${GRID_HOME}/bin/srvctl status asm | grep "is not running"
    asm_status=$?
    writeLog "INFO" "asm status $asm_status"
    if [ $asm_status -eq 0 ] ; then
        writeLog "INFO" "asm is not running" 
        writeLog "INFO" "Starting asm"
        su - oracle -c "
            . .grid_profile
            ${GRID_HOME}/bin/srvctl start asm"
    else
        writeLog "INFO" "asm is running"
    fi

    ${GRID_HOME}/bin/srvctl status asm | grep "is running"
    asm_status=$?
    writeLog "INFO" "asm status $asm_status"
    if [ $asm_status -eq 0 ] ; then
        writeLog "INFO" "asm is running"
    fi
}

#####################################################################
# Mount all ASM diskgroups (DATA/RECO/REDO)
#####################################################################
mount_ASMDiskGroups() {
    if [ $dgnumber -eq 1 ];then
	writeLog "INFO" "Only one Disk Group present: $ASM_DISKGROUP"
        su - oracle -c "
            . .grid_profile
            export ORACLE_SID=+ASM
            asmcmd mount $ASM_DISKGROUP
        "
    else
        writeLog "INFO" "Several Disk Groups present "
        for index in "${ASMdgname[@]}"; do
	    writeLog "INFO" "Mounting Disk Group: $index "
            su - oracle -c "
                . .grid_profile
                export ORACLE_SID=+ASM
                asmcmd mount $index
            "
        done
    fi
    
    writeLog "INFO" "Oracle ASM diskgroups:"
    su - oracle -c "
        export ORACLE_SID=+ASM
        export ORACLE_HOME=$GRID_HOME
        sqlplus -S / as sysasm > $tmpfile <<- !
            select NAME from v\\\$asm_diskgroup;
!
        " > /dev/null
    cat $tmpfile 
}

#####################################################################
# Check asm status
#####################################################################
chech_ASM_Status() {
    ${GRID_HOME}/bin/crsctl status res -t | grep -A 1 ora.asm | grep -v ora.asm > /tmp/tmp.txt
  
    line=`cat /tmp/tmp.txt`
    stringarray=($line)
	tries=1
  
	while true
        do
			if [ ${stringarray[0]} == "ONLINE" ] && [ ${stringarray[1]} == "ONLINE" ] && [ ${stringarray[2]} == $SED_NEW_HOSTNAME ] && [ ${stringarray[3]} == "Started" ]; then
				writeLog "INFO" "asm resource is ONLINE on host $SED_NEW_HOSTNAME and is Started"
				break
			else
				tries=${tries}+1
				sleep 5			
			fi                        
			
			if [ $tries -eq 5 ];then
				break				
			fi
        done		  
}

#####################################################################
# Add/Start listener 
#####################################################################

add_start_oralistener() {
    listenerstatus=`netstat -nltp |grep 1521`
    netstatus=$?
    
    writeLog "INFO" "listener status $netstatus"
    
    if [ $netstatus -eq 0 ] ; then
        writeLog "INFO" $listenerstatus
        writeLog "INFO" "port is used - killing listener"
        statusarray=($listenerstatus)
        processid=${statusarray[6]}
        length=${#processid}
        idToKill=${processid:0:$length-8}
        killprocess=`kill -9 $idToKill`
    fi
  
    su - oracle -c "
        . .grid_profile
        ${GRID_HOME}/bin/srvctl add listener"
        ${GRID_HOME}/bin/srvctl status listener | grep "is not running"
        listener_status=$?
        writeLog "INFO" "listener status $listener_status"

        if [ $listener_status -eq 0 ]; then
            writeLog "INFO" "listener is not running"
            writeLog "INFO" "Starting listener "
            su - oracle -c "
                . .grid_profile
                ${GRID_HOME}/bin/srvctl start listener"
        else
            writeLog "INFO" "listener is running"
        fi
}

#####################################################################
# Add/Start SNM database instance resource
#####################################################################
add_start_SNM() {
    writeLog "INFO" "Add/Start SNM database instance resource "	
    writeLog "INFO" " GRID_HOME is: $GRID_HOME "
    writeLog "INFO" " ORACLE_HOME is: $ORACLE_HOME "
    writeLog "INFO" " SNM spfile value is: $SNMspfilevalue "

    su - oracle -c "
        . .grid_profile
        ${GRID_HOME}/bin/srvctl add database -d SNM -o $ORACLE_HOME -p $SNMspfilevalue -s open
        ${GRID_HOME}/bin/srvctl start database -d SNM"	
}
	  
#####################################################################
# Create omc_<new_hostname> Oracle user
#####################################################################
creat_OMC_user() {

    writeLog "INFO" "Creating the omc Oracle user "
    userowner="omc_$OLD_HOSTNAME"
    userdestination="omc_$SED_NEW_HOSTNAME"
   
    if [[ "$USE_FQDN" == "Y" ]]; then
	    
            writeLog "INFO" "Updating old short Hostname ${OLD_SHORTHOSTNAME} to ${SHORTHOSTNAME} in hosts file"
            userowner="omc_$OLD_SHORTHOSTNAME"
            userdestination="omc_$SHORTHOSTNAME"
    fi

    writeLog "INFO" "Deleting Oracle user $userowner and creating Oracle user $userdestination "

    su - oracle -c "
        export ORACLE_SID=SNM
        . .profile
        exp system/orapower owner=$userowner file=myexport.dmp log=myexport.log
        sqlplus -S / as sysdba > $tmpfile <<- !
            CREATE USER $userdestination
                IDENTIFIED BY $userdestination
                DEFAULT TABLESPACE muse
                TEMPORARY TABLESPACE TEMP;
            GRANT CONNECT, RESOURCE TO $userdestination;
!
        imp system/orapower fromuser=$userowner toUser=$userdestination file=myexport.dmp log=myimport.log"
}  

#####################################################################
# Create server.keystore using the new hostname
#####################################################################
createNewServerKeystores() {
    writeLog "INFO" "Updating keystores ..."
    cd ${CSA_PATH} 					
    dirname=keyStores.orig.`date '+%Y%m%d'`
    mkdir $dirname
    cp keyStores/* $dirname
  
    cd ${CSA_PATH}/keyStores/
    ./makeKeyStore.sh -i "" $SED_NEW_HOSTNAME Yes Yes
    chmod +r ${CSA_PATH}/keyStores/server.keystore
}

#####################################################################
# Restore Settings (hostname/IP) - no Oracle installed
#####################################################################
restore_settings() {
if [[ "${ACTUALHOSTNAME}" == "${OLD_HOSTNAME}" ]]; then

        writeLog "INFO" "Actual Hostname ${ACTUALHOSTNAME} is the same as ${OLD_HOSTNAME} "

        if [[ "${ACTUALIP}" == "${OLD_IP_TAG}" ]]; then
                writeLog "INFO" "actual IP/HOSTNAME are the same as the ones from /install/data/OMC_INSTALL "
        else
                writeLog "INFO" "--- Changing IP in files: ${OLD_IP_TAG} to ${ACTUALIP} --- "
                changeIPinFiles ${OLD_IP_TAG} ${ACTUALIP}
                writeLog "INFO" "--- Changing IP in /etc/hosts: ${OLD_IP_TAG} to ${ACTUALIP} --- "
                substitute /etc/hosts ${OLD_IP_TAG} ${ACTUALIP}
                writeLog "INFO" "Changing IP in Oracle: ${OLD_IP_TAG} to ${ACTUALIP} "
		changeIPinOracle ${OLD_IP_TAG} ${ACTUALIP}
		writeLog "INFO" "Changing IP in /etc/ssh/sshd_config: ${OLD_IP_TAG} to ${ACTUALIP} "
        	substitute /etc/ssh/sshd_config ${OLD_IP_TAG} to ${ACTUALIP}
        	service sshd restart
        fi
else
        writeLog "INFO" "Changing IP in files: ${OLD_IP_TAG} to ${ACTUALIP} "
        changeIPinFiles ${OLD_IP_TAG} ${ACTUALIP}

        writeLog "INFO" "Changing IP in /etc/hosts: ${OLD_IP_TAG} to ${ACTUALIP} "
        substitute /etc/hosts ${OLD_IP_TAG} ${ACTUALIP}

	writeLog "INFO" "Changing IP in /etc/ssh/sshd_config: ${OLD_IP_TAG} to ${ACTUALIP} "
	substitute /etc/ssh/sshd_config ${OLD_IP_TAG} to ${ACTUALIP}
	service sshd restart

        writeLog "INFO" "Changing hostname in /etc/hosts: ${ACTUALHOSTNAME} to ${OLD_HOSTNAME} "
        substitute /etc/sysconfig/network ${ACTUALHOSTNAME} ${OLD_HOSTNAME}

        hostname $OLD_HOSTNAME

	writeLog "INFO" "Trying to start PMON "
        substitute /alcatel/MS/MS_PMON/config/im/orb.properties ${OLD_IP_TAG} ${ACTUALIP}
fi

}

#################################################################
# Remove all AUX servers from host
#################################################################
removeAllAuxHosts() {
        writeLog "INFO" "Saving current location & moving to manage_aux.sh location "
        currentPWD=`pwd`
        cd /alcatel/MS/OMC_DBCF/scripts

        writeLog "INFO" "Get the list of attached AUX servers "
        list_aux=`./manage_AUX.sh list | egrep "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}" | awk -F' ' {'print $1'}`
        writeLog "INFO" "Currently attached aux servers: ${list_aux} "
        
        writeLog "INFO" "Removing all AUX servers attached to host "
        for aux_host in ${list_aux}
                do 
	        writeLog "INFO" "Removing host: '${aux_host}' "
                echo "${list_aux}" | ./manage_AUX.sh del
        done

        cd ${currentPWD}
}

#################################################################
# Check and Start Oracle and PMON
#################################################################
check_and_start_oracle_and_pmon() {

  writeLog "INFO" "Check and Start Oracle and PMON "

  ORACLE_HOME=${DB_HOME}
  export ORACLE_HOME

  ## OLD_HOSTNAME - old hostname
  ## OLD_IP_TAG - old IP
  ## 
  ## SED_NEW_HOSTNAME - new hostname (if entered)

  if [[ "${ACTUALHOSTNAME}" == "${OLD_HOSTNAME}" ]]; then

	writeLog "INFO" "Actual Hostname ${ACTUALHOSTNAME} is the same as ${OLD_HOSTNAME} "

	if [[ "${ACTUALIP}" == "${OLD_IP_TAG}" ]]; then
                writeLog "INFO" "actual IP/HOSTNAME are the same as the ones from /install/data/OMC_INSTALL "

	else

		writeLog "INFO" "--- Changing IP in files: ${OLD_IP_TAG} to ${ACTUALIP} --- "
        	changeIPinFiles ${OLD_IP_TAG} ${ACTUALIP}

		writeLog "INFO" "--- Changing IP in /etc/hosts: ${OLD_IP_TAG} to ${ACTUALIP} --- "
	        substitute /etc/hosts ${OLD_IP_TAG} ${ACTUALIP}
	        
		writeLog "INFO" "Changing IP in Oracle: ${OLD_IP_TAG} to ${ACTUALIP} "	
	        changeIPinOracle ${OLD_IP_TAG} ${ACTUALIP}

		writeLog "INFO" "Changing IP in /etc/ssh/sshd_config: ${OLD_IP_TAG} to ${ACTUALIP} "
        	substitute /etc/ssh/sshd_config ${OLD_IP_TAG} to ${ACTUALIP}
        	service sshd restart

	fi
  
  else

	writeLog "INFO" "Checking and starting Oracle and PMON --- " 
        writeLog "INFO" "Changing IP in files: ${OLD_IP_TAG} to ${ACTUALIP} "
	changeIPinFiles ${OLD_IP_TAG} ${ACTUALIP}

        writeLog "INFO" "Changing IP in /etc/hosts: ${OLD_IP_TAG} to ${ACTUALIP} "
	substitute /etc/hosts ${OLD_IP_TAG} ${ACTUALIP}

        writeLog "INFO" "Changing hostname in /etc/hosts: ${ACTUALHOSTNAME} to ${OLD_HOSTNAME} "
	substitute /etc/sysconfig/network ${ACTUALHOSTNAME} ${OLD_HOSTNAME}

	writeLog "INFO" "Changing IP in /etc/ssh/sshd_config: ${OLD_IP_TAG} to ${ACTUALIP} "
        substitute /etc/ssh/sshd_config ${OLD_IP_TAG} to ${ACTUALIP}
        service sshd restart


	writeLog "INFO" "Changing IP in Oracle: ${OLD_IP_TAG} to ${ACTUALIP} "
	changeIPinOracle ${OLD_IP_TAG} ${ACTUALIP}

 	hostname $OLD_HOSTNAME
	substitute /etc/hostname ${ACTUALHOSTNAME} ${OLD_HOSTNAME}

	start_oracle_cmd="$GRID_HOME/bin/crsctl start has"

	############ check if oracle is running. If not, try to start it

	sleep 1m
	
	processpid=`ps -ef | grep "ohasd.bin reboot" | grep -v grep | awk '{print $2}'`
	kill -9 $processpid 

        ps -ef | grep ora_pmon_SNM | grep -v grep
        ora_pmon_status=$?
        STATUS=`su - oracle -c "
	export ORACLE_SID=SNM
	export ORACLE_HOME=$ORACLE_HOME
	${ORACLE_HOME}/bin/srvctl status database -d SNM
"
`
	echo ${STATUS} | grep "Database is running"
	db_status=$?

        if [ ${ora_pmon_status} -eq 0 ] || [ ${db_status} -eq 0 ]; then
   		#if [ ${db_status} -eq 0 ]; then

		writeLog "INFO" "Oracle is running "
  	 else
           	writeLog "INFO" "Oracle is NOT running "
           	start_oracle_cmd="$GRID_HOME/bin/crsctl start has"
           	writeLog "INFO" "Starting Oracle using $start_oracle_cmd"
           	$start_oracle_cmd
           	sleep 30
           	i=0
           	while [ $i -lt 45 ] ; do
                	i=$(($i+1))
                   	ps -ef | grep ora_pmon_SNM | grep -v grep
                   	ora_pmon_status=$?
                   	if [ ${ora_pmon_status} -eq 0  ]; then
                        	i=45
                   	else
                        	echo "$i: Wait 20s"
                        	sleep 20
                       	fi
           	done

           	####### if oracle did not start, exit
           	if [ ${ora_pmon_status} -ne 0  ]; then
                	writeLog "ERROR" "Starting Oracle using $start_oracle_cmd failed"
                	exit 1
            	else

		    	writeLog "INFO" "Trying to start PMON "
			substitute /alcatel/MS/MS_PMON/config/im/orb.properties ${OLD_IP_TAG} ${ACTUALIP}
           	fi
  	fi
  fi
}

#################################################################
# CRI 385374.01: Re-configure CSA and WEB-SSO
#################################################################
configureCSA() {

    OLD_IP=$1
    NEW_IP=$2
 
    writeLog "INFO" "Configuring CSA "
    writeLog "INFO" "Stopping LDAP "

    ${OMC_HOME}/MS_PMON/scripts/pmon.sh stop | tee -a $LOGFILE
    ${OMC_HOME}/MS_PMON/scripts/startstop/stop_ldap
    ${OMC_HOME}/MS_PMON/scripts/startstop/stop_csa

    ${CSA_PATH}/bin/system/oam/cnm-replace-ip -c csa -o $OLD_IP -n $NEW_IP | tee -a $LOGFILE
    
    ${OMC_HOME}/MS_PMON/scripts/pmon.sh start

    writeLog "INFO" "Starting webstart... "
 
    ${OMC_HOME}/MSweb/scripts/webstart.sh
}

#################################################################
#Change floating IP in all impacted files
#################################################################
changeIPinFiles() {
    OLD_IP=$1
    NEW_IP=$2    

    writeLog "INFO" "Starting Change floating IP process in all impacted files"
    
    writeLog "INFO" "Old IP: ${OLD_IP} and New IP: ${NEW_IP}"
    
    FILES=/tmp/files
    DIR="/alcatel/muse ${OMC_HOME} /alcatel/install /var/tmp /opt/apache/ /opt/PC_3PP ${TOMCAT_HOME}/webapps/ROOT/ /opt/tomcat_instances/ /install/data /etc/iCSA.txt"
    
    writeLog "INFO" "Finding all files that contain hardcoded IPs"
    rm -f $FILES
    for dir in $DIR
    do
    	writeLog "INFO" "Searching $dir..."
		find $dir -type f ! -iname "*.trace" ! -iname "*.log" ! -iname "*.dbf" ! -iname "*.jar" | xargs grep "$OLD_IP" 2>/dev/null | cut -f1 -d":" | grep -v "core" | grep -v "Binary" | grep -v ".aud" | sort -u >> $FILES
    done
    #for each file , apply the replace
    for filename in `cat $FILES`
    do
    	wfile=${filename}
    	writeLog "INFO" "Substituting in $wfile"
    	substitute $wfile ${OLD_IP} ${NEW_IP}	
    done
    rm $FILES
}

#################################################################
#Change ip in Oracle
#################################################################
changeIPinOracle() {

	OLD_IP=$1
	NEW_IP=$2
	
	writeLog "INFO" "Substitution in ${GRID_HOME}/network/admin/sqlnet.ora file"
	oracle_file=${GRID_HOME}/network/admin/sqlnet.ora
	oracle_file_db=${DB_HOME}/network/admin/sqlnet.ora
	oracle_file_orig=${GRID_HOME}/network/admin/sqlnet.ora_orig
	oracle_file_db_orig=${DB_HOME}/network/admin/sqlnet.ora_orig
    
    if [ -f  $oracle_file ];then
            cp -p $oracle_file $oracle_file_orig
            /bin/cat $oracle_file  | /bin/sed -e "s/${OLD_IP}/${NEW_IP}/g" > /tmp/sqlnet.ora.tmp
            cp /tmp/sqlnet.ora.tmp $oracle_file
            chown oracle:oinstall $oracle_file
            chmod 644 $oracle_file
            rm /tmp/sqlnet.ora.tmp
    fi

    writeLog "INFO" "Substitution in ${DB_HOME}/network/admin/sqlnet.ora file"
    if [ -f  $oracle_file_db ];then
            cp -p $oracle_file_db $oracle_file_db_orig
            /bin/cat $oracle_file_db  | /bin/sed -e "s/${OLD_IP}/${NEW_IP}/g" > /tmp/sqlnet.ora.tmp
            cp /tmp/sqlnet.ora.tmp $oracle_file_db
            chown oracle:oinstall $oracle_file_db
            chmod 644 $oracle_file_db
            rm /tmp/sqlnet.ora.tmp
    fi
}
#################################################################
#################################################################
## Main                                                        ##
#################################################################

LOGFILE="/alcatel/install/log/changeiphostname_`date '+%d_%m_%y__%H-%M-%S'`.log"
UPDATE_HOSTNAME="NO"

while getopts ":h:" opt; do
    case "${opt}" in
    h) SED_NEW_HOSTNAME=`echo "$OPTARG" | /bin/sed 's/\//\\\\\//g'`; UPDATE_HOSTNAME="YES";;
    \?) writeLog "ERROR" "Unknow option: '$OPTARG'!\n\t\tUsage: `basename \"$0\"` -h <newhostname> "; exit 1;;
    esac
done

ACTUALHOSTNAME=`hostname`
ACTUALIP=$(ifconfig eth0|awk '{if($1=="inet"){n=split($2,a,":");print a[n];exit}}')

if [ ! -f /install/data/OMC_INSTALL ] ;then
        writeLog "ERROR" "/install/data/OMC_INSTALL file not found" 
        exit 1
fi

. /install/data/OMC_INSTALL

OLD_HOSTNAME=${HOST_NAME}
OLD_IP_TAG=${IP_SERVER}

#readSNMspfile


writeLog "INFO" "**********************************\n\tThe Old IP of the NPO server is: $OLD_IP_TAG and The Old Hostname is:${OLD_HOSTNAME}\
        \n\tThe New IP will be: $ACTUALIP and The New Hostname will be: $SED_NEW_HOSTNAME"
writeLog "INFO" "**********************************"

#sleep 1m

userowner="omc_$OLD_HOSTNAME"
userdestination="omc_$SED_NEW_HOSTNAME"

HAS_ORACLE="NO"
oratabfile=/etc/oratab
CSA_HOME=/alcatel/csa
CSA_PATH=${CSA_HOME}/ngsec/NGSEC
OMC_HOME=/alcatel/MS

if [[ -f /etc/oratab ]]; then

	writeLog "INFO" "Oracle DB present "
	HAS_ORACLE="YES"
	ORACLE_HOME=`awk -F: '$1 ~/^SNM$/ {print $2}' $oratabfile`
        export ORACLE_HOME
	GRID_HOME=`awk -F: '$1 ~/^\+ASM$/ {print $2}' $oratabfile`

	# Check and start Oracle and PMON Here
	check_and_start_oracle_and_pmon
	sleep 1m
        readASMDiskGroupName
        readSNMspfile

else
	writeLog "INFO" "Oracle DB is not present. "
	restore_settings
fi

sleep 1m

if [[ "${UPDATE_HOSTNAME}" == "YES" ]]; then
        writeLog "INFO" "Checking if the server has FQDN "
        if [[ "$USE_FQDN" == "N" ]]; then
	        writeLog "INFO" "The server doesn't use FQDN "
        else

		writeLog "INFO" "Extracting old domain name and old short hostname "
		position=`echo $CLUSTER_NAME |awk 'END{print index($0,".")}'`
		length=${#CLUSTER_NAME}
                domainlength=$((length-$position))
                OLD_DOMAIN_NAME=${CLUSTER_NAME:$((position)):$domainlength}
                OLD_SHORTHOSTNAME=${CLUSTER_NAME:0:$position-1}
		writeLog "INFO" "The server uses FQDN "

                writeLog "INFO" "The Old Domaine name is: $OLD_DOMAIN_NAME  "
                writeLog "INFO" "The Old short Hostname is: $OLD_SHORTHOSTNAME  "

		if echo "$SED_NEW_HOSTNAME" | grep -q "."; then
	                writeLog "INFO" "Extracting short hostname from FQDN "
			position=`echo $SED_NEW_HOSTNAME |awk 'END{print index($0,".")}'`
			length=${#SED_NEW_HOSTNAME}
			domainlength=$((length-$position))
			DOMAIN_NAME=${SED_NEW_HOSTNAME:$((position)):$domainlength}
			SED_NEW_HOSTNAME=${SED_NEW_HOSTNAME:0:$position-1}
			SHORTHOSTNAME=$SED_NEW_HOSTNAME
			FULLHOSTNAME=$SHORTHOSTNAME.$DOMAIN_NAME
	                writeLog "INFO" "The New Domaine name is: $DOMAIN_NAME  "
	                writeLog "INFO" "The New short Hostname is: $SHORTHOSTNAME  "

		else
                        writeLog "INFO" "The hostname entered doesn't contain the domain name "
                        FULLHOSTNAME=$SED_NEW_HOSTNAME.$OLD_DOMAIN_NAME
		fi
        fi

  if [[ `echo "${SED_NEW_HOSTNAME}" | grep -iv '^npo$' | wc -l` -ne 1 ]]; then
      writeLog "ERROR" "'Hostname can not be '${SED_NEW_HOSTNAME}'. Please use a different name for server name."
      exit 1
  else
    if [[ ${#SED_NEW_HOSTNAME} -gt 16 ]]; then
      writeLog "ERROR" "'${SED_NEW_HOSTNAME}' is longer than 16 alphanumeric characters "
      exit 1
    else
      if [ `echo "${SED_NEW_HOSTNAME}" | egrep '^[a-zA-Z]' | egrep -iv npo | egrep -v '[[:blank:]_$@#%&*]' | wc -l` = 0 ]; then
        writeLog "ERROR" "'${SED_NEW_HOSTNAME}' is an invalid name for npo server "
        exit 1
      else
        writeLog "INFO" "New name for npo server is '${SED_NEW_HOSTNAME}' "
      fi
    fi
  fi
    
    if [[ "$USE_FQDN" == "N" ]]; then
	    writeLog "INFO" "Updating Hostname to ${SED_NEW_HOSTNAME} "
    else
	    writeLog "INFO" "Updating Hostname to ${FULLHOSTNAME} "
            writeLog "INFO" "Updating old short Hostname ${OLD_SHORTHOSTNAME} to ${SHORTHOSTNAME} in hosts file"
	    substitute /etc/hosts ${OLD_SHORTHOSTNAME} ${SHORTHOSTNAME}

            writeLog "INFO" "Updating old Domain name: ${OLD_DOMAIN_NAME} to ${DOMAIN_NAME} in hosts file"
            substitute /etc/hosts ${OLD_DOMAIN_NAME} ${DOMAIN_NAME}

            SED_NEW_HOSTNAME=${FULLHOSTNAME}
    fi	
  
    sleep 1m
 
    if [[ "${HAS_ORACLE}" = "YES" ]]; then
        #readASMDiskGroupName
        #readSNMspfile 
        oracleReconfiguration
    fi

   sleep 1m

    ACTUALHOSTNAME=`hostname` 
    changeHostnameOnFiles ${ACTUALHOSTNAME} ${SED_NEW_HOSTNAME}
    hostname $SED_NEW_HOSTNAME
    substitute /etc/hostname ${ACTUALHOSTNAME} ${SED_NEW_HOSTNAME} 
    
    if [[ "${HAS_ORACLE}" = "YES" ]]; then
        sudo $GRID_HOME/crs/install/roothas.pl -verbose 
        add_start_ASM
        mount_ASMDiskGroups
        chech_ASM_Status
        add_start_oralistener
        chech_ASM_Status
        add_start_SNM
        chech_ASM_Status
        creat_OMC_user
    fi
    createNewServerKeystores
fi

if [ $OMC_CONF = "XLARGE" ] || [ $OMC_CONF = "MEDIUM" ] || [ $OMC_CONF = "SMALL" ]; then
	writeLog "INFO" "Removing all aux's attached to host "
	removeAllAuxHosts
fi

hostid=`hostid`
writeLog "INFO" "Removing old hostid: $hostid "

oldhostidfile=/etc/hostid
rm -rf $oldhostidfile

python << END

from struct import pack
import os, fcntl, socket, struct

def getHwAddr(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    info = fcntl.ioctl(s.fileno(), 0x8927,  struct.pack('256s', ifname[:15]))
    return ''.join(['%02x' % ord(char) for char in info[20:24]])

hwaddr = "0x"+getHwAddr('eth0')
filename = "/etc/hostid"
hostid = pack("I",int(hwaddr,16))
open(filename,"wb").write(hostid)
os.chmod(filename, 0444)

END

hostid=`hostid`

writeLog "INFO" "The NEW hostid is $hostid "
writeLog "INFO" "Finished runnning successfully change_ip_hostname.sh"
#####################################################################
