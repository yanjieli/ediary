#!/bin/bash
set -x

LOG="/alcatel/install/log/MAIN_customer_data_BR.log_`date '+%Y-%m-%d_%H-%M-%S'`"
script_dir="/alcatel/backup/backup_MAIN"
ME=$(basename $0)

initialize ()
{
	if [ $# -gt 2 ] || [ $# -eq 0 ]
        then
                echo "Error : incorrect number of arguments.Check usage!" | tee -a $LOG
		echo ""
                echo "usage : $ME backup | restore <archive_name> " | tee -a $LOG
		echo ""
                exit 1
	fi
	
	if [ $1 != "backup" ] && [ $1 != "restore" ]
	then 
		echo "Error : incorrect value of first argument. Check usage!" | tee -a $LOG
		echo ""
		echo "usage : $ME backup|restore <archive_name> " | tee -a $LOG
		echo ""
		exit 1
	fi
	if [ $1 == "restore" ] && [ $# -lt 2 ]
	then
		echo "Error: incorrect argument for restore option!"
		echo ""
		echo "usage : $ME backup|restore <archive_name> " | tee -a $LOG
		echo ""
		exit 1
	fi
	
}

customer_bkp ()
{
	echo "============`date`==============" | tee -a $LOG
	cust_dir_list="/tmp/saved_list".$$
	files_to_be_saved="/tmp/files".$$
	big_cust_files="/tmp/big_filescust_data".$$
	cat <<-EOF > $cust_dir_list
/alcatel/var/home/axadmin/ 
/etc/hosts
/etc/resolv.conf
/etc/mail/sendmail.mc
/etc/sysconfig/sendmail
/etc/sysconfig/network-scripts/route-eth*
/etc/passwd 
/etc/group 
/etc/shadow
/var/spool/cron/
/alcatel/muse/MUSE_MAAT/hip/config/emailFilters.xml
/alcatel/muse/MUSE_MAAT/hip/config/mail.cfg
/alcatel/muse/MUSE_DASHBOARD/scripts/config/
/alcatel/support/
/root/
/etc/ntp.conf
/alcatel/muse/technologies/LTE/cacerts.trustStore
EOF

	if [ ! -d $script_dir ]
	then
		mkdir -p $script_dir
	fi
	if [ -f $files_to_be_saved ]
	then 
		rm $files_to_be_saved
	fi
	if [ -f $big_cust_files ]
	then
		rm $big_cust_files
	fi

	while read line
	do
		for f in `find $line`
		do
			if [ -d $f ]
			then
				echo "$f" >> $files_to_be_saved
			else
				if [ `du -k $f | awk '{print $1}'` -lt 102400 ]
				then
					echo "Adding $f to the backup list" | tee -a $LOG
					echo "$f" >> $files_to_be_saved
				else
					echo "Adding $f to the excluded list" | tee -a $LOG
					echo "$f" >> $big_cust_files
				fi
			fi
		done
	done < $cust_dir_list
	if  [ -f $big_cust_files ]
        then
                tar_opts="-X $big_cust_files"
        else
                tar_opts=""
        fi
        (cd $script_dir
	tar czvfp ${script_dir}/archive_`date '+%Y-%m-%d_%H-%M-%S'`.tar.gz ${tar_opts} -T ${files_to_be_saved}
	status=$?
	if [ $status -eq 0 ]
        then
        	echo "Backup has been performed successfully" | tee -a $LOG
        else
        	echo "Backup failed" | tee -a $LOG
        	exit 1
        fi
	)
	if [ -f $big_cust_files ]
	then
		echo "Warning: the following files are bigger than 100M; these files will be excluded from the backup!" | tee -a $LOG
		cat $big_cust_files | tee -a $LOG
	fi
	echo "The backup is saved in ${script_dir} directory " | tee -a $LOG

	rm -rf $cust_dir_list
	rm -rf $files_to_be_saved
    rm -rf $big_cust_files
}



restore_bkp()
{
	echo "============`date`==============" | tee -a $LOG
	exclude_list="/tmp/restore_exclude_files_$$"
	find /root/ | grep -v ".tcshrc$" | grep -v ".bashrc$" | sed 's/^\///g' >> $exclude_list 
	cat >> $exclude_list <<EOF
var/spool/cron/root
var/spool/cron/axadmin
var/spool/cron/oracle
EOF
 
	if [ -f ${script_dir}/$1 ]
	then
		(cd /
		tar xzvfp ${script_dir}/$1 -X $exclude_list -C / --overwrite
		status=$?
		if [ $status -eq 0 ]
		then
			echo "Restore has been performed successfully" | tee -a $LOG
			
		else
			echo "Restore failed" | tee -a $LOG
			exit 1
		fi
		)
				
	else
		echo "The restore archive does not exist!" | tee -a $LOG
		exit 1
	fi
	rm -rf $exclude_list

}

#######MAIN#########

	initialize $@ 
	if [ $1 == "backup" ]
	then 
		customer_bkp
	elif [ $1 == "restore" ]
	then
		customer_bkp
		restore_bkp $2
	fi
	exit 0
