#!/bin/ksh
#set -x

# Script to deinstall Oracle components: 

logfile=/alcatel/install/log/deinstall_Oracle_Components_`date '+%d-%m-%y:%H:%M'`.log
touch $logfile
chmod 777 $logfile

if [ ! -f /install/data/OMC_INSTALL ] && [ ! -f /install/data/OMC_INSTALL_1 ] && [ ! -f /install/data/OMC_INSTALL_2 ];then
	echo "/install/data/OMC_INSTALL file not found" | tee -a $logfile
	exit 1
fi

OMC_INSTALL_FILE=`ls -tr /install/data | grep OMC_INSTALL | tail -1`
. /install/data/${OMC_INSTALL_FILE}

ORACLE_HOME=$DB_HOME
echo "Oracle Home set to ${ORACLE_HOME}" | tee -a $logfile

if [ "${CLUSTER_ENABLED}" = "true" ]; then
	if [ "${CLUSTER_TYPE}" = "MASTER" ];then
        	ORACLE_SID=SNM1
	else
		echo "Not running on slave node" | tee -a $logfile
		exit 1
	fi
else
        ORACLE_SID=SNM
fi

echo "ORACLE_SID is ${ORACLE_SID}" | tee -a $logfile
echo "Starting deinstallation task at `date '+%d-%m-%y:%H:%M'`" | tee -a $logfile

su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog << EOF
spool $logfile append
connect / as sysdba
SET SERVEROUTPUT ON
@$ORACLE_HOME/ctx/admin/catnoctx.sql;
drop procedure sys.validate_context;
spool off
exit
EOF
"

echo "Ended deinstallation task at `date '+%d-%m-%y:%H:%M'`" | tee -a $logfile
