#!/bin/ksh

#        Create slave instance and add it to cluster
#        Last Update : 27.02.2007 
#        Author : Ciurea Cristian 

#set -x

SALVE_CONF="/install/data/slave.conf"

if [ -f $SALVE_CONF ]
        then . $SALVE_CONF
fi

cat >$1 <<!
ASM=$ASM
RAC=$RAC
CLUSTER_TYPE=$CLUSTER_TYPE
FLOATING_IP=$FLOATING_IP
MASTER_IP=$MASTER_IP
MASTER_PRIV=$MASTER_PRIV
MASTER_VIP=$MASTER_VIP
MASTER_HOSTNAME=$MASTER_HOSTNAME
CLUSTER_RECO=$CLUSTER_RECO
CLUSTER_TEMP=$CLUSTER_TEMP
CLUSTER_VOTE=$CLUSTER_VOTE
CLUSTER_OCR=$CLUSTER_OCR
CLUSTER_DATA=$CLUSTER_DATA
LOG_FILE=$LOG_FILE
RAC_DIR=$RAC_DIR
SLAVE_IP=$SLAVE_IP
SLAVE_HOSTNAME=$SLAVE_HOSTNAME
NODE_NUMBER=$NODE_NUMBER
DELIVERY_LOGIN=$DELIVERY_LOGIN
CRS_HOME=$CRS_HOME
ORACLE_HOME=$ORACLE_HOME
ORACLE_BASE=$ORACLE_BASE
DB_PASSWD=$DB_PASSWD
DB_NAME=$DB_NAME
SPFILE=$SPFILE
ASM_PASSWD=$ASM_PASSWD
!

echo "Start create_slave_instance.sh script `date`" | tee -a $LOG_FILE
echo "test slave number"
SLAVE_INSTANCE_NUMBER=${INSTANCE_NUMBER}

#delete ASM instances from SLAVE node
ssh $SLAVE_IP rm $ORACLE_HOME/dbs/*ASM*

#create directory structure for CLUSTER
ssh $SLAVE_IP mkdir -p /alcatel/oracle/admin/SNM
ssh $SLAVE_IP mkdir -p /alcatel/oracle/admin/SNM/cdump
ssh $SLAVE_IP mkdir -p /alcatel/oracle/admin/SNM/udump
ssh $SLAVE_IP mkdir -p /alcatel/oracle/admin/SNM/bdump
ssh $SLAVE_IP mkdir -p /alcatel/oracle/admin/SNM/adump
ssh $SLAVE_IP chmod 755 /alcatel/oracle
ssh $SLAVE_IP chmod +w /alcatel/install/log
ssh $SLAVE_IP chown -R oracle:oinstall /alcatel/oracle
ssh $SLAVE_IP mkdir -p /alcatel/temp/${DB_NAME}/flash_recovery_area
ssh $SLAVE_IP chown oracle:oinstall /alcatel/temp/${DB_NAME}/flash_recovery_area


#Create ASM log directories and password directories
su - oracle -c "
ssh $SLAVE_IP mkdir -p /opt/app/oracle/admin/asm/bdump
ssh $SLAVE_IP mkdir -p /opt/app/oracle/admin/asm/cdump
ssh $SLAVE_IP mkdir -p /opt/app/oracle/admin/asm/udump
ssh $SLAVE_IP $ORACLE_HOME/bin/orapwd file=$ORACLE_HOME/dbs/orapw+ASM$SLAVE_INSTANCE_NUMBER password=$ASM_PASSWD
"

#Create pfile for ASM instance
su - oracle -c "
cat > /var/tmp/init+ASM$SLAVE_INSTANCE_NUMBER.ora << EOT
*.background_dump_dest='/opt/app/oracle/admin/asm/bdump'
*.core_dump_dest='/opt/app/oracle/admin/asm/cdump'
*.remote_login_passwordfile='SHARED'
*.instance_type='asm'
*.large_pool_size=12M
*.user_dump_dest='/opt/app/oracle/admin/asm/udump'
cluster_database=true
+ASM$SLAVE_INSTANCE_NUMBER.instance_number=$SLAVE_INSTANCE_NUMBER
instance_number=$SLAVE_INSTANCE_NUMBER
EOT
"

#copy script to SLAVE node
su - oracle -c "scp /var/tmp/init+ASM$SLAVE_INSTANCE_NUMBER.ora $SLAVE_IP:$ORACLE_HOME/dbs/init+ASM$SLAVE_INSTANCE_NUMBER.ora"

#create ASM start-up script
TEMP_ASM=/var/tmp/asm.sh
SQL_LOG=/var/tmp/sql.log
echo "export ORACLE_HOME="$ORACLE_HOME > $TEMP_ASM
echo "export ORACLE_SID=+ASM"$SLAVE_INSTANCE_NUMBER >> $TEMP_ASM 
echo "export SQL_LOG="$SQL_LOG >> $TEMP_ASM
echo "export ASM_PASSWD="$ASM_PASSWD >> $TEMP_ASM
#create spfile from pfile
echo "\$ORACLE_HOME/bin/sqlplus /nolog <<- EOF" >> $TEMP_ASM
echo "spool \$SQL_LOG" >> $TEMP_ASM
echo "connect sys/\$ASM_PASSWD as sysdba" >> $TEMP_ASM
echo "create spfile from pfile;" >> $TEMP_ASM
echo "startup nomount" >> $TEMP_ASM
echo "disconnect" >> $TEMP_ASM
echo "spool off" >> $TEMP_ASM
echo "exit" >> $TEMP_ASM
echo "EOF"  >> $TEMP_ASM
#create diskgroups
#echo "\$ORACLE_HOME/bin/sqlplus /nolog <<- EOF" >> $TEMP_ASM
#echo "spool \$SQL_LOG" >> $TEMP_ASM
#echo "connect sys/\$ASM_PASSWD as sysdba" >> $TEMP_ASM
#echo "alter system set asm_diskstring='/dev/rdsk/*' scope=both;" >> $TEMP_ASM
#echo "alter system set asm_diskgroups='DATA','RECOVERY','FAILSAVE' scope=both;" >> $TEMP_ASM
#echo "disconnect" >> $TEMP_ASM
#echo "spool off" >> $TEMP_ASM
#echo "exit" >> $TEMP_ASM
#echo "EOF" >> $TEMP_ASM

#copy/run script to SLAVE
scp $TEMP_ASM $SLAVE_IP:$RAC_DIR
ssh $SLAVE_IP chown oracle:oinstall $RAC_DIR/asm.sh
su - oracle -c "ssh $SLAVE_IP ksh $RAC_DIR/asm.sh"

#get to MASTER log from script on SLAVE
scp $SLAVE_IP:$SQL_LOG /var/tmp/temp.log
cat /var/tmp/temp.log >> $LOG_FILE

#Update spfile on MASTER node
#In case of slave node
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

cat >$2 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
!
MASTER_INSTANCE_NUMBER=$INSTANCE_NUMBER

#create PFILE
PFILE=$SPFILE$DB_NAME$MASTER_INSTANCE_NUMBER.ora
su - oracle -c "
        export ORACLE_HOME=$ORACLE_HOME
        export ORACLE_SID=SNM$MASTER_INSTANCE_NUMBER
        #create spfile from pfile
        $ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile
        connect sys/$DB_PASSWD as sysdba

        create pfile='$PFILE' from spfile;

        disconnect
        spool off
        exit
EOF
"

#update spfile with right values
sed -e '/cluster_database_instances/d' $PFILE > $PFILE.indus  
echo "SNM$SLAVE_INSTANCE_NUMBER.instance_number=$SLAVE_INSTANCE_NUMBER" >> $PFILE.indus
echo "SNM$SLAVE_INSTANCE_NUMBER.thread=$SLAVE_INSTANCE_NUMBER" >> $PFILE.indus
echo "SNM$SLAVE_INSTANCE_NUMBER.undo_tablespace='UNDOTBS$SLAVE_INSTANCE_NUMBER'" >> $PFILE.indus
echo "cluster_database_instances=$SLAVE_INSTANCE_NUMBER"  >> $PFILE.indus

sleep 2
#start database with the new spfile
SQL_FILE=/var/tmp/sql.log
su - oracle -c "
        export ORACLE_HOME=$ORACLE_HOME
        export ORACLE_SID=SNM$MASTER_INSTANCE_NUMBER
        #create spfile from pfile
        $ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $SQL_FILE
        connect sys/$DB_PASSWD as sysdba

        alter database add logfile thread $SLAVE_INSTANCE_NUMBER ('+RECOVERY') size 1073741824;
        alter database add logfile thread $SLAVE_INSTANCE_NUMBER ('+RECOVERY') size 1073741824;
        alter database add logfile thread $SLAVE_INSTANCE_NUMBER ('+RECOVERY') size 1073741824;
        alter database enable public thread $SLAVE_INSTANCE_NUMBER;
        create undo tablespace undotbs$SLAVE_INSTANCE_NUMBER datafile '+DATA' size 170M autoextend on;

        disconnect
        spool off
        exit
EOF
sleep 10
$ORACLE_HOME/bin/srvctl stop database -d $DB_NAME
sleep 100
#$ORACLE_HOME/bin/srvctl start asm -n $MASTER_HOSTNAME

$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
        spool $SQL_FILE
        connect sys/$DB_PASSWD as sysdba

        create spfile='+DATA/SNM/spfileSNM.ora' from pfile='$PFILE.indus';

        disconnect
        spool off
        exit
EOF
"

#update log file
cat $SQL_FILE >> $LOG_FILE

#change old instance file
ssh $SLAVE_IP mv $ORACLE_HOME/dbs/init$DB_NAME$MASTER_INSTANCE_NUMBER.ora  $ORACLE_HOME/dbs/init$DB_NAME$SLAVE_INSTANCE_NUMBER.ora

#register instance and start it
su - oracle -c "
set -x
#$ORACLE_HOME/bin/srvctl add asm -n $SLAVE_HOSTNAME -i +ASM$SLAVE_INSTANCE_NUMBER -o $ORACLE_HOME
$ORACLE_HOME/bin/srvctl add instance -d $DB_NAME -i $DB_NAME$SLAVE_INSTANCE_NUMBER -n $SLAVE_HOSTNAME
$ORACLE_HOME/bin/srvctl modify instance -d $DB_NAME -i $DB_NAME$SLAVE_INSTANCE_NUMBER -s +ASM$SLAVE_INSTANCE_NUMBER
#$ORACLE_HOME/bin/srvctl enable asm -n $SLAVE_HOSTNAME -i +ASM$SLAVE_INSTANCE_NUMBER
$ORACLE_HOME/bin/srvctl stop db -d $DB_NAME
sleep 100
" | tee -a $LOG_FILE

OLS_NODES=$CRS_HOME/bin/olsnodes
nodes_list=`$OLS_NODES | grep -v $SLAVE_HOSTNAME`
node_number=0
for node_hostname in $nodes_list
do
	let node_number+=1
	su - oracle -c "
		echo "y" | $ORACLE_HOME/bin/srvctl remove instance -i $DB_NAME$node_number -d $DB_NAME
		$ORACLE_HOME/bin/srvctl add instance -d $DB_NAME -i $DB_NAME$node_number -n $node_hostname
		$ORACLE_HOME/bin/srvctl modify instance -d $DB_NAME -i $DB_NAME$node_number -s +ASM$node_number
	" | tee -a $LOG_FILE
done

su - oracle -c "
$ORACLE_HOME/bin/srvctl stop db -d $DB_NAME
sleep 100
$ORACLE_HOME/bin/srvctl start db -d $DB_NAME
" | tee -a $LOG_FILE

echo "Finish create_slave.sh script `date`" | tee -a $LOG_FILE

exit 0
