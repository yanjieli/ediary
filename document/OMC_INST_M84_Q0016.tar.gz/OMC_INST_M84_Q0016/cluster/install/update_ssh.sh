#!/bin/ksh
#set -x

orafile=/var/opt/oracle/oratab

id |grep root > /dev/null
id_err=`echo $?`

#test if machine is accesible
if [[ $id_err -eq 1 ]]
then
        echo "Script must be run as root user !!!"
        exit 1
fi

if [ -f $orafile ]
then
	CRS_HOME=`awk -F: '$1 ~/^\+ASM1$/ {print $2}' $orafile`
        export CRS_HOME
else
        echo "ERROR $orafile does not exists"
        exit 1
fi

if [[ x$1 != "x" ]]
then
        NEW_SLAVE=$1
else
        echo "Enter hostname of the NEW SLAVE node :"
        read NEW_SLAVE
fi

ping $NEW_SLAVE  > /dev/null
err=`echo $?`

#test if machine is accesible
if [[ $err -eq 1 ]]
then
        echo "SLAVE node $NEW_SLAVE not accesible !!!"
        exit 1
fi

#test ssh connection
ssh $NEW_SLAVE date > /dev/null
SSH_CON=`echo $?`

if [[ $SSH_CON -eq 1 ]]
then
        echo "SSH on SLAVE node $NEW_SLAVE not accesible !!!"
        exit 1
fi

SALVE_CONF=/install/data/slave.conf
OLS_NODE=$CRS_HOME/bin/olsnodes
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

nodelist=`$OLS_NODE`

nr=`echo "$nodelist" | wc -l`
if [ $nr -lt 2 ]
then
	echo "Less than 2 nodes no ssh configuration needed!"
	exit 0
fi 

for NODE in $nodelist
do
	REMOTE_SCRIPT_DIR=/var/tmp/sshscrit

	echo "\n--- Working on $NODE ---\n"
	echo "*** Adding $NEW_SLAVE to $NODE ***"
	
	if [ -f ../../unix/oracle/script.exp ]
	then
		cp ../../unix/oracle/script.exp /var/tmp/script.exp
	else
        	echo "ERROR: script.exp not found!"
	fi

        EXPR="s/__hostname__/${NEW_SLAVE}/g"
        /usr/bin/sed $EXPR /var/tmp/script.exp > /var/tmp/script.exp.slave

        #edit hostname on master
        if [ -f ../../unix/oracle/addhosts.sh ]
        then
                 cp ../../unix/oracle/addhosts.sh /var/tmp/addhosts.sh
        else
                 echo "ERROR: addhosts.sh not found!"
        fi

        EXPR1="s/__HOST_SLAVE__/${NEW_SLAVE}/g"
        HOST_SLAVE_IP=`awk '$2 ~ /^'"${NEW_SLAVE}"'$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
        EXPR2="s/__HOST_SLAVE_IP__/${HOST_SLAVE_IP}/g"
        HOST_SLAVE_VIP=`awk '$2 ~ /^'"${NEW_SLAVE}"'-vip$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
        EXPR3="s/__HOST_SLAVE_VIP__/${HOST_SLAVE_VIP}/g"
        HOST_SLAVE_PRIV=`awk '$2 ~ /^'"${NEW_SLAVE}"'-priv$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
        EXPR4="s/__HOST_SLAVE_PRIV__/${HOST_SLAVE_PRIV}/g"
        /usr/bin/sed -e $EXPR1 -e $EXPR2 -e $EXPR3 -e $EXPR4 /var/tmp/addhosts.sh > /var/tmp/addhosts.sh.slave

        ssh ${NODE} -l root mkdir -p $REMOTE_SCRIPT_DIR
        ssh ${NODE} -l root chmod +w $REMOTE_SCRIPT_DIR
        scp /var/tmp/addhosts.sh.slave ${NODE}:$REMOTE_SCRIPT_DIR
        #add slave hosts on existing node /etc/hosts
        echo "Add ${NEW_SLAVE} hosntame in $NODE /etc/hosts"
        ssh ${NODE} -l root chmod +x $REMOTE_SCRIPT_DIR/addhosts.sh.slave
        ssh ${NODE} -l root $REMOTE_SCRIPT_DIR/addhosts.sh.slave
        echo "Configure ssh on $NODE to connect to $NEW_SLAVE"
        scp /var/tmp/script.exp.slave ${NODE}:$REMOTE_SCRIPT_DIR
        ssh ${NODE} -l root chmod +x $REMOTE_SCRIPT_DIR/script.exp.slave
        ssh ${NODE} -l root $REMOTE_SCRIPT_DIR/script.exp.slave
        su - oracle -c "ssh ${NODE} -l oracle $REMOTE_SCRIPT_DIR/script.exp.slave"
	su - axadmin -c "ssh ${NODE} -l axadmin $REMOTE_SCRIPT_DIR/script.exp.slave"

	echo "*** Adding $NODE to $NEW_SLAVE ***" 
	
	 EXPR="s/__hostname__/${NODE}/g"
        /usr/bin/sed $EXPR /var/tmp/script.exp > /var/tmp/script.exp.slave2
	EXPR1="s/__HOST_SLAVE__/${NODE}/g"
        HOST_SLAVE_IP=`awk '$2 ~ /^'"${NODE}"'$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
        EXPR2="s/__HOST_SLAVE_IP__/${HOST_SLAVE_IP}/g"
        HOST_SLAVE_VIP=`awk '$2 ~ /^'"${NODE}"'-vip$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
        EXPR3="s/__HOST_SLAVE_VIP__/${HOST_SLAVE_VIP}/g"
        HOST_SLAVE_PRIV=`awk '$2 ~ /^'"${NODE}"'-priv$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
        EXPR4="s/__HOST_SLAVE_PRIV__/${HOST_SLAVE_PRIV}/g"
        /usr/bin/sed -e $EXPR1 -e $EXPR2 -e $EXPR3 -e $EXPR4 /var/tmp/addhosts.sh > /var/tmp/addhosts.sh.slave2

        ssh ${NEW_SLAVE} -l root mkdir -p $REMOTE_SCRIPT_DIR
        ssh ${NEW_SLAVE} -l root chmod +w $REMOTE_SCRIPT_DIR
        scp /var/tmp/addhosts.sh.slave2 ${NEW_SLAVE}:$REMOTE_SCRIPT_DIR
        #add slave hosts on existing node /etc/hosts
        echo "Add ${NODE} hosntame in $NEW_SLAVE /etc/hosts"
        ssh ${NEW_SLAVE} -l root chmod +x $REMOTE_SCRIPT_DIR/addhosts.sh.slave2
        ssh ${NEW_SLAVE} -l root $REMOTE_SCRIPT_DIR/addhosts.sh.slave2
        echo "Configure ssh on $NEW_SLAVE to connect to $NODE"
        scp /var/tmp/script.exp.slave2 ${NEW_SLAVE}:$REMOTE_SCRIPT_DIR
        ssh ${NEW_SLAVE} -l root chmod +x $REMOTE_SCRIPT_DIR/script.exp.slave2
        ssh ${NEW_SLAVE} -l root $REMOTE_SCRIPT_DIR/script.exp.slave2
        su - oracle -c "ssh ${NEW_SLAVE} -l oracle $REMOTE_SCRIPT_DIR/script.exp.slave2"
	su - axadmin -c "ssh ${NEW_SLAVE} -l axadmin $REMOTE_SCRIPT_DIR/script.exp.slave2"
done
