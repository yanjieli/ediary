#!/bin/ksh

#                     Add a  new storage to the cluster
#                     Last update: 05.09.2007
#                     Author : Ciurea Cristian
#set -x

orafile=/var/opt/oracle/oratab

usage()
{
        echo ""
        echo "USAGE: add_new_storage.sh /install/data/slave.conf" >&2
        echo ""
        exit 1
}

#Process arguments.
if [ $# != 1 ]
then
 usage;
 exit;
fi

slaveconf=$1;
if [ ! -f $slaveconf ]; then
        echo "No $slaveconf file present, please check the file path !"
        exit 1
fi

#Other setups
#check if scp is in path
SCP_PATCH=/usr/local/bin/scp
[ -f "$SCP_PATCH" ] || {
        echo "\n Create link for scp!" >&2
        ln -s /usr/bin/scp $SCP_PATCH
}

if [ -f $orafile ]
then
        ORACLE_HOME=`awk -F: '$1 ~/^SNM$/ {print $2}' $orafile`
        CRS_HOME=`awk -F: '$1 ~/^\+ASM1$/ {print $2}' $orafile`
        export ORACLE_HOME
        export CRS_HOME
else
        echo "ERROR $orafile does not exists"
        exit 1
fi

#cluster.conf
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi
cat >$2 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
!
MASTER_INSTANCE=$INSTANCE_NUMBER

#In case of slave node
if [ -f $slaveconf ]
	then . $slaveconf
fi

cat >$2 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
ASM_PASSWD=$ASM_PASSWD
CLUSTER_DATA=$CLUSTER_DATA
CLUSTER_RECO=$CLUSTER_RECO
CLUSTER_VOTE=$CLUSTER_VOTE
CLUSTER_VOTE2=$CLUSTER_VOTE2
CLUSTER_VOTE3=$CLUSTER_VOTE3
CLUSTER_OCR=$CLUSTER_OCR
DB_NAME=$DB_NAME
LOG_FILE=$LOG_FILE
!

ASM_SID=+ASM$MASTER_INSTANCE
ORACLE_SID=$DB_NAME$MASTER_INSTANCE

echo "Start add_new_storage.sh script `date`" | tee -a $LOG_FILE
if [[ -z $CLUSTER_DATA ]] || [[ -z $CLUSTER_RECO ]] ; then
        echo "No storage atached!!!" | tee -a $LOG_FILE
        exit 0 
fi

log="/tmp/log.txt"
[[ -f $log ]] && rm $log

#check if devices already exist in cluster
su - oracle -c "
	export ORACLE_SID=$ORACLE_SID
	echo 'SELECT PATH FROM v\$asm_disk where group_number='0';' > /var/tmp/asm.sql
	$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

	spool $log
	connect sys/orapower as sysdba
        SET SERVEROUTPUT ON;
	
	@/var/tmp/asm.sql	

	disconnect
	spool off
	exit
EOF
" >/var/tmp/disk_add.txt

cat $log >> $LOG_FILE

if [ -f /var/tmp/disk_add.sql ]
then
        rm /var/tmp/disk_add.sql
fi

#search after CLUSTER_DATA and CLUSTER_RECO
grep "$CLUSTER_DATA" /var/tmp/disk_add.txt >/dev/null 2>&1
if [ $? -ne 0 ] ;then
        echo "The $CLUSTER_DATA is already added!!!" | tee -a $LOG_FILE
else
	dd if=/dev/zero of=$CLUSTER_DATA bs=265289728 count=1
        echo "alter diskgroup DATA add disk '$CLUSTER_DATA';" >> /var/tmp/disk_add.sql
fi

grep "$CLUSTER_RECO" /var/tmp/disk_add.txt >/dev/null 2>&1
if [ $? -ne 0 ] ;then
        echo "The $CLUSTER_RECO is already added!!!" | tee -a $LOG_FILE
else
	dd if=/dev/zero of=$CLUSTER_RECO bs=265289728 count=1
        echo "alter diskgroup RECOVERY add disk '$CLUSTER_RECO';" >> /var/tmp/disk_add.sql
fi

failsavelist="CLUSTER_VOTE
                CLUSTER_VOTE2
                CLUSTER_VOTE3
                CLUSTER_OCR"

for device in $failsavelist
do
        eval rawdevice=\$$device
        grep "$rawdevice" /var/tmp/disk_add.txt >/dev/null 2>&1
        if [ $? -ne 0 ] ;then
                echo "The $rawdevice is already added!!!" | tee -a $LOG_FILE
        else
                echo "Adding $rawdevice to FAILSAVE diskgroup"
                dd if=/dev/zero of=$rawdevice bs=265289728 count=1
                echo "alter diskgroup FAILSAVE add disk '$rawdevice';" >> /var/tmp/disk_add.sql
        fi
done

#set oracle rights to all existing nodes/devices
nodelist=`$CRS_HOME/bin/olsnodes`
for node in $nodelist
do
	ssh $node chown oracle:dba /devices/scsi_vhci/*raw >/dev/null 2>&1 | tee -a $LOG_FILE
	ssh $node chmod 660 /devices/scsi_vhci/*raw >/dev/null 2>&1 | tee -a $LOG_FILE
done

#set oracle rights to new node/devices
ssh $SLAVE_IP chown oracle:dba /devices/scsi_vhci/*raw >/dev/null 2>&1 | tee -a $LOG_FILE
ssh $SLAVE_IP chmod 660 /devices/scsi_vhci/*raw >/dev/null 2>&1 | tee -a $LOG_FILE

if [ ! -f /var/tmp/disk_add.sql ]
then
	echo "DATA and RECOVERY disks already added!"
	exit 0
fi

sleep 10

log="/tmp/log.txt"
[[ -f $log ]] && rm $log

set -x

su - oracle -c "
. ~/.grid_profile
export ORACLE_SID=$ASM_SID
#create diskgroups
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
spool $log
connect / as sysasm

@/var/tmp/disk_add.sql

disconnect
spool off
exit
EOF
"

cat $log >> $LOG_FILE

echo "Finish add_new_storage.sh script `date`" | tee -a $LOG_FILE
