#!/bin/ksh

#        Script that add a new node in a cluster

#set -x

HOSTNAME=`hostname`
LHOSTNAME=`echo $HOSTNAME | tr '[A-Z]' '[a-z]'`
cwd=`pwd`
ORACLE_USER=oracle
LOG_FILE=/alcatel/install/log
SALVE_CONF=/install/data/slave.conf
RAC_DIR=/var/tmp/racscript
ORACLE_INV=/opt/app/oracle/oraInventory
ORA_HOME=/alcatel/var/home/oracle
ORACLE_BASE=/opt/app/oracle
GRID_BASE=/opt/app/grid
ORACLE_INVLOC=$ORACLE_BASE/oraInventory
TMP_PATCH=/tmp/patch_cluster.sh
ASM_PASSWD=Asmpower1
DB_PASSWD=orapower
DB_NAME=SNM
SPFILE=/var/tmp/initSNM1.ora
DELIVERY_LOGIN=oracle
orafile=/var/opt/oracle/oratab

id |grep root > /dev/null
id_err=`echo $?`

#test if machine is accesible
if [[ $id_err -eq 1 ]]
then
        echo "Script must be run as root user !!!"
        exit 1
fi

if [ -f $orafile ]
then
        ORACLE_HOME=`awk -F: '$1 ~/^SNM$/ {print $2}' $orafile`
	CRS_HOME=`awk -F: '$1 ~/^\+ASM1$/ {print $2}' $orafile`
        export ORACLE_HOME
	export CRS_HOME
else
        echo "ERROR $orafile does not exists" 
	exit 1
fi

OLS_NODE=$CRS_HOME/bin/olsnodes

echo
echo
echo "Enter hostname of the SLAVE node :"
read SLAVE_HOSTNAME
echo
echo

#check if the node was already added to the cluster configuration
nodelist=`$OLS_NODE`
if [ `echo "$nodelist" | grep $SLAVE_HOSTNAME` ] 
then 
	echo "ERROR: $SLAVE_HOSTNAME is already a cluster node."
	exit 1
fi

#test if machine is accesible
ping $SLAVE_HOSTNAME > /dev/null
if [[ $? -ne 0 ]]
then
	echo "SLAVE node $SLAVE_HOSTNAME not accesible !!!"
	exit 1
fi

#test ssh connection
su - oracle -c "ssh -l$ORACLE_USER $SLAVE_HOSTNAME date > /dev/null"
if [[ $? -ne 0 ]]
then
        echo "SSH on SLAVE node $SLAVE_HOSTNAME not accesible !!!"
        exit 1
fi

#copy cluster.conf from SLAVE to MASTER
#create slave.conf on MASTER node - information about SLAVE node
if [ -f $SALVE_CONF ]
then
	rm -fr $SALVE_CONF
fi

scp root@$SLAVE_HOSTNAME:/install/data/cluster.conf $SALVE_CONF 
SLAVE_IP=`awk '$2 ~ /^'"${SLAVE_HOSTNAME}"'$/ && $1 !~ /^#/ {print $1}' /etc/hosts`

echo "SLAVE hostname: $SLAVE_HOSTNAME" 
echo "SLAVE public IP: $SLAVE_IP"

echo "Do you want to continue? [y/n]"
read answer
case $answer in
            Y|y|Yes|yes|YES)    ;;
            *)                  exit;;
esac

LOG_FILE=$LOG_FILE/$SLAVE_HOSTNAME`date '+_%d_%m_%y__%H-%M-%S'`.log
NODE_NUMBER=`$OLS_NODE| wc -l | tr -d " "`

echo "Start ADD NODE procedure for $SLAVE_HOSTNAME `date`" | tee $LOG_FILE
chmod 777 $LOG_FILE

resourcelist="ora.scan1.vip
                ora.LISTENER_SCAN1.lsnr
                ora.cvu
                ora.oc4j"

for res in $resourcelist
do
        echo "Relocating resource $res to $LHOSTNAME" | tee $LOG_FILE
        $CRS_HOME/bin/crsctl modify resource $res -attr HOSTING_MEMBERS=$LHOSTNAME
done

if [ -f /SECURITY/ALUipf/scripts/ipf_command.sh ]
then
	echo "Disabeling IP filter on Master" | tee $LOG_FILE
	/SECURITY/ALUipf/scripts/ipf_command.sh -d
fi

if [ -f /etc/rc3.d/S90ipfilter ]
then
	echo "Renaming /etc/rc3.d/S90ipfilter"
	mv /etc/rc3.d/S90ipfilter /etc/rc3.d/_S90ipfilter
fi

#update slave conf with some varible
echo "LOG_FILE="$LOG_FILE >> $SALVE_CONF
echo "RAC_DIR="$RAC_DIR >> $SALVE_CONF
echo "SLAVE_IP="$SLAVE_IP >> $SALVE_CONF
echo "ORACLE_INVLOC="$ORACLE_INVLOC >> $SALVE_CONF
echo "ORACLE_INV="$ORACLE_INV >> $SALVE_CONF
echo "ORACLE_HOME="$ORACLE_HOME >> $SALVE_CONF
echo "ORA_HOME="$ORA_HOME >> $SALVE_CONF
echo "ORACLE_BASE="$ORACLE_BASE >> $SALVE_CONF
echo "GRID_BASE="$GRID_BASE >> $SALVE_CONF
echo "SLAVE_HOSTNAME="$SLAVE_HOSTNAME >> $SALVE_CONF
echo "NODE_NUMBER="$NODE_NUMBER >> $SALVE_CONF
echo "DELIVERY_LOGIN="$DELIVERY_LOGIN >> $SALVE_CONF
echo "CRS_HOME="$CRS_HOME >> $SALVE_CONF
echo "TMP_PATCH="$TMP_PATCH >> $SALVE_CONF
echo "DB_PASSWD="$DB_PASSWD  >> $SALVE_CONF
echo "DB_NAME="$DB_NAME  >> $SALVE_CONF
echo "SPFILE="$SPFILE  >> $SALVE_CONF
echo "ASM_PASSWD="$ASM_PASSWD >> $SALVE_CONF

#create script directory on SLAVE node
echo " Create $RAC_DIR on SLAVE node" | tee -a $LOG_FILE
ssh $SLAVE_HOSTNAME mkdir -p $RAC_DIR 
ssh $SLAVE_HOSTNAME chmod 777 $RAC_DIR

echo "Finish to update $SALVE_CONF" | tee -a $LOG_FILE
echo ""
echo "Run add_new_storage.sh script"
echo "====================================================================="
cd $cwd
ksh add_new_storage.sh $SALVE_CONF
RET=$?
if [[ $RET -eq 1 ]]
then
        echo "Script add_new_storage.sh FAILED !!! EXIT FROM SCRIPT !!!!"
        exit 1
fi
echo "====================================================================="

echo ""
echo "Run copy_node.sh script"
echo "====================================================================="
cd $cwd
ksh copy_node.sh
RET=$?
if [[ $RET -eq 1 ]]
then
        echo "Script copy_node.sh FAILED !!! EXIT FROM SCRIPT !!!!"
        exit 1
fi
echo "====================================================================="

echo ""
echo "Run create_slave_instance.sh script"
echo "====================================================================="
cd $cwd
ksh create_slave_instance.sh
RET=$?
if [[ $RET -eq 1 ]]
then
        echo "Script create_slave_instance.sh FAILED !!! EXIT FROM SCRIPT !!!!"
        exit 1
fi
echo "====================================================================="

echo "Finish ADD NODE procedure for $SLAVE_HOSTNAME `date`" | tee -a $LOG_FILE
#echo $?
#echo $SSH_CON
#echo $err
