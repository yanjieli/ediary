#!/bin/ksh

#        Script that add a new node in a cluster
#        Last Update : 08.02.2007 
#        Author : Ciurea Cristian 

#set -x

SALVE_CONF="/install/data/slave.conf"

if [ -f $SALVE_CONF ]
        then . $SALVE_CONF
fi

cat >$1 <<!
ASM=$ASM
RAC=$RAC
CLUSTER_TYPE=$CLUSTER_TYPE
INSTANCE_NUMBER=$INSTANCE_NUMBER
FLOATING_IP=$FLOATING_IP
MASTER_IP=$MASTER_IP
MASTER_PRIV=$MASTER_PRIV
MASTER_VIP=$MASTER_VIP
MASTER_HOSTNAME=$MASTER_HOSTNAME
CLUSTER_RECO=$CLUSTER_RECO
CLUSTER_TEMP=$CLUSTER_TEMP
CLUSTER_VOTE=$CLUSTER_VOTE
CLUSTER_OCR=$CLUSTER_OCR
CLUSTER_DATA=$CLUSTER_DATA
LOG_FILE=$LOG_FILE
RAC_DIR=$RAC_DIR
SLAVE_IP=$SLAVE_IP
SLAVE_HOSTNAME=$SLAVE_HOSTNAME
NODE_NUMBER=$NODE_NUMBER
DELIVERY_LOGIN=$DELIVERY_LOGIN
CRS_HOME=$CRS_HOME
ORACLE_HOME=$ORACLE_HOME
ORACLE_BASE=$ORACLE_BASE
GRID_BASE=$GRID_BASE
!

echo "Start copy_node.sh script `date`!!!" | tee -a $LOG_FILE

#create oracle base directory
ssh $SLAVE_IP mkdir -p $ORACLE_BASE | tee -a $LOG_FILE
ssh $SLAVE_IP chown oracle:oinstall $ORACLE_BASE | tee -a $LOG_FILE
ssh $SLAVE_IP chmod +w $ORACLE_BASE | tee -a $LOG_FILE

#create grid base directory
ssh $SLAVE_IP mkdir -p $GRID_BASE | tee -a $LOG_FILE
ssh $SLAVE_IP chown oracle:oinstall $GRID_BASE | tee -a $LOG_FILE
ssh $SLAVE_IP chmod +w $GRID_BASE | tee -a $LOG_FILE

#create link file
TEMP_FILE="/var/tmp/link.sh"
echo "#!/bin/ksh" > $TEMP_FILE
echo "SCP_PATCH=/usr/local/bin/scp" >> $TEMP_FILE
echo "[ -f \"\$SCP_PATCH\" ] || {" >> $TEMP_FILE
echo "echo \"Create link for scp!\" >&2" >> $TEMP_FILE
echo "ln -s /usr/bin/scp \$SCP_PATCH" >> $TEMP_FILE
echo "}" >> $TEMP_FILE

echo "Copy link script to slave node" | tee -a $LOG_FILE
scp $TEMP_FILE $SLAVE_IP:$RAC_DIR
ssh $SLAVE_IP chmod +x $RAC_DIR/link.sh
ssh $SLAVE_IP $RAC_DIR/link.sh

echo "Creating Oracle .profile file on SLAVE node" | tee -a $LOG_FILE
PROFILE_FILE="/var/tmp/profile"
cat <<- ! > $PROFILE_FILE
umask 022
CRS_HOME=$CRS_HOME
ORACLE_BASE=$ORACLE_BASE ; export ORACLE_BASE
ORACLE_HOME=$ORACLE_HOME ; export ORACLE_HOME
LD_LIBRARY_PATH=$ORACLE_HOME/lib; export LD_LIBRARY_PATH
CLASSPATH=$ORACLE_HOME/jdk/jre/lib:$ORACLE_HOME/jlib; export CLASSPATH
ORACLE_NLS33=$ORACLE_HOME/ocommon/nls/admin/data; export ORACLE_NLS33
NLS_LANG=american_america.US7ASCII; export NLS_LANG
PATH=$ORACLE_HOME/bin:/usr/bin:/bin; export PATH
/usr/bin/newtask -p oracle_proj -c \$\$
PS1="oracle@$SLAVE_HOSTNAME:\$PWD $ "; export PS1
!

scp $PROFILE_FILE $SLAVE_IP:/alcatel/var/home/oracle/.profile
ssh $SLAVE_IP "chown oracle:oinstall /alcatel/var/home/oracle/.profile; chmod +r /alcatel/var/home/oracle/.profile; chmod 777 /opt/app"
echo "Copy Oracle .grid_profile file to SLAVE node" | tee -a $LOG_FILE
sed -e "s/ASM1/ASM2/" /alcatel/var/home/oracle/.grid_profile > /var/tmp/grid_profile.slave
scp /var/tmp/grid_profile.slave  $SLAVE_IP:/alcatel/var/home/oracle/.grid_profile
ssh $SLAVE_IP "chown oracle:oinstall /alcatel/var/home/oracle/.grid_profile" 

#Lauch oracle 
NODE_NAME=$SLAVE_HOSTNAME
PRIV_NODE_NAME=$NODE_NAME-priv
VIP_NODE_NAME=$NODE_NAME-vip
MASTER_HOST_NAME=$MASTER_HOSTNAME

#run CRS add node command
TEMP_CRS=/var/tmp/crs.sh
echo "cd $CRS_HOME/oui/bin" > $TEMP_CRS
echo "NODE_NAME="$NODE_NAME >> $TEMP_CRS
echo "PRIV_NODE_NAME="$PRIV_NODE_NAME >> $TEMP_CRS
echo "VIP_NODE_NAME="$VIP_NODE_NAME >> $TEMP_CRS
echo "CRS_HOME="$CRS_HOME >> $TEMP_CRS
echo "IGNORE_PREADDNODE_CHECKS=Y" >> $TEMP_CRS
echo "export IGNORE_PREADDNODE_CHECKS" >> $TEMP_CRS
echo "\$CRS_HOME/oui/bin/addNode.sh -silent \"CLUSTER_NEW_NODES={\$NODE_NAME}\" \"CLUSTER_NEW_VIRTUAL_HOSTNAMES={\$VIP_NODE_NAME}\"" >> $TEMP_CRS
chmod +x $TEMP_CRS

su - oracle -c "sh $TEMP_CRS" | tee -a $LOG_FILE

#check install logs
logfile=`ls -t1 $ORACLE_INVLOC/logs/add* | head -n 1`
grep "failed" $logfile >/dev/null 2>&1
if [ $? -eq 0 ] ;then
        echo "#!/bin/ksh" > $TMP_PATCH
        echo "#Patch CRS_NODE in case of addNode.sh errors!" >> $TMP_PATCH
        echo CRS_HOME=$CRS_HOME >> $TMP_PATCH
        echo MASTER_HOST_NAME=$MASTER_HOST_NAME >> $TMP_PATCH
        echo ORACLE_INVLOC=$ORACLE_INVLOC >> $TMP_PATCH
        echo NODE_NAME=$NODE_NAME >> $TMP_PATCH
        echo cd $CRS_HOME/oui/bin/ >> $TMP_PATCH
fi

grep "'AttachHome' failed" $logfile >/dev/null 2>&1
failed_status=$?
if [ $? -eq 0 ] ;then
	echo "$CRS_HOME/oui/bin/runInstaller -attachHome -noClusterEnabled ORACLE_HOME=$CRS_HOME ORACLE_HOME_NAME=OraClusterware11ghome1 CLUSTER_NODES=$MASTER_HOST_NAME,$NODE_NAME CRS=true  INVENTORY_LOCATION=$ORACLE_INVLOC LOCAL_NODE=$NODE_NAME -silent" >> $TMP_PATCH
fi 

grep "'UpdateNodeList' failed" $logfile >/dev/null 2>&1
if [ $? -eq 0 ] ;then
	echo "$CRS_HOME/oui/bin/runInstaller -updateNodeList -noClusterEnabled ORACLE_HOME=$CRS_HOME CLUSTER_NODES=$MASTER_HOST_NAME,$NODE_NAME CRS=true INVENTORY_LOCATION=$ORACLE_INVLOC LOCAL_NODE=$NODE_NAME -silent" >> $TMP_PATCH
fi

if [ $failed_status -eq 0 ] ;then
       	 #run patch script
	su - oracle -c "sh $TMP_PATCH" 
fi 


#update ora inventory
echo " Running $ORACLE_INV/orainstRoot.sh on $SLAVE_IP" | tee -a $LOG_FILE
ssh $SLAVE_IP $ORACLE_INV/orainstRoot.sh | tee -a $LOG_FILE

#run script rootaddnode.sh on MASTER node (with patch)
#cd $CRS_HOME/install
#$CRS_HOME/crs/utl/rootaddnode.sh | tee -a $LOG_FILE

#run root.sh  on Slave node
echo " Running $CRS_HOME/root.sh on $SLAVE_IP" | tee -a $LOG_FILE
ssh $SLAVE_IP "mkdir -p /alcatel/oracle/admin/+ASM1; chown oracle:oinstall /alcatel/oracle/admin/+ASM1"
ssh $SLAVE_IP "cd $CRS_HOME; ./root.sh" | tee -a $LOG_FILE

#check if root.sh was successfull
NRNODES=`$CRS_HOME/bin/olsnodes | wc -l`
if [ $NRNODES -eq 2 ]
then
	echo "Cluster contains 2 nodes now - OK" | tee -a $LOG_FILE
else
	echo "Deconfigure grid on SLAVE node" | tee -a $LOG_FILE
	ssh $SLAVE_IP $CRS_HOME/crs/install/roothas.pl -deconfig -force -verbose | tee -a $LOG_FILE 
	echo " Running again $CRS_HOME/root.sh on $SLAVE_IP" | tee -a $LOG_FILE
	ssh $SLAVE_IP "cd $CRS_HOME; ./root.sh" | tee -a $LOG_FILE
fi

#run addNode for data 
TEMP_DATA=/var/tmp/data.sh
echo "NODE_NAME="$NODE_NAME > $TEMP_DATA
echo "ORACLE_HOME="$ORACLE_HOME >> $TEMP_DATA
echo "cd $ORACLE_HOME/oui/bin" >> $TEMP_DATA
echo "IGNORE_PREADDNODE_CHECKS=Y" >> $TEMP_CRS
echo "export IGNORE_PREADDNODE_CHECKS" >> $TEMP_CRS
echo "\$ORACLE_HOME/oui/bin/addNode.sh -silent \"CLUSTER_NEW_NODES={\$NODE_NAME}\"" >> $TEMP_DATA
chmod +x $TEMP_DATA

su - oracle -c "sh $TEMP_DATA" | tee -a $LOG_FILE

#check install logs
logfile=`ls -t1 $ORACLE_INVLOC/logs/add* | head -n 1`
grep "failed" $logfile >/dev/null 2>&1
failed_status=$?
if [ $? -eq 0 ] ;then
        echo "#!/bin/ksh" > $TMP_PATCH
        echo "#Patch CRS_NODE in case of addNode.sh errors!" >> $TMP_PATCH
        echo ORACLE_INVLOC=$ORACLE_INVLOC >> $TMP_PATCH
        echo ORACLE_HOME=$ORACLE_HOME >> $TMP_PATCH
        echo MASTER_HOST_NAME=$MASTER_HOST_NAME >> $TMP_PATCH
        echo NODE_NAME=$NODE_NAME >> $TMP_PATCH
        echo cd $ORACLE_HOME/oui/bin/ >> $TMP_PATCH
fi

grep "'AttachHome' failed" $logfile >/dev/null 2>&1
if [ $? -eq 0 ] ;then
	echo '$ORACLE_HOME/oui/bin/runInstaller -attachHome -noClusterEnabled ORACLE_HOME=$ORACLE_HOME ORACLE_HOME_NAME=ORACLE_HOME2 CLUSTER_NODES=$MASTER_HOST_NAME,$NODE_NAME "INVENTORY_LOCATION=$ORACLE_INVLOC" LOCAL_NODE=$NODE_NAME -silent' >> $TMP_PATCH
fi

grep "'UpdateNodeList' failed" $logfile >/dev/null 2>&1
if [ $? -eq 0 ] ;then
	echo '$ORACLE_HOME/oui/bin/runInstaller -updateNodeList -noClusterEnabled ORACLE_HOME=$ORACLE_HOME CLUSTER_NODES=$MASTER_HOST_NAME,$NODE_NAME CRS=false "INVENTORY_LOCATION=$ORACLE_INVLOC" LOCAL_NODE=$NODE_NAME -silent' >> $TMP_PATCH
fi

if [ $failed_status -eq 0 ] ;then
	#run  path script
	su - oracle -c "sh $TMP_PATCH"
fi

#update ora inventory
#ssh $SLAVE_IP $ORACLE_INV/orainstRoot.sh | tee -a $LOG_FILE

#run root.sh  on Slave node
bfile="root.sh"
file="$ORACLE_HOME/$bfile"

echo "Running configuration script ($file)" | tee -a $LOG_FILE
[[ -f "$file" ]] || {
        echo "\nERROR: $file not found. The installation of $patchname failed!" >&2
        exit 1
}

ssh $SLAVE_IP $file <<- ! > $ORACLE_INVLOC/logs/$bfile.$SLAVE_HOSTNAME.out 2>$ORACLE_INVLOC/logs/$bfile.$SLAVE_HOSTNAME.err

! | tee -a $LOG_FILE

status=$?
scp $ORACLE_INVLOC/logs/$bfile.$SLAVE_HOSTNAME.out $SLAVE_IP:$ORACLE_INVLOC/logs/
scp $ORACLE_INVLOC/logs/$bfile.$SLAVE_HOSTNAME.err $SLAVE_IP:$ORACLE_INVLOC/logs/

if [ "$status" -ne 0 ]; then
        echo "\nERROR: Configuration script $bfile failed!" >&2
        echo "         Please check logs in $ORACLE_INVLOC/logs directory for more details." >&2
fi

if [ ! -h ${ORACLE_HOME}/dbs/orapwSNM${INSTANCE_NUMBER} ]
then
	su - oracle "
		ln -s ${ORACLE_HOME}/dbs/orapwSNM ${DB_HOME}/dbs/orapwSNM${INSTANCE_NUMBER}
	"
fi

vipfile="config_private_vip.sh"
TEMP_DIR="/var/tmp"
echo "Running $vipfile" | tee -a $LOG_FILE
scp ../../unix/oracle/$vipfile $SLAVE_IP:$TEMP_DIR/
ssh $SLAVE_IP $TEMP_DIR/$vipfile | tee -a $LOG_FILE

echo "Finish copy_node.sh script `date`" | tee -a $LOG_FILE
