#!/bin/ksh
#                     Remove node from the cluster
#                     Last update: 09.04.2008
#                     Author : Mocan Cristina

#set -x

ORACLE_USER=oracle
LOGFILE=/alcatel/install/log
SLAVE_CONF=/install/data/slave.conf
RAC_DIR=/var/tmp/racscript
ORACLE_INV=/opt/app/oracle/oraInventory
ORA_HOME=/alcatel/var/home/oracle
ORACLE_BASE=/opt/app/oracle
OLS_NODE=$CRS_HOME/bin/olsnodes
ORACLE_INVLOC=$ORACLE_BASE/oraInventory
ASM_PASSWD=asmpower
DB_PASSWD=orapower
DB_NAME=SNM
SPFILE=/var/tmp/initSNM1.ora
DELIVERY_LOGIN=oracle
ASM_PASSWD=asmpower
orafile=/var/opt/oracle/oratab


id |grep root > /dev/null
id_err=`echo $?`

#test if user is root 
if [[ $id_err -eq 1 ]]
then
        echo "Script must be run as root user !!!"
        exit 1
fi

if [ -f $orafile ]
then
        ORACLE_HOME=`awk -F: '$1 ~/^SNM$/ {print $2}' $orafile`
        CRS_HOME=`awk -F: '$1 ~/^\+ASM1$/ {print $2}' $orafile`
        export ORACLE_HOME
        export CRS_HOME
else
        echo "ERROR $orafile does not exists"
        exit 1
fi

echo
echo
echo "Enter IP public address of the SLAVE node :"
read ip
echo
echo

ping $ip  > /dev/null
err=`echo $?`

#test if machine is accesible
if [[ $err -eq 1 ]]
then
        echo "SLAVE node $ip not accesible !!!"
        exit 1
fi

#test ssh connection
su - oracle -c "ssh -l $ORACLE_USER $ip date > /dev/null"
if [[ $? -ne 0 ]]
then
        echo "SSH on SLAVE node $ip not accesible !!!"
        exit 1
fi

echo ""
echo "Do you want to continue with the remove of SLAVE node? \c"
read answer
case $answer in
	Y|y|Yes|yes|YES)    ;;
	*)                  exit;;
esac

#copy cluster.conf from SLAVE to MASTER
#create slave.conf on MASTER node - information about SLAVE node
if [ -f $SLAVE_CONF ]; then
	rm -fr $SLAVE_CONF
fi

SLAVE_HOSTNAME=`ssh $ip hostname`
LOGFILE=$LOGFILE/remove_node.$SLAVE_HOSTNAME`date '+_%d_%m_%y__%H-%M-%S'`.log

echo "Note: Remove actions will be logged in the $LOGFILE file\n";
echo "=======Starting remove node procedure for $SLAVE_HOSTNAME `date`=======" | tee $LOGFILE
scp root@$ip:/install/data/cluster.conf $SLAVE_CONF

echo "LOGFILE="$LOGFILE >> $SLAVE_CONF
echo "RAC_DIR="$RAC_DIR >> $SLAVE_CONF
echo "SLAVE_IP="$ip >> $SLAVE_CONF
echo "ORACLE_INVLOC="$ORACLE_INVLOC >> $SLAVE_CONF
echo "ORACLE_INV="$ORACLE_INV >> $SLAVE_CONF
echo "ORACLE_HOME="$ORACLE_HOME >> $SLAVE_CONF
echo "ORA_HOME="$ORA_HOME >> $SLAVE_CONF
echo "ORACLE_BASE="$ORACLE_BASE >> $SLAVE_CONF
echo "SLAVE_HOSTNAME="$SLAVE_HOSTNAME >> $SLAVE_CONF
echo "DELIVERY_LOGIN="$DELIVERY_LOGIN >> $SLAVE_CONF
echo "CRS_HOME="$CRS_HOME >> $SLAVE_CONF
echo "DB_PASSWD="$DB_PASSWD  >> $SLAVE_CONF
echo "DB_NAME="$DB_NAME  >> $SLAVE_CONF
echo "SPFILE="$SPFILE  >> $SLAVE_CONF
echo "ASM_PASSWD="$ASM_PASSWD >> $SLAVE_CONF

echo "SLAVE:"
if [ -f $SLAVE_CONF ]
        then . $SLAVE_CONF
fi

cat >$1 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
SLAVE_IP=$SLAVE_IP
!
SLAVE_INSTANCE_NUMBER=$INSTANCE_NUMBER

echo "MASTER:"
#cluster.conf
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi
cat >$2 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
!
MASTER_INSTANCE=$INSTANCE_NUMBER

#Stop db and remove SNM and ASM instance
su - oracle -c "
	$ORACLE_HOME/bin/srvctl stop database -d $DB_NAME
	sleep 100
	echo "y" | $ORACLE_HOME/bin/srvctl remove instance -i $DB_NAME$SLAVE_INSTANCE_NUMBER -d $DB_NAME
	$ORACLE_HOME/bin/srvctl stop asm -n $SLAVE_HOSTNAME
	sleep 20
	echo "y" | $ORACLE_HOME/bin/srvctl remove asm -n $SLAVE_HOSTNAME
" | tee -a $LOGFILE

export ORACLE_HOME=$ORACLE_HOME 
export CRS_HOME=$CRS_HOME
ssh $SLAVE_IP "export ORACLE_HOME=$ORACLE_HOME; $ORACLE_HOME/bin/srvctl stop nodeapps -n $SLAVE_HOSTNAME" | tee -a $LOGFILE
ssh $SLAVE_IP "export ORACLE_HOME=$ORACLE_HOME; echo y | $ORACLE_HOME/bin/srvctl remove nodeapps -n $SLAVE_HOSTNAME" | tee -a $LOGFILE

OLS_NODES=$CRS_HOME/bin/olsnodes
nodes_list=`$OLS_NODES | grep -v $SLAVE_HOSTNAME`
nodenumber=`$OLS_NODES -n | grep $SLAVE_HOSTNAME | cut -f2`

list=""
checkfirst=0
for node_hostname in $nodes_list
do
	if [ $checkfirst -eq 1 ]; then
		list=$list","$node_hostname
	else
		checkfirst=1
		list=$node_hostname
	fi
done

for node_hostname in $nodes_list
do
	su - oracle -c "
	ssh $node_hostname $ORACLE_HOME/oui/bin/runInstaller.sh -silent -updateNodeList ORACLE_HOME="$ORACLE_HOME" "CLUSTER_NODES={$list}" -local LOCAL_NODE="$node_hostname"
	"
done

ssh $SLAVE_IP $CRS_HOME/install/rootdeletenode.sh local nosharedvar nosharedhome

ssh $SLAVE_IP $CRS_HOME/bin/crsctl stop crs >/dev/null 2>&1

for node_hostname in $nodes_list
do
        ssh $node_hostname $CRS_HOME/bin/crsctl stop crs >/dev/null 2>&1
        sleep 20
        ssh $node_hostname $CRS_HOME/bin/crsctl start crs | tee -a $LOGFILE
        sleep 40
done


##Perform rootdeletenode.sh on which remaining node
$CRS_HOME/install/rootdeletenode.sh $SLAVE_HOSTNAME,$nodenumber | tee -a $LOGFILE

for node_hostname in $nodes_list
do
	su - oracle -c "
	ssh $node_hostname $CRS_HOME/oui/bin/runInstaller.sh -silent -updateNodeList ORACLE_HOME="$CRS_HOME" "CLUSTER_NODES={$list}" -local CRS=TRUE LOCAL_NODE="$node_hostname"
	"
done

for node_hostname in $nodes_list
do
	ssh $node_hostname $CRS_HOME/bin/crsctl stop crs >/dev/null 2>&1
	sleep 20
	ssh $node_hostname $CRS_HOME/bin/crsctl start crs | tee -a $LOGFILE
	sleep 40
done

su - oracle -c "
        $ORACLE_HOME/bin/srvctl start database -d $DB_NAME >/dev/null 2>&1
        sleep 100
" | tee -a $LOGFILE

#Remove file from slave node
ssh $SLAVE_IP rm -rf $ORACLE_HOME 
ssh $SLAVE_IP rm -rf $CRS_HOME

ssh $SLAVE_IP rm -f /etc/init.d/init.cssd
ssh $SLAVE_IP rm -f /etc/init.d/init.crs
ssh $SLAVE_IP rm -f /etc/init.d/init.crsd
ssh $SLAVE_IP rm -f /etc/init.d/init.evmd 
ssh $SLAVE_IP rm -f /etc/rc2.d/K96init.crs
ssh $SLAVE_IP rm -f /etc/rc2.d/S96init.crs
ssh $SLAVE_IP rm -f /etc/rc3.d/K96init.crs
ssh $SLAVE_IP rm -f /etc/rc3.d/S96init.crs
ssh $SLAVE_IP rm -f /etc/rc5.d/K96init.crs
ssh $SLAVE_IP rm -f /etc/rc5.d/S96init.crs
ssh $SLAVE_IP rm -rf /var/opt/oracle/scls_scr

ssh $SLAVE_IP rm -rf /var/opt/oracle/
ssh $SLAVE_IP rm -rf /opt/app/oracle/oraInventory
ssh $SLAVE_IP rm -f /usr/local/bin/coraenv
ssh $SLAVE_IP rm -f /usr/local/bin/dbhome
ssh $SLAVE_IP rm -f /usr/local/bin/oraenv

#Remove from inittab
echo "Remove from /etc/inittab"
wfile="/etc/inittab"
ssh $SLAVE_IP cp -p $wfile $wfile.backup
EXPR1="/init.ohasd/d"
ssh $SLAVE_IP "/usr/bin/sed -e $EXPR1 $wfile.backup > /etc/inittab"
ssh $SLAVE_IP init q

#restart
su - oracle -c "
	$ORACLE_HOME/bin/srvctl stop database -d $DB_NAME
	sleep 100
" | tee -a $LOGFILE

for node_hostname in $nodes_list
do
	su - oracle -c "
		$ORACLE_HOME/bin/srvctl stop asm -n $node_hostname
		sleep 20
		$ORACLE_HOME/bin/srvctl stop nodeapps -n $node_hostname
		sleep 20
	" | tee -a $LOGFILE
done

for node_hostname in $nodes_list
do
	su - oracle -c "
		$ORACLE_HOME/bin/srvctl start nodeapps -n $node_hostname
		sleep 20
		$ORACLE_HOME/bin/srvctl start asm -n $node_hostname
		sleep 20
	" | tee -a $LOGFILE
done

su - oracle -c "
	$ORACLE_HOME/bin/srvctl start database -d $DB_NAME
	sleep 100
" | tee -a $LOGFILE

#Drop tablespace
su - oracle -c "
export ORACLE_SID=${DB_NAME}${MASTER_INSTANCE}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
        DROP TABLESPACE UNDOTBS${SLAVE_INSTANCE_NUMBER} INCLUDING CONTENTS AND DATAFILES;
        ALTER DATABASE DISABLE THREAD ${SLAVE_INSTANCE_NUMBER};

        disconnect
        exit
EOF
" | tee -a $LOGFILE

export ORACLE_HOME=$ORACLE_HOME
export ORACLE_SID=$DB_NAME

file="/tmp/drop_redolog.sql"
log="/tmp/drop_redolog.txt"

[[ -f $file ]] && rm $file
[[ -f $log ]] && rm $log

echo "SET SERVEROUTPUT ON;" >> $file
echo "DECLARE" >> $file
           echo "x number;" >> $file
           echo "y number;" >> $file
           echo "V_sql_1 varchar2(300);" >> $file
           echo "V_sql_2 varchar2(300);" >> $file

echo "BEGIN" >> $file
	   echo "FOR x IN (SELECT GROUP# FROM v\$log WHERE THREAD#=${SLAVE_INSTANCE_NUMBER} AND ARCHIVED LIKE 'NO')" >> $file
	   echo "LOOP" >> $file
		echo "V_sql_1 := 'ALTER SYSTEM ARCHIVE LOG GROUP ' || x.GROUP#;" >> $file
                echo "execute immediate V_sql_1;"  >> $file
           echo "END LOOP;" >> $file	
           echo "FOR y IN (SELECT GROUP# FROM v\$log WHERE THREAD#=${SLAVE_INSTANCE_NUMBER})" >> $file
           echo "LOOP" >> $file
                echo "V_sql_2 := 'ALTER DATABASE DROP LOGFILE GROUP ' || y.GROUP#;" >> $file
                echo "execute immediate V_sql_2;"  >> $file
           echo "END LOOP;" >> $file
echo "end;" >> $file
echo "/" >> $file

su - oracle -c "
export ORACLE_SID=${DB_NAME}${MASTER_INSTANCE}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

        spool $log

        @/tmp/drop_redolog.sql

        disconnect
        spool off
        exit
EOF
"
cat $log >> $LOGFILE

echo "=======Finish remove node procedure for $SLAVE_HOSTNAME `date`=======" | tee -a $LOGFILE
exit 0
