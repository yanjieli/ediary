#!/bin/ksh
dirlist="admin/SNM/bdump\
        admin/SNM/cdump\
        admin/SNM/create\
        admin/SNM/flash_recovery_area\
        admin/SNM/pfile\
        admin/SNM/udump\
        admin/SNM/adump\
        oradata/SNM/arch\
        oradata/migration/move"

for d in $dirlist
do
        if [ ! -d /alcatel/oracle/$d ]
        then
                echo "Creating directory /alcatel/oracle/$d"
                mkdir -p /alcatel/oracle/$d
        fi
done

chown -R oracle:oinstall /alcatel/oracle/admin
chown -R oracle:oinstall /alcatel/oracle/oradata
