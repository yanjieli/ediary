#!/bin/ksh
#**********************************************************
#This script must be used in case of full restore on SAN Cluster configuration
#Main tasks: restore OCR and VOTING disks
#	     replace old OCR and VOTING disks devices with the new ones
#	     create RECOVERY and DATA diskgroups
#Prerequisites: CD1+CD2S+CD2P installed on Master and Slave
#		first part of the restore performed on Master and Slave
#		SSH is configured
#It must be started as root user on Master
#**********************************************************

cluster_conf=/install/data/cluster.conf
old_cluster_conf=/install/data/cluster.conf.backup
datetime=`date '+%Y%m%d_%H%M%S'`
logfile=/alcatel/pre_restore.log_$datetime
ORACLE_HOME=/opt/app/oracle/product/10.2.0; export ORACLE_HOME
export CRS_HOME=/opt/app/oracle/crs
date > $logfile

rename () {

 if [ -c $NEW_CLUSTER_VOTE ] && [ $renameVOTE -eq 1 ]
 then
	echo "Link $NEW_CLUSTER_VOTE -> $CLUSTER_VOTE" | tee -a $logfile
        ln -s  $NEW_CLUSTER_VOTE $CLUSTER_VOTE 
	ssh $nodeIP ln -s  $NEW_CLUSTER_VOTE $CLUSTER_VOTE
 else
        echo "ERROR $NEW_CLUSTER_VOTE not found " | tee -a $logfile
 fi

 if [ -c $NEW_CLUSTER_VOTE2 ] && [ $renameVOTE2-eq 1 ]
 then
        echo "Link $NEW_CLUSTER_VOTE2 -> $CLUSTER_VOTE2" | tee -a $logfile
        ln -s  $NEW_CLUSTER_VOTE2 $CLUSTER_VOTE2
        ssh $nodeIP ln -s  $NEW_CLUSTER_VOTE2 $CLUSTER_VOTE2
 else
        echo "ERROR $NEW_CLUSTER_VOTE2 not found" | tee -a $logfile
 fi
 
 if [ -c $NEW_CLUSTER_VOTE3 ] && [ $renameVOTE3 -eq 1 ]
 then
        echo "Link $NEW_CLUSTER_VOTE3 -> $CLUSTER_VOTE3" | tee -a $logfile
        ln -s  $NEW_CLUSTER_VOTE3 $CLUSTER_VOTE3
        ssh $nodeIP ln -s  $NEW_CLUSTER_VOTE3 $CLUSTER_VOTE3
 else
        echo "ERROR $NEW_CLUSTER_VOTE3 not found" | tee -a $logfile
 fi

 if [ -c $NEW_CLUSTER_OCR ] && [ $renameOCR -eq 1 ]
 then
	echo "Link $NEW_CLUSTER_OCR -> $CLUSTER_OCR" | tee -a $logfile
	ln -s $NEW_CLUSTER_OCR $CLUSTER_OCR
	ssh $nodeIP ln -s $NEW_CLUSTER_OCR $CLUSTER_OCR
 else
        echo "ERROR $NEW_CLUSTER_OCR not found " | tee -a $logfile
 fi

 if [ -c $NEW_CLUSTER_OCR2 ] && [ $renameOCR2 -eq 1 ]
 then
        echo "Link $NEW_CLUSTER_OCR2 -> $CLUSTER_OCR2" | tee -a $logfile
        ln -s $NEW_CLUSTER_OCR2 $CLUSTER_OCR2
        ssh $nodeIP ln -s $NEW_CLUSTER_OCR2 $CLUSTER_OCR2
 else
        echo "ERROR $NEW_CLUSTER_OCR not found " | tee -a $logfile
 fi

}

SAN=0
#read new cluster.conf
if [ -f $cluster_conf ]
then
	. $cluster_conf
else
	echo "ERROR : $cluster_conf not found" | tee -a $logfile
	exit 1 
fi

if [ $SAN -eq 1 ]
then
        echo "ERROR this script is not for resotore on SAN configuration"
        exit 1
fi

MY_TYPE=$CLUSTER_TYPE

NEW_CLUSTER_RECO=$CLUSTER_RECO
NEW_CLUSTER_VOTE=$CLUSTER_VOTE
NEW_CLUSTER_OCR=$CLUSTER_OCR
NEW_CLUSTER_OCR2=$CLUSTER_OCR2
NEW_CLUSTER_DATA=$CLUSTER_DATA
NEW_CLUSTER_VOTE2=$CLUSTER_VOTE2
NEW_CLUSTER_VOTE3=$CLUSTER_VOTE3

#read old cluster.conf
if [ -f $old_cluster_conf ]
then
        . $old_cluster_conf
else
        echo "ERROR : $old_cluster_conf not found" | tee -a $logfile
        exit 1
fi

#check if devices on SAN are the same like before backup
renameVOTE=1
if [ $NEW_CLUSTER_VOTE = $CLUSTER_VOTE ] ; then
	renameVOTE=0
fi
renameVOTE2=1
if [ $NEW_CLUSTER_VOTE2 = $CLUSTER_VOTE2 ] ; then
        renameVOTE2=0
fi
renameVOTE3=1
if [ $NEW_CLUSTER_VOTE3 = $CLUSTER_VOTE3 ] ; then
        renameVOTE3=0
fi
renameOCR=1
if [ $NEW_CLUSTER_OCR = $CLUSTER_OCR ] ; then
	renameOCR=0
fi
renameOCR2=1
if [ $NEW_CLUSTER_OCR2 = $CLUSTER_OCR2 ] ; then
        renameOCR2=0
fi

echo "Give public IP of the Slave node:"
read nodeIP

rename

chown oracle:dba /devices/scsi_vhci/*raw
ssh $nodeIP chown oracle:dba /devices/scsi_vhci/*raw
chmod 660 /devices/scsi_vhci/*raw
ssh $nodeIP chmod 660 /devices/scsi_vhci/*raw

#first step restore OCR disk
#restore OCR DISK done for Master and Slave OCR
. ${old_cluster_conf}
echo "Restoring OCR disk $CLUSTER_OCR" | tee -a $logfile
/usr/bin/dd if=/opt/app/oracle/crs/cdata/ocr_backup of=$CLUSTER_OCR bs=65536
$CRS_HOME/bin/crsctl query  css votedisk
#restore OCR2
echo "Restoring OCR2 disk $CLUSTER_OCR2" | tee -a $logfile
/usr/bin/dd if=/opt/app/oracle/crs/cdata/ocr_backup of=$CLUSTER_OCR2 bs=65536

#stop CRS on all nodes
for nodename in `$CRS_HOME/bin/olsnodes`
do
        echo "Stop CRS on node: $nodename"
        ssh $nodename $CRS_HOME/bin/crsctl stop crs
done
sleep 10

#restore Voting disk from Master node
	filename=`basename $CLUSTER_VOTE`
	echo "Restoring VOTE disk ${filename}" | tee -a $logfile
	/usr/bin/dd if=/opt/app/oracle/crs/cdata/${filename} of=$CLUSTER_VOTE bs=65536
	filename=`basename $CLUSTER_VOTE2`
       	echo "Restoring VOTE2 disk ${filename}" | tee -a $logfile
       	/usr/bin/dd if=/opt/app/oracle/crs/cdata/${filename} of=$CLUSTER_VOTE2 bs=65536
	filename=`basename $CLUSTER_VOTE3`
        echo "Restoring VOTE3 disk ${filename}" | tee -a $logfile
        /usr/bin/dd if=/opt/app/oracle/crs/cdata/${filename} of=$CLUSTER_VOTE3 bs=65536

echo "Restore of old OCR and voting disks done" | tee -a $logfile
$CRS_HOME/bin/ocrcheck | tee -a $logfile

#add new VOTE devices and delete the old ones
. ${cluster_conf}
if [ $renameVOTE -eq 1 ] ; then
	echo "Add Master new voting disk $CLUSTER_VOTE" | tee -a $logfile
	$CRS_HOME/bin/crsctl add css votedisk $CLUSTER_VOTE -force
fi
if [ $renameVOTE2 -eq 1 ] ; then
	echo "Add Master new voting disk $CLUSTER_VOTE2" | tee -a $logfile
	$CRS_HOME/bin/crsctl add css votedisk $CLUSTER_VOTE2 -force
fi
if [ $renameVOTE3 -eq 1 ] ; then
	echo "Add Master new voting disk $CLUSTER_VOTE3" | tee -a $logfile
	$CRS_HOME/bin/crsctl add css votedisk $CLUSTER_VOTE3 -force
fi

$CRS_HOME/bin/crsctl query  css votedisk | tee -a $logfile

. ${old_cluster_conf}
if [ $renameVOTE -eq 1 ] ; then
	echo "Delete Master old voting disk $CLUSTER_VOTE" | tee -a $logfile
	$CRS_HOME/bin/crsctl delete css votedisk $CLUSTER_VOTE -force
fi
if [ $renameVOTE2 -eq 1 ] ; then
	echo "Delete Master old voting disk $CLUSTER_VOTE2" | tee -a $logfile
	$CRS_HOME/bin/crsctl delete css votedisk $CLUSTER_VOTE2 -force
fi
if [ $renameVOTE3 -eq 1 ] ; then
	echo "Delete Master old voting disk $CLUSTER_VOTE3" | tee -a $logfile
	$CRS_HOME/bin/crsctl delete css votedisk $CLUSTER_VOTE3 -force
fi

$CRS_HOME/bin/crsctl query  css votedisk | tee -a $logfile

#crs must be started now on all nodes
for nodename in `$CRS_HOME/bin/olsnodes`
do
	echo "Starting CRS on node: $nodename" | tee -a $logfile
	ssh $nodename $CRS_HOME/bin/crsctl start crs
done
sleep 200

$CRS_HOME/bin/crs_stat -t | tee -a $logfile

#OCR replacement with new device, crs must be running
existingOCR=`$CRS_HOME/bin/ocrcheck | awk -F: '/rdsk/ {print $2}'`

#add the other OCR disk as ocrmirror
if [ $existingOCR = $CLUSTER_OCR2 ]
then
	. ${cluster_conf}
	$CRS_HOME/bin/ocrconfig -replace ocrmirror $CLUSTER_OCR
else
	. ${cluster_conf}
	$CRS_HOME/bin/ocrconfig -replace ocrmirror $CLUSTER_OCR2
fi
$CRS_HOME/bin/ocrcheck | tee -a $logfile
sleep 10
#replace first OCR disk
$CRS_HOME/bin/ocrconfig -replace ocr
$CRS_HOME/bin/ocrcheck | tee -a $logfile

#use new devices for DATA and RECO
. ${cluster_conf}
export INSTANCE=${INSTANCE_NUMBER}
echo "INSTANCE = $INSTANCE"

echo " Create DATA and RECO diskgroups from Master" | tee -a $logfile
cat << ! > /var/tmp/master_asm_restore.sql
alter system set asm_diskstring = '/dev/rdsk/*' scope=both;
alter system set asm_diskgroups = 'DATA', 'RECOVERY' scope=both;
create diskgroup DATA external redundancy disk '$CLUSTER_DATA';
create diskgroup RECOVERY external redundancy disk '$CLUSTER_RECO';
!
	su - oracle -c "
	export ORACLE_SID=+ASM${INSTANCE}
	$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

        @/var/tmp/master_asm_restore.sql

        disconnect
        exit
EOF
	$ORACLE_HOME/bin/asmcmd <<- EOF
        cd RECOVERY
        mkdir SNM
        cd SNM
        mkdir arch
	lsdg
        exit
EOF
"

./make_directories.sh | tee -a $logfile
scp make_directories.sh $nodeIP:/var/tmp/
ssh $nodeIP /var/tmp/make_directories.sh

for nodename in `$CRS_HOME/bin/olsnodes`
do
	su - oracle -c "
	$ORACLE_HOME/bin/srvctl stop asm -n $nodename
	sleep 15
	$ORACLE_HOME/bin/srvctl start asm -n $nodename
	$ORACLE_HOME/bin/srvctl start nodeapps -n $nodename
	"
done

