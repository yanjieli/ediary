#!/bin/ksh
#**********************************************************
#This script must be used in case of full restore on Cluster configuration
#Main tasks: restore OCR and VOTING disks
#	     replace old OCR and VOTING disks devices with the new ones
#	     create RECOVERY and DATA diskgroups
#Prerequisites: CD1+CD2S+CD2P installed on Master and Slave
#		first part of the restore performed on Master and Slave
#		SSH is configured
#It must be started as root user on Master
#**********************************************************

cluster_conf=/install/data/cluster.conf
old_cluster_conf=/install/data/cluster.conf.backup
datetime=`date '+%Y%m%d_%H%M%S'`
logfile=/alcatel/pre_restore.log_$datetime
ORACLE_HOME=/opt/app/oracle/product/10.2.0; export ORACLE_HOME
export CRS_HOME=/opt/app/oracle/crs
date > $logfile

rename () {

 if [ -c $NEW_CLUSTER_VOTE ]
 then
	echo "Link $NEW_CLUSTER_VOTE -> $CLUSTER_VOTE" | tee -a $logfile
        ln -s  $NEW_CLUSTER_VOTE $CLUSTER_VOTE 
	ssh $nodeIP ln -s  $NEW_CLUSTER_VOTE $CLUSTER_VOTE
 else
        echo "ERROR $NEW_CLUSTER_VOTE not found " | tee -a $logfile
 fi

 if [ -c $NEW_CLUSTER_VOTE2 ]
 then
        echo "Link $NEW_CLUSTER_VOTE2 -> $CLUSTER_VOTE2" | tee -a $logfile
        ln -s  $NEW_CLUSTER_VOTE2 $CLUSTER_VOTE2
        ssh $nodeIP ln -s  $NEW_CLUSTER_VOTE2 $CLUSTER_VOTE2
 else
        echo "ERROR $NEW_CLUSTER_VOTE2 not found" | tee -a $logfile
 fi

 if [ -c $NEW_CLUSTER_OCR ]
 then
	echo "Link $NEW_CLUSTER_OCR -> $CLUSTER_OCR" | tee -a $logfile
	ln -s $NEW_CLUSTER_OCR $CLUSTER_OCR
	ssh $nodeIP ln -s $NEW_CLUSTER_OCR $CLUSTER_OCR
 else
        echo "ERROR $NEW_CLUSTER_OCR not found " | tee -a $logfile
 fi

}

#get cluster.conf files from the Slave node
echo "Give public IP of the Slave node:"
read nodeIP
scp $nodeIP:$cluster_conf ${cluster_conf}_other
scp $nodeIP:$old_cluster_conf ${old_cluster_conf}_other

SAN=0
#read new cluster.conf
if [ -f $cluster_conf ]
then
	. $cluster_conf
else
	echo "ERROR : $cluster_conf not found" | tee -a $logfile
	exit 1 
fi

if [ $SAN -eq 1 ]
then
        echo "ERROR this script is not for resotore on SAN configuration"
        exit 1
fi

MY_TYPE=$CLUSTER_TYPE

NEW_CLUSTER_RECO=$CLUSTER_RECO
NEW_CLUSTER_VOTE=$CLUSTER_VOTE
NEW_CLUSTER_OCR=$CLUSTER_OCR
NEW_CLUSTER_DATA=$CLUSTER_DATA
if [ "x$CLUSTER_VOTE2" != "x" ]
then
	NEW_CLUSTER_VOTE2=$CLUSTER_VOTE2
else
	NEW_CLUSTER_VOTE2=0
fi

#read old cluster.conf
if [ -f $old_cluster_conf ]
then
        . $old_cluster_conf
else
        echo "ERROR : $old_cluster_conf not found" | tee -a $logfile
        exit 1
fi

rename

#read slave new cluster.conf
if [ -f ${cluster_conf}_other ]
then
        . ${cluster_conf}_other
else
        echo "ERROR : ${cluster_conf}_other not found" | tee -a $logfile
        exit 1
fi

NEW_CLUSTER_RECO=$CLUSTER_RECO
NEW_CLUSTER_VOTE=$CLUSTER_VOTE
NEW_CLUSTER_OCR=$CLUSTER_OCR
NEW_CLUSTER_DATA=$CLUSTER_DATA
if [ "x$CLUSTER_VOTE2" != "x" ]
then
        NEW_CLUSTER_VOTE2=$CLUSTER_VOTE2
else
        NEW_CLUSTER_VOTE2=0
fi

#read slave old cluster.conf
if [ -f ${old_cluster_conf}_other ]
then
        . ${old_cluster_conf}_other
else
        echo "ERROR : ${old_cluster_conf}_other not found" | tee -a $logfile
        exit 1
fi

rename

chown oracle:dba /devices/scsi_vhci/*raw
ssh $nodeIP chown oracle:dba /devices/scsi_vhci/*raw
chmod 660 /devices/scsi_vhci/*raw
ssh $nodeIP chmod 660 /devices/scsi_vhci/*raw

#first step restore OCR disk
#restore OCR DISK done for Master and Slave OCR
. ${old_cluster_conf}
echo "Restoring OCR disk $CLUSTER_OCR" | tee -a $logfile
/usr/bin/dd if=/opt/app/oracle/crs/cdata/ocr_backup of=$CLUSTER_OCR bs=65536
$CRS_HOME/bin/crsctl query  css votedisk
#restore Slave OCR
. ${old_cluster_conf}_other
echo "Restoring OCR disk $CLUSTER_OCR" | tee -a $logfile
/usr/bin/dd if=/opt/app/oracle/crs/cdata/ocr_backup of=$CLUSTER_OCR bs=65536

#stop CRS on all nodes
for nodename in `$CRS_HOME/bin/olsnodes`
do
        echo "Stop CRS on node: $nodename"
        ssh $nodename $CRS_HOME/bin/crsctl stop crs
done
sleep 10

#restore Voting disk from Slave node
	filename=`basename $CLUSTER_VOTE`
	echo "Restoring VOTE disk ${filename}" | tee -a $logfile
	/usr/bin/dd if=/opt/app/oracle/crs/cdata/${filename} of=$CLUSTER_VOTE bs=65536
	if [ "x$CLUSTER_VOTE2" != "x" ] ; then
		filename=`basename $CLUSTER_VOTE2`
        	echo "Restoring VOTE2 disk ${filename}" | tee -a $logfile
        	/usr/bin/dd if=/opt/app/oracle/crs/cdata/${filename} of=$CLUSTER_VOTE2 bs=65536
	fi

#source backup cluster conf to get OCR and VOTE disks
. ${old_cluster_conf}

#restore Voting disk from Master node
	filename=`basename $CLUSTER_VOTE`
	echo "Restoring VOTE disk ${filename}" | tee -a $logfile
	/usr/bin/dd if=/opt/app/oracle/crs/cdata/${filename} of=$CLUSTER_VOTE bs=65536
	if [ "x$CLUSTER_VOTE2" != "x" ] ; then
		filename=`basename $CLUSTER_VOTE2`
        	echo "Restoring VOTE2 disk ${filename}" | tee -a $logfile
        	/usr/bin/dd if=/opt/app/oracle/crs/cdata/${filename} of=$CLUSTER_VOTE2 bs=65536
	fi

echo "Restore of old OCR and voting disks done" | tee -a $logfile
$CRS_HOME/bin/ocrcheck | tee -a $logfile

#add new VOTE devices and delete the old ones
. ${cluster_conf}
echo "Add Master new voting disk $CLUSTER_VOTE" | tee -a $logfile
$CRS_HOME/bin/crsctl add css votedisk $CLUSTER_VOTE -force
if [ "x$CLUSTER_VOTE2" != "x" ] ; then
	echo "Add Master new voting disk $CLUSTER_VOTE2" | tee -a $logfile
	$CRS_HOME/bin/crsctl add css votedisk $CLUSTER_VOTE2 -force
fi

. ${cluster_conf}_other
#add the Slave voting disk
echo "Add Slave new voting disk $CLUSTER_VOTE" | tee -a $logfile
$CRS_HOME/bin/crsctl add css votedisk $CLUSTER_VOTE -force
if [ "x$CLUSTER_VOTE2" != "x" ] ; then
	echo "Add Slave new voting disk $CLUSTER_VOTE2" | tee -a $logfile
	$CRS_HOME/bin/crsctl add css votedisk $CLUSTER_VOTE2 -force
fi

$CRS_HOME/bin/crsctl query  css votedisk | tee -a $logfile

. ${old_cluster_conf}
echo "Delete Master old voting disk $CLUSTER_VOTE" | tee -a $logfile
$CRS_HOME/bin/crsctl delete css votedisk $CLUSTER_VOTE -force
if [ "x$CLUSTER_VOTE2" != "x" ] ; then
	echo "Delete Master old voting disk $CLUSTER_VOTE2" | tee -a $logfile
	$CRS_HOME/bin/crsctl delete css votedisk $CLUSTER_VOTE2 -force
fi

. ${old_cluster_conf}_other
echo "Delete Slave old voting disk $CLUSTER_VOTE" | tee -a $logfile
$CRS_HOME/bin/crsctl delete css votedisk $CLUSTER_VOTE -force
if [ "x$CLUSTER_VOTE2" != "x" ] ; then
	echo "Delete Slave old voting disk $CLUSTER_VOTE2" | tee -a $logfile
	$CRS_HOME/bin/crsctl delete css votedisk $CLUSTER_VOTE2 -force
fi

$CRS_HOME/bin/crsctl query  css votedisk | tee -a $logfile

#crs must be started now on all nodes
for nodename in `$CRS_HOME/bin/olsnodes`
do
	echo "Starting CRS on node: $nodename" | tee -a $logfile
	ssh $nodename $CRS_HOME/bin/crsctl start crs
done
sleep 200

$CRS_HOME/bin/crs_stat -t | tee -a $logfile

#OCR replacement with new device, crs must be running
existingOCR=`$CRS_HOME/bin/ocrcheck | awk -F: '/rdsk/ {print $2}'`
if [ `grep $existingOCR ${old_cluster_conf} 2>/dev/null` ]
then
	. ${cluster_conf}_other
else
	. ${cluster_conf}
fi

#add the other OCR disk as ocrmirror
$CRS_HOME/bin/ocrconfig -replace ocrmirror $CLUSTER_OCR
$CRS_HOME/bin/ocrcheck | tee -a $logfile
sleep 10
#replace first OCR disk
$CRS_HOME/bin/ocrconfig -replace ocr
$CRS_HOME/bin/ocrcheck | tee -a $logfile

#use new devices for DATA and RECO
. ${cluster_conf}
export INSTANCE=${INSTANCE_NUMBER}
echo "INSTANCE = $INSTANCE"

echo " Create DATA and RECO diskgroups from Master" | tee -a $logfile
cat << ! > /var/tmp/master_asm_restore.sql
alter system set asm_diskstring = '/dev/rdsk/*' scope=both;
alter system set asm_diskgroups = 'DATA', 'RECOVERY' scope=both;
create diskgroup DATA external redundancy disk '$CLUSTER_DATA';
create diskgroup RECOVERY external redundancy disk '$CLUSTER_RECO';
!
	su - oracle -c "
	export ORACLE_SID=+ASM${INSTANCE}
	$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

        @/var/tmp/master_asm_restore.sql

        disconnect
        exit
EOF
	$ORACLE_HOME/bin/asmcmd <<- EOF
        cd RECOVERY
        mkdir SNM
        cd SNM
        mkdir arch
	lsdg
        exit
EOF
"

#use new Slave devices for DATA and RECO
echo "Add Slave DATE and RECO to the diskgroups" | tee -a $logfile
. ${cluster_conf}_other
cat << ! > /var/tmp/slave_asm_restore.sql
alter diskgroup DATA add disk '$CLUSTER_DATA';
alter diskgroup RECOVERY add disk '$CLUSTER_RECO';
!
su - oracle -c "
        export ORACLE_SID=+ASM${INSTANCE}
        $ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

        @/var/tmp/slave_asm_restore.sql

        disconnect
        exit
EOF
"

./make_directories.sh | tee -a $logfile
scp make_directories.sh $nodeIP:/var/tmp/
ssh $nodeIP /var/tmp/make_directories.sh

for nodename in `$CRS_HOME/bin/olsnodes`
do
	su - oracle -c "
	$ORACLE_HOME/bin/srvctl stop asm -n $nodename
	sleep 15
	$ORACLE_HOME/bin/srvctl start asm -n $nodename
	$ORACLE_HOME/bin/srvctl start nodeapps -n $nodename
	"
done

