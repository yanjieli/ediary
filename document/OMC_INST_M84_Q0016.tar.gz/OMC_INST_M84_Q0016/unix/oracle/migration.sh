#!/bin/ksh
#
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
#	Oracle MIGRATION
#	for Linux RedHat (x86)
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
#  January  2016 A.D.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

#set -x
new_oracle_ver=11.2.0.4
logfile=/alcatel/install/log/migration_to_${new_oracle_ver}.log_`date '+%d-%m-%y:%H:%M'`
tmpfile=/tmp/tmp_$(basename $0).$$
if [ -f $tmpfile ]; then
	rm -f $tmpfile
fi
touch $tmpfile

pe_migfile="/var/tmp/migration_traces.log"
printf "\n\-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n"	>> $pe_migfile
printf " %-15s : %s\n"	"Script"		"$0 $*"					>> $pe_migfile
printf " %-15s : %s\n"	"Start of script"	"$(date '+%Y/%m/%d %H:%M:%S')"		>> $pe_migfile
printf "\-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n"	>> $pe_migfile
id -a		>> $pe_migfile
df -h		>> $pe_migfile

{

function_initialize() {

scr_location=$(dirname $0)

INSTALL_LIB_DIR="${scr_location}/../lib"
install_file="${INSTALL_LIB_DIR}/install.sh"

        if [ ! -f $install_file ];then
                echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR [INSTALL]: $install_file file not found" >&2
				echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR [INSTALL]: $install_file file not found" >> $tmpfile
                exit 1
        fi
. $install_file

oratab_file=/etc/oratab
if [ -f $oratab_file ]; then
    ORACLE_HOME_OLD=`awk -F: '$1 ~/^SNM$/ {print $2}' $oratab_file`
	old_ora_version=`awk -F: '$1 ~/^SNM$/ {print $2}' $oratab_file | sed -e "s#.*product/##"`
	log_message "INFO" "Found Oracle version : $old_ora_version" 
fi

export PATH=/bin:/usr/bin:/usr/sbin:/usr/openwin/bin
export ORACLE_BASE=/opt/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/$new_oracle_ver
export GRID_CRS_HOME=/opt/app/grid/$new_oracle_ver
export GRID_HOME=/opt/app/oracle/grid/$new_oracle_ver
export ORACLE_INVLOC=$ORACLE_BASE/oraInventory
new_ver=`echo ${new_oracle_ver} | sed 's/\.//g'`
file="/alcatel/var/home/oracle/.profile"
oracle_profile="/alcatel/var/home/oracle/.profile_${new_ver}"
CURR_DIR=`pwd`

#cluster parameter read
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
else
	log_message "ERROR" "Cannot find /install/data/cluster.conf file !"
	echo "ERROR Cannot find /install/data/cluster.conf file !" >> $tmpfile
	exit 1
fi
export ASM
export RAC


if [ ! -f $oratab_file ]; then
	log_message "ERROR" "$oratab_file file is missing. Migration can not be performed " 
	echo "ERROR  $oratab_file file is missing. Migration can not be performed " >> $tmpfile
	exit 1
else
	if [ -d $ORACLE_HOME_OLD ]; then
		egrep "$ORACLE_HOME" $oratab_file >/dev/null 2>&1
		check_migr=$?
		if [[ $check_migr -eq 1 ]]; then
			if [ -d $ORACLE_HOME ]; then
				log_message "INFO" "===Starting migration to ${new_oracle_ver} ===" 
			else
				log_message "ERROR" "Oracle ${new_oracle_ver} is NOT installed on this machine. Please check... ===" 
				echo "ERROR Oracle ${new_oracle_ver} is NOT installed on this machine. Please check... ===" >> $tmpfile
				exit 1
			fi
		else
			log_message "INFO" "Migration to ${new_oracle_ver} was already performed on this machine " 
			exit 0
		fi	
	fi
fi	 

DB_NAME=`grep $ORACLE_HOME_OLD: $oratab_file | cut -f1 -d ':'`

}

function_create_oracle_profile() {
#Create oracle .profile for 11.
log_message "INFO" "Creating Oracle .profile_${new_ver} file (${oracle_profile}) "
cat <<- ! > $oracle_profile
umask 022
CRS_HOME=/opt/app/oracle/crs/
ORACLE_BASE=$ORACLE_BASE ; export ORACLE_BASE
ORACLE_HOME=$ORACLE_HOME ; export ORACLE_HOME
LD_LIBRARY_PATH=$ORACLE_HOME/lib; export LD_LIBRARY_PATH
CLASSPATH=$ORACLE_HOME/jdk/jre/lib:$ORACLE_HOME/jlib; export CLASSPATH
ORACLE_NLS33=$ORACLE_HOME/ocommon/nls/admin/data; export ORACLE_NLS33
NLS_LANG=american_america.US7ASCII; export NLS_LANG
PATH=$ORACLE_HOME/bin:/usr/bin:/bin; export PATH
PS1="oracle@`hostname`:\$PWD $ "; export PS1
!
chown oracle:oinstall ${oracle_profile}
chmod 744 ${oracle_profile}

}

function_WA_for_OS_param() {
#
# WA for OS parameter kernel.shmall
#

log_message "INFO" "Changing  kernel.shmall parameter "
param=$(/sbin/sysctl -A | grep shmall)
log_message "INFO" "kernel.shmall parameter: $param"

MEM=$(free|grep Mem|awk '{print$2}')
TOTMEM=$(echo "$MEM*1024"|bc)
PAGE_SIZE=$(getconf PAGE_SIZE)
SHMALL=$(echo "$TOTMEM/$PAGE_SIZE"|bc)
sed -e "s#kernel.shmall=.*#kernel.shmall=$SHMALL#g" < /etc/sysctl.conf > /tmp/sysctl.conf
cp /tmp/sysctl.conf /etc/sysctl.conf

sleep 5
/sbin/sysctl -p
sleep 5

param=$(/sbin/sysctl -A | grep shmall)
log_message "INFO" "kernel.shmall parameter: $param"
}


function_restart_listener_and_database() {
#FLASHBACK STATUS
FLASHBACK_STATUS=NO

ls -l /tmp/FLASHBACK.txt	>> $pe_migfile 2>&1
cat /tmp/FLASHBACK.txt		>> $pe_migfile 2>&1

grep "FLASHBACK_STATUS=" /tmp/FLASHBACK.txt || {
	mv /tmp/FLASHBACK.txt /tmp/FLASHBACK.txt.ko.migration
	log_message "ERROR" " ====================================================================== "	| tee -a $logfile
	log_message "ERROR" " /tmp/FLASHBACK.txt is broken "						| tee -a $logfile
	log_message "ERROR" " Create a file without getting the FLASHBACK_STATUS value from database "	| tee -a $logfile
	log_message "ERROR" "     with FLASHBACK_STATUS=YES"						| tee -a $logfile
	log_message "ERROR" " ====================================================================== "	| tee -a $logfile
	echo "FLASHBACK_STATUS=YES" > /tmp/FLASHBACK.txt
	chmod 777 /tmp/FLASHBACK.txt
}
log_message "INFO" " cat /tmp/FLASHBACK.txt = $(cat /tmp/FLASHBACK.txt) " | tee -a $logfile
ls -l /tmp/FLASHBACK.txt	>> $pe_migfile 2>&1
cat /tmp/FLASHBACK.txt		>> $pe_migfile 2>&1

if [ -f /tmp/FLASHBACK.txt ]; then
        FLASHBACK_STATUS=`cat /tmp/FLASHBACK.txt | cut -d "=" -f2`
        export FLASHBACK_STATUS
else
	log_message "INFO" "WARNING: /tmp/FLASHBACK.txt not present "
	echo "WARNING: /tmp/FLASHBACK.txt not present " >> $tmpfile
	exit 1
fi

log_message "INFO" "FLASHBACK_STATUS = $FLASHBACK_STATUS"
if [ $FLASHBACK_STATUS = "NO" ]
then	
    #Stop Oracle Listener
    #

	su - oracle -c "
        . $oracle_profile
        ${ORACLE_HOME}/bin/lsnrctl status  2>&1" > /dev/null
        listener_status=$?
        if [ $listener_status -eq 0 ] ; then
                log_message "INFO" "Oracle Listener is running " 
                log_message "INFO" "Stopping listener " 
                su - oracle -c "
                . $oracle_profile
                ${ORACLE_HOME}/bin/lsnrctl stop" 
        else
                log_message "INFO" "Oracle Listener is stopped " 
        fi
	
	#
    #Start Grid Listener
    #
	su - oracle -c "
        . .grid_profile
        ${GRID_HOME}/bin/lsnrctl status  2>&1" > /dev/null
        listener_status=$?
        if [ $listener_status -eq 1 ] ; then
                log_message "INFO" "Grid Listener is not running "
                log_message "INFO" "Starting listener " 
                su - oracle -c "
                . .grid_profile
                ${GRID_HOME}/bin/lsnrctl start" 
        else
                log_message "INFO" "Grid Listener is started " 
        fi
	

	su - oracle -c "
	export ORACLE_HOME=$ORACLE_HOME_OLD	
        export ORACLE_SID=${DB_NAME}
        sqlplus -s / as sysdba <<-EOI
        startup mount
        alter database noarchivelog;
        alter database open;
        quit
	EOI
        exit
	"
oracle_stop | tee -a $logfile


	
fi

#
#Stop listener
#
log_message "INFO" "Stop 11G listener " 

	su - oracle -c "
        . .grid_profile 
        ${GRID_HOME}/bin/lsnrctl status  2>&1" > /dev/null
		listener_status=$?
        if [ $listener_status -eq 0 ] ; then
                log_message "INFO" "Grid Listener is running " 
                log_message "INFO" "Stopping listener " 
                su - oracle -c "
                . .grid_profile
                ${GRID_HOME}/bin/lsnrctl stop" 
        else
                log_message "INFO" "Grid Listener is stopped " 
        fi

}


function_migration_log_dir() {
#Migration log directory
migr_dir="/alcatel/install/log/migration"
if [ ! -d $migr_dir ]; then
	mkdir -p $migr_dir
	chmod 777 $migr_dir
fi

su - oracle -c "
        cd /alcatel/install/log/migration/
        cp $ORACLE_HOME/rdbms/admin/utlu112i.sql $migr_dir/
"

wfile="/alcatel/install/log/migration/utlu112i.sql"

sed -e "/^[ 	]*file_dest/,/dsize/s/30/50/" $wfile > $wfile.$$
mv $wfile.$$ $wfile
chown oracle:oinstall $wfile

log_message "INFO" "Changing rights for ${ORACLE_BASE}/admin/${DB_NAME} " 
chown -R oracle:oinstall ${ORACLE_BASE}/admin/${DB_NAME}
}


function_pre_upgrade_info_tool() {
#Run pre_upgrade information tool
log=$migr_dir/upgrade_info_SNM_${new_ver}
log_message "INFO" "Run pre_upgrade information tool (see logs in $log) " 
log_message "INFO" "Please wait..." 


	su - oracle -c "
        cd $migr_dir
	export ORACLE_HOME=$ORACLE_HOME_OLD
        export ORACLE_SID=${DB_NAME}
        sqlplus /nolog <<- EOF
                connect / as sysdba
                startup
                spool $log.log
                @$migr_dir/utlu112i.sql
                spool off
                exit;
	EOF
        "
oracle_stop | tee -a $logfile

}


function_dbua() {
log_message "INFO" "Starting Listener" 
		su - oracle -c "
        	. .grid_profile
		${GRID_HOME}/bin/lsnrctl start" 


log_message "INFO" "Starting Database for upgrade " 
	su - oracle -c "
	export ORACLE_HOME=$ORACLE_HOME_OLD
        export ORACLE_SID=${DB_NAME}
        sqlplus /nolog <<- EOI
                connect / as sysdba
                startup
                exit;
	EOI
        "

log_message "INFO" "Start running dbua " 
su - oracle -c "
DISPLAY=$DISPLAY;export DISPLAY;
$ORACLE_HOME/bin/dbua -silent -sid ${DB_NAME}" 

}

function_update_spfile() {

qfile="/alcatel/var/home/oracle/.bashrc"

if [ -f ${wfile} ]; then
        /bin/sed -e "s/ORACLE_HOME=.*/ORACLE_HOME=\${ORACLE_BASE}\/product\/${new_oracle_ver}/g" ${qfile} > /tmp/file
        mv /tmp/file ${qfile}
        chown oracle:oinstall ${qfile}
        chmod 640 ${qfile}
fi

log_message "INFO" " Stopping Oracle DB "
oracle_stop | tee -a $logfile
	
#Update spfile
log_message "INFO" "Backup oracle 1102 profile " 
mv $file $file.old
mv ${oracle_profile} $file

log_message "INFO" " Starting Oracle DB "
oracle_start
  
sleep 100

#Update spfile
log_message "INFO" "Update spfile " 
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOI
        alter system set diagnostic_dest='/alcatel/oracle/admin/${DB_NAME}' scope=spfile;
		alter system set UTL_FILE_DIR='/tmp' scope=spfile;
        disconnect
        exit
EOI
"

if [ $FLASHBACK_STATUS = "NO" ]
then
	log_message "INFO" "Update spfile " 
	su - oracle -c "
	export ORACLE_SID=${DB_NAME}
	$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOI
        alter system set compatible='${new_oracle_ver}.0' scope=spfile;
        disconnect
        exit
EOI
" 
fi
}

function_restart_oracle() {

log_message "INFO" "Restarting Oracle " 

		# Workaround in 11.2.0.3

		log_message "INFO" "Replace Oracle Home in New Grid listener.ora file " 
        cp $GRID_HOME/network/admin/listener.ora $GRID_HOME/network/admin/listener.ora.premigr
        sed -e "s#${old_ora_version}#${new_oracle_ver}#g" $GRID_HOME/network/admin/listener.ora > /tmp/listener.ora
        cp /tmp/listener.ora $GRID_HOME/network/admin/listener.ora
        rm /tmp/listener.ora
		
		#Restart Grid Listener
		su - oracle -c "
                . .grid_profile
                ${GRID_HOME}/bin/lsnrctl stop" 
		sleep 5

		su - oracle -c "
                . .grid_profile
                ${GRID_HOME}/bin/lsnrctl start" 
                sleep 5

		log_message "INFO" "Stopping Oracle DB "
		oracle_stop | tee -a $logfile

		sleep 5

		log_message "INFO" " Starting Oracle DB "
		oracle_start

sleep 200
}

function_post_upgrade_info_tool() {
#Run post-upgrade information tool
log=$migr_dir/postupgrade_info_SNM_${new_ver}
log_message "INFO" "Run postupgrade information tool (see logs in $log) " 
log_message "INFO" "Please wait..."
su - oracle -c "
	export ORACLE_SID=${DB_NAME}
        sqlplus /nolog <<- EOI
                connect / as sysdba
                spool $log.log
                @?/rdbms/admin/utlu112s.sql
                spool off
                exit;
	EOI
"

log_message "INFO" " Stopping Oracle DB "
oracle_stop | tee -a $logfile

}

#####MAIN
function_initialize
function_create_oracle_profile
function_WA_for_OS_param
function_restart_listener_and_database
function_migration_log_dir
function_pre_upgrade_info_tool
function_dbua
function_update_spfile
function_restart_oracle
function_post_upgrade_info_tool
log_message "INFO" "=== End of Migration to ${new_oracle_ver} " 

printf " %-15s : %s\n"	"End of script"	"$(date '+%Y/%m/%d %H:%M:%S')"			>> $pe_migfile
printf "\-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n"	>> $pe_migfile

} 2>&1 | tee -a ${logfile}
global_exit_code=`cat $tmpfile | wc -l`
exit $global_exit_code
