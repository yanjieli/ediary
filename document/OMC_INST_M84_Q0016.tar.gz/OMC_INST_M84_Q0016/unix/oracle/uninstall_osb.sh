#!/bin/ksh
#set -x

#
# Functions
#

uninstall_10_1 () {

echo "Running uninstallob script at `date`" | tee -a $LOGFILE

/usr/local/oracle/backup/install/uninstallob <<EOF
$host
install/obparameters
yes
no
yes
EOF

}

uninstall_10_2 () {

echo "Running uninstallob script at `date`" | tee -a $LOGFILE

/usr/local/oracle/backup/install/uninstallob <<EOF
install/obparameters
yes
no
yes
EOF

} 

remove_files () {

echo "\nRemoving /usr/local/oracle directory at `date`" | tee -a $LOGFILE
rm -fr /opt/app/oracle/product/11.2.0.2/lib/libobk.so
rm -fr /opt/app/oracle/product/11.2.0.3/lib/libobk.so
rm -fr /usr/local/oracle/
rm -fr /usr/local/oracle
echo "Removing ob driver at `date`" | tee -a $LOGFILE
rem_drv ob
echo "Removing ob references from /usr/kernel/drv\n" | tee -a $LOGFILE
rm -fr /usr/kernel/drv/ob
rm -fr /usr/kernel/drv/ob.conf
rm -fr /usr/kernel/drv/sparcv9/ob

}

LOGFILE="/alcatel/install/log/OSB_uninstall_`date '+%d_%m_%y__%H-%M-%S'`.log"
echo "Log file is $LOGFILE"

if [[ -d /usr/local/oracle/backup ]]
then
	echo "/usr/local/oracle/backup present..." | tee -a $LOGFILE
else
	echo "Backup directory does not exist...Aborting uninstallation" | tee -a $LOGFILE
	exit 1
fi

if [ -f /usr/local/oracle/backup/bin/obtool ]
	then
		cd /usr/local/oracle/backup/bin
		inst_ver=`./obtool -V | grep 10\..\..\.. | awk {'print $3'}`
		echo "Installed version is $inst_ver" | tee -a $LOGFILE
	else
		echo "Backup directory not complete ...Aborting uninstallation" | tee -a $LOGFILE
		remove_files
		exit 1	
fi


echo "Removing current OSB installation at `date`" | tee -a $LOGFILE
ob1=`ps -ef | grep -i obhttpd | awk '{print $2}'`
ob2=`ps -ef | grep -i obscheduled | awk '{print $2}'`
ob3=`ps -ef | grep -i observiced | awk '{print $2}'`

for i in $ob1
do
	echo "Killing ob process $i" | tee -a $LOGFILE
	kill -9 $i 1>>$LOGFILE 2>&1
done

for i in $ob2
do
        echo "Killing ob process $i" | tee -a $LOGFILE
        kill -9 $i 1>>$LOGFILE 2>&1
done

for i in $ob3
do
        echo "Killing ob process $i" | tee -a $LOGFILE
        kill -9 $i 1>>$LOGFILE 2>&1
done

host=`hostname`

case $inst_ver in
	*10.1.0.2*) uninstall_10_1;;
	*10.2.0.2*) uninstall_10_2;;
	*10.3.0.1*) uninstall_10_2;;
	*10.4.0.2*) uninstall_10_2;;
	*) echo "No supported version found, exiting uninstallation script";exit 1
	esac
cd .

remove_files

echo "Removing of OSB software completed at `date`!" | tee -a $LOGFILE
echo "---------------------------------------------------"
