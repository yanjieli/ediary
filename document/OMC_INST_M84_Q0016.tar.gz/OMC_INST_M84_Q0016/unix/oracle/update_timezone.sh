#!/bin/ksh

#
# Update timezone to version 9
#

#set -x

log_TZa="/var/tmp/fixTZa.lst"
log_TZb="/var/tmp/fixTZb.lst"

#cluster parameter read
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

export ASM
export RAC
export INSTANCE_NUMBER

if [ $RAC -eq 1 ]; then
        export ORACLE_SID=SNM$INSTANCE_NUMBER
else
	export ORACLE_SID=SNM
fi

export ORACLE_HOME="/opt/app/oracle/product/10.2.0"

[[ -f $log_TZa ]] && /usr/bin/rm $log_TZa
[[ -f $log_TZb ]] && /usr/bin/rm $log_TZb

curpwd=`pwd`

cd /var/tmp/

if [[ "$RAC" -eq 1 ]]; then
#start ASM
/usr/bin/su - oracle -c "
        export ORACLE_SID=+ASM$INSTANCE_NUMBER
        export ORACLE_HOME=$ORACLE_HOME
        $ORACLE_HOME/bin/sqlplus /nolog <<- !
        connect sys/asmpower as sysdba
        startup
        disconnect
        exit;
        !
"

#start SNM
/usr/bin/su - oracle -c "
        export ORACLE_SID=$ORACLE_SID
        export ORACLE_HOME=$ORACLE_HOME
        $ORACLE_HOME/bin/sqlplus / as sysdba <<- !
	STARTUP NOMOUNT
        ALTER SYSTEM SET CLUSTER_DATABASE=FALSE SCOPE=spfile;
        SHUTDOWN IMMEDIATE
        exit;
        !
"

/usr/bin/su - oracle -c "
       export ORACLE_SID=$ORACLE_SID
       export ORACLE_HOME=$ORACLE_HOME
       $ORACLE_HOME/bin/sqlplus / as sysdba <<- !
       startup
       exit;
       !
"
fi

if [[ "$RAC" -eq 0 ]]; then
/usr/bin/su - oracle -c "
	export ORACLE_SID=$ORACLE_SID
        sqlplus /nolog <<- !
                connect / as sysdba
                startup
		exit;
!
"
fi

$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
connect sys/orapower as sysdba 
@/opt/app/oracle/product/10.2.0/javavm/admin/fixTZa.sql
exit
EOF


/usr/bin/egrep "Bug is in fact present" /var/tmp/fixTZa.lst >/dev/null 2>&1
check_bug=$?

if [[ $check_bug -eq 0 ]]; then
	if [[ "$RAC" -eq 0 ]]; then
		/usr/bin/su - oracle -c "
        		ORACLE_SID=$ORACLE_SID
        		export ORACLE_SID
        		sqlplus /nolog <<- !
                	connect / as sysdba
			shutdown immediate
                	startup upgrade
                	exit;
		!
		"
        fi

	if [[ "$RAC" -eq 1 ]]; then
		/usr/bin/su - oracle -c "
                        ORACLE_SID=$ORACLE_SID
                        export ORACLE_SID
                        sqlplus /nolog <<- !
                        connect / as sysdba
			shutdown immediate
                        startup upgrade
                        exit;
                !
                "
	fi

	$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
	connect sys/orapower as sysdba
	@/opt/app/oracle/product/10.2.0/javavm/admin/fixTZb.sql
	exit
	EOF
fi

if [[ "$RAC" -eq 0 ]]; then
	/usr/bin/su - oracle -c "
       		export ORACLE_SID=$ORACLE_SID
       		sqlplus /nolog <<- !
               	connect / as sysdba
               	shutdown
               	exit;
       	!
       	"
fi

if [[ "$RAC" -eq 1 ]]; then
#stop SNM
/usr/bin/su - oracle -c "
     export ORACLE_SID=$ORACLE_SID
     sqlplus /nolog <<- !
     connect / as sysdba
     shutdown
     exit;
     !
"

#set cluster_database
/usr/bin/su - oracle -c "
     	export ORACLE_SID=$ORACLE_SID
       	export ORACLE_HOME=$ORACLE_HOME
       	$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
       	STARTUP NOMOUNT
       	ALTER SYSTEM SET CLUSTER_DATABASE=TRUE SCOPE=spfile;
       	SHUTDOWN IMMEDIATE
       	exit
	EOF
"

/usr/bin/sleep 200

#stop ASM
/usr/bin/su - oracle -c "
	export ORACLE_SID=+ASM$INSTANCE_NUMBER
	export ORACLE_HOME=$ORACLE_HOME
	$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
	connect sys/asmpower as sysdba
	shutdown
	disconnect
	exit
	EOF
	"
fi

cd $curpwd
