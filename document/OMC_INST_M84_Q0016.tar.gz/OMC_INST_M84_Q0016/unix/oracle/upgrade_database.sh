#!/bin/ksh

#        - Restore database using information from external storage and RMAN backup
#        - Move database to ASM disks  
#        - Switch database to copy (ASM disks) 
#        Author : Cristian Ciurea - 07.10.2007

DB_NAME=SNM
RMAN_BACK_DIR=/alcatel/backup
LOGFILE=/alcatel/install/log/restore_data.log
ORACLE_HOME_PATH=/alcatel/var/home/oracle
ORACLE_HOME=`cat $ORACLE_HOME_PATH/.profile |grep ORACLE_HOME |awk '{print $1}' |cut -d = -f2`
RECOVERY_DISKGROUP="+RECOVERY"
DATA_DISKGROUP="+DATA"
FILE="/alcatel/backup/old_pfile.ora"
DB_PASSWD="orapower"

#Obtain instance number
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

cat >$2 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
!

#Update database from Diskgroups
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
	
	connect sys/${DB_PASSWD} as sysdba
        startup pfile='${FILE}.new' UPGRADE;
        disconnect
        exit
EOF
" | tee -a $LOGFILE
sleep 30

#Restore control files
su - oracle -c "
export ORACLE_SID=$DB_NAME
$ORACLE_HOME/bin/rman target / nocatalog <<- EOF
	restore controlfile from '${RMAN_BACK_DIR}/ctl_after_backup.ctl';
        exit
EOF
" | tee -a $LOGFILE
sleep 30

backup_time=`cat ${RMAN_BACK_DIR}/hour`
#Upgrade database 
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

      connect sys/${DB_PASSWD} as sysdba
      	alter database mount;	
      	recover database until cancel using backup controlfile;
        
	disconnect
        exit
EOF
" | tee -a $LOGFILE

#Upgrade database
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

      connect sys/${DB_PASSWD} as sysdba
	alter database open resetlogs;	
        disconnect
        exit
EOF
" | tee -a $LOGFILE

#Upgrade database
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

      connect sys/${DB_PASSWD} as sysdba
        @$ORACLE_HOME/rdbms/admin/catalog.sql
        @$ORACLE_HOME/rdbms/admin/catproc.sql
        create spfile='+DATA/SNM/spfilesnm.ora' from pfile='${FILE}.new';
        create pfile='/var/tmp/rac_snm.ora' from spfile='+DATA/SNM/spfilesnm.ora';
	shutdown immediate;

        disconnect
        exit
EOF
" | tee -a $LOGFILE

exit 0
