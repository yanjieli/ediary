#!/bin/ksh

#                 Update failed oracle config files resulted from Clusterware 
#                 Author : Ciurea Cristian
#                 Last Update : 19.09.2007

#set -x
CRS_HOME=/opt/app/oracle/crs	
failed=$CRS_HOME/cfgtoollogs/configToolFailedCommands


file=$CRS_HOME/bin/oifcfg
if [[ -f $CRS_HOME/bin/oifcfg ]]
then
	getif=`$CRS_HOME/bin/oifcfg getif | wc -l`	
else
        echo "ERROR: Oracle Clusterware not installed!"
        exit 1
fi

function get_network {
	ip=$1
	hexmask=$2
	subnet=""
	i=1
	while [ $i -ne 5 ]
	do
		j=$((i*2-1))
		d1=`echo $ip | awk -F"." '{print $'"$i"'}'`
		n1=`echo $hexmask | awk '{print substr($0,'"$j"',2) }'`
		n1=$((16#$n1))
		let " s[i] =  n1 & d1 "
		i=$(($i+1))
	done
	subnet=${s[1]}.${s[2]}.${s[3]}.${s[4]}
}

if [[ $getif -eq 0 ]]
then
	if [[ -f $failed ]]
	then
		first_ip=`cat $failed |awk '/cluster_interconnect/ {print $4}'|cut -f1 -d ':' | cut -f2 -d '/'`
                first_hexmask=`ifconfig -a | grep $first_ip | awk ' { print $4 } '`
                get_network $first_ip $first_hexmask
		first_subnet=$subnet
                echo "first IP: $first_ip - $first_subnet"

		cp $failed $failed.bak
		
		second_ip=`cat $failed |awk '/cluster_interconnect/ {print $5}'|cut -f1 -d ':' | cut -f2 -d '/'`
                second_hexmask=`ifconfig -a | grep $second_ip | awk ' { print $4 } '`
                get_network $second_ip $second_hexmask
                second_subnet=$subnet
                echo "second IP: $second_ip - $second_subnet"	
		
		EXPR1="s/$first_ip/$first_subnet/g"
                EXPR2="s/$second_ip/$second_subnet/g"	
		sed -e $EXPR1 -e $EXPR2 $failed > $failed.indus	
		chown oracle:oinstall $failed.indus
		chmod +x $failed.indus
		$failed.indus
	else
       		echo "ERROR: Oracle Clusterware not installed!"
        	exit 1
	fi
else
	echo " Clusterware is correctly configured !"
fi

