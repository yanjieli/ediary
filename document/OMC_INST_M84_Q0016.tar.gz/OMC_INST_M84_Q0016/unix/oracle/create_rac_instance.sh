#!/bin/ksh

#        - Update spfile with RAC info
#        - Create SNM RAC instance 
#        - Register SNM1/SNM instance to srvctl
#        Author : Cristian Ciurea - 08.10.2007

DB_NAME=SNM
RMAN_BACK_DIR=/alcatel/backup
LOGFILE=/alcatel/install/log/restore_data.log
ORACLE_HOME_PATH=/alcatel/var/home/oracle
ORACLE_HOME=`cat $ORACLE_HOME_PATH/.profile |grep ORACLE_HOME |awk '{print $1}' |cut -d = -f2`
RECOVERY_DISKGROUP="+RECOVERY"
DATA_DISKGROUP="+DATA"
FILE="/alcatel/backup/old_pfile.ora"
DB_PASSWD="orapower"
HOSTNAME=`hostname`
HOSTNAME_UPPER=`echo "$HOSTNAME" | tr [a-z] [A-Z]`
BACKUPDIR=/alcatel/oracle/oradata
REDOLOG=/var/tmp/redo.sql

#Obtain instance number
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

CLUSTER_NAME=`awk '$1 ~ /^'"${FLOATING_IP}"'$/ {print $2}' /etc/hosts`

cat >$2 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
CLUSTER_NAME=$CLUSTER_NAME
!

#obtain tunnning parameters
#set oracle tunning parameter
if [ -f /install/data/tuning_server.pm ]
        then . /install/data/tuning_server.pm
fi

cat >$2 <<!
TEMP_TABLESPACE_AUTOEXTEND=$TEMP_TABLESPACE_AUTOEXTEND
TEMP_MAX_SIZE=$TEMP_MAX_SIZE
TEMP_TABLESPACE_SIZE=$TEMP_TABLESPACE_SIZE
!

PFILE="/var/tmp/rac_snm.ora"
#cp $PFILE $PFILE.bak
EXPR1="s/${DB_NAME}._/${DB_NAME}${INSTANCE_NUMBER}._/g"

/usr/bin/sed -e $EXPR1 $FILE.new > $PFILE.new | tee -a $LOGFILE

echo "*.cluster_database_instances=1"  >> $PFILE.new | tee -a $LOGFILE
echo "*.cluster_database=true"  >> $PFILE.new | tee -a $LOGFILE
echo "*.remote_listener='LISTENERS_${DB_NAME}'" >> $PFILE.new | tee -a $LOGFILE
echo "${DB_NAME}${INSTANCE_NUMBER}.local_listener='LOCAL_$HOSTNAME_UPPER'" >> $PFILE | tee -a $LOGFILE
echo "${DB_NAME}${INSTANCE_NUMBER}.instance_number=${INSTANCE_NUMBER}"  >> $PFILE.new | tee -a $LOGFILE
echo "${DB_NAME}${INSTANCE_NUMBER}.thread=${INSTANCE_NUMBER}"  >> $PFILE.new | tee -a $LOGFILE
echo "${DB_NAME}${INSTANCE_NUMBER}.undo_tablespace='UNDOTBS${INSTANCE_NUMBER}'"  >> $PFILE.new | tee -a $LOGFILE

#Shutdown SNM instance

su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

        shutdown immediate

        disconnect
        exit
EOF
" | tee -a $LOGFILE

#Start database with new pfile
su - oracle -c "
export ORACLE_SID=${DB_NAME}${INSTANCE_NUMBER}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

        startup pfile='$PFILE.new';
	create spfile='+DATA/SNM/spfilesnm.ora' from pfile='$PFILE.new';
	@$ORACLE_HOME/rdbms/admin/catclust.sql
	shutdown immediate

        disconnect
        exit
EOF
" | tee -a $LOGFILE

#remove spfile if exist
rm -fr $ORACLE_HOME/dbs/spfile${DB_NAME}${INSTANCE_NUMBER}.ora
echo SPFILE='+DATA/SNM/spfileSNM.ora' > $ORACLE_HOME/dbs/init${DB_NAME}${INSTANCE_NUMBER}.ora

#create SNM instance
su - oracle -c "
$ORACLE_HOME/bin/srvctl add database -d ${DB_NAME} -o $ORACLE_HOME
$ORACLE_HOME/bin/srvctl add instance -i ${DB_NAME}${INSTANCE_NUMBER} -d ${DB_NAME} -n ${HOSTNAME} 
$ORACLE_HOME/bin/srvctl modify instance -i ${DB_NAME}${INSTANCE_NUMBER} -d ${DB_NAME} -s +ASM${INSTANCE_NUMBER}
$ORACLE_HOME/bin/srvctl stop asm -n ${HOSTNAME}
sleep 30
$ORACLE_HOME/bin/srvctl start db -d SNM
" | tee -a $LOGFILE

#Change user name
#read configuration parameters
if [ -f ${BACKUPDIR}/config ]
        then . ${BACKUPDIR}/config
fi

cat >$2 <<!
BACK_UP_SIZE=$BACK_UP_SIZE
HOSTNAME=$HOSTNAME
INSTANCE_COUNT=$INSTANCE_COUNT
OMC_HOME=$OMC_HOME
OMC_DB_USER=$OMC_DB_USER
!


#Export OLD USER info and imported into the new one
if [ "omc_${CLUSTER_NAME}" != "${OMC_DB_USER}" ]
then
#create new user only if it has a new name (Cluster name is diffrent from old hostname)
EXPDIR=/alcatel/export
mkdir -p ${EXPDIR}
rm -fr ${EXPDIR}/*
chown oracle:oinstall ${EXPDIR}
su - oracle -c "
export ORACLE_SID=${DB_NAME}${INSTANCE_NUMBER}
/alcatel/${OMC_HOME}/OMC_DBCF/dba_scripts/NM_create_users.sh
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
        CREATE OR REPLACE DIRECTORY export AS '${EXPDIR}';
        GRANT READ, WRITE ON DIRECTORY export to ${OMC_DB_USER};
        GRANT READ, WRITE ON DIRECTORY export to omc_${CLUSTER_NAME};
        disconnect
        exit
EOF
$ORACLE_HOME/bin/expdp ${OMC_DB_USER}/${OMC_DB_USER} DUMPFILE=dump.dmp SCHEMAS=${OMC_DB_USER} DIRECTORY=export
$ORACLE_HOME/bin/impdp system/${DB_PASSWD} DUMPFILE=dump.dmp DIRECTORY=export REMAP_SCHEMA=${OMC_DB_USER}:omc_${CLUSTER_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
        drop user ${OMC_DB_USER} cascade;
        disconnect
        exit
EOF
" | tee -a $LOGFILE
fi

/alcatel/${OMC_HOME}/OMC_DBCF/scripts/updateclusterconfig.sh

#prepare info from configure_tunning
TEMP_size=`perl -e '$TEMP_size="'$TEMP_TABLESPACE_SIZE'"; $aux=int($TEMP_size * 1024);print $aux.M;'`
TEMP_auto=`perl -e '$TEMP_auto="'$TEMP_TABLESPACE_AUTOEXTEND'"; $aux=int($TEMP_auto * 1024);print $aux.M;'`
TEMP_MAX_size=`perl -e '$TEMP_MAX_size="'$TEMP_MAX_SIZE'"; $aux=int($TEMP_MAX_size * 1024);print $aux.M;'`

#copy redo log to /var/tmp/redo.sql
cp -p moveredo.sql /var/tmp/redo.sql
cp -p removelastlog.sql /var/tmp/movelast.sql
chown oracle:oinstall /var/tmp/redo.sql
chown oracle:oinstall /var/tmp/movelast.sql
#Move redo log to +RECOVERY
su - oracle -c "
export ORACLE_SID=${DB_NAME}${INSTANCE_NUMBER}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
       @/var/tmp/redo.sql
       @/var/tmp/movelast.sql
       create temporary tablespace temprac tempfile '${DATA_DISKGROUP}';
       alter database default temporary tablespace temprac;
       drop tablespace temp including contents and datafiles;
       create temporary tablespace temp tempfile '${DATA_DISKGROUP}' SIZE $TEMP_size REUSE AUTOEXTEND ON NEXT $TEMP_auto MAXSIZE $TEMP_MAX_size;
       ALTER DATABASE DEFAULT TEMPORARY TABLESPACE temp;
       DROP TABLESPACE temprac INCLUDING CONTENTS AND DATAFILES;
       disconnect
       exit
EOF
" | tee -a $LOGFILE

echo "Configuring oracle tuning" | tee -a $LOGFILE
su - oracle -c "/alcatel/${OMC_HOME}/OMC_DBCF/dba_scripts/configure_tuning_pm.sh" || {
     echo "\nWARNING: Can't configure oracle tuning"
     exit 1
} | tee -a $LOGFILE

su - oracle -c "
	$ORACLE_HOME/bin/srvctl stop db -d $DB_NAME > /dev/null 2>&1
	$ORACLE_HOME/bin/srvctl start db -d $DB_NAME > /dev/null 2>&1
" | tee -a $LOGFILE

sleep 200

exit 0
