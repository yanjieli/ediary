#!/bin/ksh

#
# Check FLASHBACK
#

#set -x
date="$(date '+%Y%m%d_%H:%M:%S')"
logfile=/alcatel/install/log/migration/$(basename $0 .sh)_$date.log
dir_name=$(dirname $logfile)

echo "[`date '+%d-%m-%y %H:%M:%S'`] execute script to get FLASHBACK status" | tee -a $logfile
scr_location=$(dirname $0)

pe_migfile="/var/tmp/migration_traces.log"
printf "\n\-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n"	>> $pe_migfile
printf " %-15s : %s\n"	"Script"		"$0 $*"					>> $pe_migfile
printf " %-15s : %s\n"	"Start of script"	"$(date '+%Y/%m/%d %H:%M:%S')"		>> $pe_migfile
printf "\-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n"	>> $pe_migfile
id -a		>> $pe_migfile
df -h		>> $pe_migfile
pid=$$
while ((pid>1))
do
	ps -o uid,pid,ppid,c,stime,tty,time,cmd -p $pid		>> $pe_migfile
	pid=$(ps -o ppid= -p $pid)
done

if [ -f ${scr_location}/../lib/install.sh ]; then
    . ${scr_location}/../lib/install.sh
else
    echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR: Could not load 'install.sh' library."
    exit 1
fi

#cluster parameter read
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
else
	log_message "ERROR" "/install/data/cluster.conf does not exists" | tee -a $logfile
        exit 1
fi
export ASM
export RAC

#set oracle sid for RAC
if [ $RAC -eq 1 ]; then
        export ORACLE_SID=SNM1
else
        export ORACLE_SID=SNM
fi

if [[ ! -d $dir_name ]]; then
        mkdir $dir_name
fi
chown oracle:oinstall $dir_name

if [ `uname` = "SunOS" ]
then
        OS_TYPE="solaris"
        orafile=/var/opt/oracle/oratab
else
        OS_TYPE="linux"
        orafile=/etc/oratab
fi

if [ -f $orafile ]
then
	ORACLE_VERSION=`awk -F: '$1 ~/^SNM$/ {print $2}' $orafile | sed -e "s#.*product/\([0-9]*\).*#\1#"`
        log_message "INFO" "Found Oracle version : $ORACLE_VERSION" | tee -a $logfile
        ORACLE_HOME=`awk -F: '$1 ~/^SNM$/ {print $2}' $orafile`
        export ORACLE_HOME
        log_message "INFO" " ORACLE_HOME = $ORACLE_HOME " | tee -a $logfile
else
        log_message "ERROR" "$orafile does not exists" | tee -a $logfile
	exit 1
fi

flashback_file='/var/tmp/FLASHBACK.txt'
if [[ -f $flashback_file ]]; then
    rm $flashback_file
fi

flashback_file='/tmp/FLASHBACK.txt'
if [[ -f $flashback_file ]]; then
    mv $flashback_file $flashback_file.$date
fi



wait_for_oracle

#RCA: defense case some rights are not set:
if [ ! -g $ORACLE_HOME/bin/oracle ];then
	chmod 6751 $ORACLE_HOME/bin/oracle
fi

log_message "INFO" " ORACLE_HOME = $ORACLE_HOME " | tee -a $logfile
log_message "INFO" " ORACLE_SID  = $ORACLE_SID  " | tee -a $logfile
env | grep ORA	>> $pe_migfile
ls -l $logfile			>> $pe_migfile 2>&1
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
	spool $logfile append
        connect sys/orapower as sysdba
        SET SERVEROUTPUT ON
        DECLARE
             UTLDIR varchar2 (40) := '/tmp';
             wtabsqlfile  VARCHAR2 (20) := 'FLASHBACK.txt';
             wtabsqlftype UTL_FILE.FILE_TYPE;
             cmd varchar2(1000);
        CURSOR ctabs IS
            SELECT FLASHBACK_ON type FROM V\$DATABASE;
        BEGIN
            wtabsqlftype := UTL_FILE.FOPEN(utldir, wtabsqlfile, 'w');
            		FOR rcc IN ctabs LOOP
                   		UTL_FILE.PUT_LINE(wtabsqlftype, 'FLASHBACK_STATUS=' || rcc.type);
            		END LOOP;
            UTL_FILE.FCLOSE(wtabsqlftype);
        END;
/
spool off
exit;
EOF

ls -l $logfile			>> $pe_migfile 2>&1
ls -l /tmp/FLASHBACK.txt	>> $pe_migfile 2>&1
cat /tmp/FLASHBACK.txt		>> $pe_migfile 2>&1
echo test > /tmp/x		2>> $pe_migfile
ls -l /tmp/x			>> $pe_migfile 2>&1

grep "FLASHBACK_STATUS=" $flashback_file || {
	mv $flashback_file $flashback_file.ko.info_flashback
	log_message "ERROR" " ====================================================================== "	| tee -a $logfile
	log_message "ERROR" " $flashback_file is broken "						| tee -a $logfile
	log_message "ERROR" " Create a file without getting the FLASHBACK_STATUS value from database "	| tee -a $logfile
	log_message "ERROR" "     with FLASHBACK_STATUS=YES"						| tee -a $logfile
	log_message "ERROR" " ====================================================================== "	| tee -a $logfile
	echo "FLASHBACK_STATUS=YES" > $flashback_file
	chmod 777 $flashback_file
}

log_message "INFO" " cat $flashback_file = $(cat $flashback_file) " | tee -a $logfile

ls -l /tmp/FLASHBACK.txt	>> $pe_migfile 2>&1
cat /tmp/FLASHBACK.txt		>> $pe_migfile 2>&1
printf " %-15s : %s\n"	"End of script"	"$(date '+%Y/%m/%d %H:%M:%S')"			>> $pe_migfile
printf "\-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n"	>> $pe_migfile



if [[ ! -f $flashback_file ]]; then
	exit 1
fi
exit 0

