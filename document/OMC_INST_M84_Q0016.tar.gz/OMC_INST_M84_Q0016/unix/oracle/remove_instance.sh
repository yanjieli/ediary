#!/bin/ksh

#        - Remove old RAC instance
#        - Delete diskgroup including contents
#        - Recreate diskgroups
#        Author : Cristian Ciurea - 06.10.2007

LOGFILE=/alcatel/install/log/restore_data.log
ORACLE_HOME_PATH=/alcatel/var/home/oracle
DB_NAME=SNM
HOSTNAME=`hostname`

#Obtain instance number
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

cat >$2 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
CLUSTER_DATA=$CLUSTER_DATA
CLUSTER_RECO=$CLUSTER_RECO
!


ORACLE_HOME=`cat $ORACLE_HOME_PATH/.profile |grep ORACLE_HOME |awk '{print $1}' |cut -d = -f2`
su - oracle -c "
$ORACLE_HOME/bin/srvctl stop db -d SNM
sleep 50
$ORACLE_HOME/bin/srvctl stop asm -n $HOSTNAME
sleep 10
$ORACLE_HOME/bin/srvctl remove asm -n $HOSTNAME
echo "y" | $ORACLE_HOME/bin/srvctl remove instance -i ${DB_NAME}${INSTANCE_NUMBER} -d ${DB_NAME} 
echo "y" | $ORACLE_HOME/bin/srvctl remove database -d ${DB_NAME} 
exit 0
" | tee -a $LOGFILE


#Delete DATA and RECOVERY DISKGROUPS
su - oracle -c "
export ORACLE_SID=+ASM${INSTANCE_NUMBER}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

	startup 
	drop diskgroup DATA including contents;
	drop diskgroup RECOVERY including contents;
	shutdown immediate
        disconnect
        exit
EOF
" | tee -a $LOGFILE

OMC_INSTALL=`ls /install/data/OMC_INSTALL_* | head -n 1`
#Obtain instance number
if [ -f ${OMC_INSTALL} ]
        then . ${OMC_INSTALL} 
fi

cat >$2 <<!
OMC_HOME=$OMC_HOME
!
OMC_HOME=$OMC_HOME

su - oracle -c "
        export ORACLE_SID=+ASM${INSTANCE_NUMBER}
        #create diskgroups
        $ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF

	startup
        create diskgroup DATA external redundancy disk '$CLUSTER_DATA';
        create diskgroup RECOVERY external redundancy disk '$CLUSTER_RECO';

	disconnect	
        exit
EOF
"  | tee -a $LOGFILE

exit 0
