#!/bin/bash
#This script is used to install a new version of JDK in $ORACLE_BASE/product/11.2.0.4
#The name of the patch should be: jdkpatch_p<PATCH_NUMBER>_<JDK_VERSION>.tar.gz
#The /alcatel/install/ORACLE_PATCH/3Ppatch has to contain ONLY the last Oracle JDK patch for update


ORACLE_BASE=/opt/app/oracle
ORACLE_HOME=$ORACLE_BASE/product/11.2.0.4
GRID_HOME=$ORACLE_BASE/grid/11.2.0.4
LOG_FILE=/alcatel/install/log/oracle_jdk_patch.log_$(date '+%d-%m-%y:%H:%M')
new_jdk_ver="1.5.0_85"

scr_location=$(dirname $0)

INSTALL_LIB_DIR="${scr_location}/../lib"
install_file="${INSTALL_LIB_DIR}/install.sh"
        if [ ! -f $install_file ];then
                echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR INSTALL: $install_file file not found" >&2
                exit 1
        fi
. $install_file

usage () {
	log_message "INFO" "Usage: $ME <cd_mount_point> DB/GRID" >&2
	exit 1
}

apply_jdk_patch () {
	log_message "INFO" "=== Oracle JDK patch installation in $scope_str home" | tee -a $LOG_FILE
	patch_no=$(ls -l $PATCH_LOCATION | grep -v total | wc -l)
	if [ $patch_no -eq 1 ]; then
	patch_name=$(ls -l $PATCH_LOCATION | grep -v total |awk -F" " '{print $9}')	
	jdk_crt_ver=$($DESTINATION_HOME/jdk/bin/java -version 2>&1 | grep version | awk -F"\"" '{print $2}')
	if [ $jdk_crt_ver != $new_jdk_ver ]; then
		if [ -f $DESTINATION_HOME/jdk_old.tar.gz ]; then
			rm -f $DESTINATION_HOME/jdk_old.tar.gz
		fi
		tar cvzf $DESTINATION_HOME/jdk_old.tar.gz  $DESTINATION_HOME/jdk/*
		rm -rf $DESTINATION_HOME/jdk
		(cd $DESTINATION_HOME; gzip -cd $PATCH_LOCATION/$patch_name | tar xfo -)
		chown -R oracle:oinstall $DESTINATION_HOME/jdk
		new_jdk_patch=$(echo $patch_name | awk -F"_" '{print $2}')
		new_installed_jdk=$($DESTINATION_HOME/jdk/bin/java -version 2>&1 | grep version | awk -F"\"" '{print $2}')
		cat <<- ! >> /etc/MUSE.signature
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                      -=( $scope_str JDK patch $new_jdk_patch )=-
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

!
		log_message "INFO" "===Installation of $new_jdk_patch with JDK $new_installed_jdk in $scope_str home was successful.===" | tee -a $LOG_FILE
		log_message "INFO" "==="
		log_message "INFO" "==================================================================="  | tee -a $LOG_FILE
		log_message "INFO" " PATCH correctly applied !" | tee -a $LOG_FILE
		log_message "INFO" "==================================================================="  | tee -a $LOG_FILE
	else
		log_message "INFO" "=== Found JDK version: $jdk_crt_ver in $scope_str home. No need to update. ==="             | tee -a $LOG_FILE
	fi
	else
		log_message "INFO" "==================================================================="  | tee -a $LOG_FILE
		log_message "INFO" "ERROR" "There are $patch_no number of patches in $PATCH_LOCATION and should be only 1" | tee -a $LOG_FILE
		log_message "INFO" "==================================================================="  | tee -a $LOG_FILE
	fi
		
}

stop_has () {
log_message "INFO" "Stopping Oracle HAS resources ..." | tee -a $LOG_FILE
        $GRID_HOME/bin/crs_stat >/dev/null
        if [ $? -eq 0 ];then
                $GRID_HOME/bin/crsctl stop has
                sleep 20
        fi
}

start_has () {
log_message "INFO" "Starting Oracle HAS resources ..." | tee -a $LOG_FILE
        $GRID_HOME/bin/crsctl start has
        sleep 20
}

######################################
#            MAIN                    #
######################################

if [ $# -ne 2 ]; then 
	usage
fi

MOUNT_POINT=$1
scope=$2
PATCH_LOCATION=$MOUNT_POINT/3Ppatch
if [ ! -d $PATCH_LOCATION ]; then 
	log_message "ERROR" "$PATCH_LOCATION does not exist!"
	exit 1
fi

case $scope in
	"DB")		DESTINATION_HOME=$ORACLE_HOME
			scope_str="Oracle"
			stop_has
			apply_jdk_patch
			;;
	"GRID") 	DESTINATION_HOME=$GRID_HOME
			scope_str="Grid"
			apply_jdk_patch
			start_has
			;;
	*)		usage
			;;
esac

log_message "INFO" "=== End of Oracle JDK patch installation in $scope_str home : ($(/bin/date))" | tee -a $LOG_FILE
