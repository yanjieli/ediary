#/bin/ksh
#set -x
logfile=/alcatel/install/log/grid_upgrade.log_`date '+%d-%m-%y:%H:%M'`
{


function_initialize() {

PKGver="11.2.0.4"
ORA_HOME=/alcatel/var/home/oracle
ORACLE_HOME="/opt/app/oracle/product/$PKGver"
orafile=/etc/oratab
OLD_ORACLE_HOME_2=`awk -F: '$1 ~/^SNM$/ {print $2}' ${orafile}`
ORACLE_BASE=/opt/app/oracle
ORACLE_INVLOC=$ORACLE_BASE/oraInventory
ASM_INSTANCE=+ASM1
OS_TYPE=`uname -s`
OLD_GRID_HOME=`awk -F: '$1 ~/^\+ASM$/ {print $2}' ${orafile}`
GRID_HOME=/opt/app/oracle/grid/$PKGver
location_for_disk1=$1; export location_for_disk1
HOSTNAME=`hostname`
NODELIST=$HOSTNAME
ORACLE_DB_SID=SNM

touch $logfile
chmod 777 $logfile

if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
else
        echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR: /install/data/cluster.conf file missing"
        exit 1
fi

ASM=$ASM
RAC=$RAC
CLUSTER_DATA=$CLUSTER_DATA
PKGname="CDORAGRIDver"
AWK=/bin/awk
location_for_disk1=$1; export location_for_disk1

if [[ -f $OMC_UNIX_INSTALL_DIR/oracle/response.file/ocm.rsp ]]
then
	cp $OMC_UNIX_INSTALL_DIR/oracle/response.file/ocm.rsp /var/tmp
else
    echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR: $OMC_UNIX_INSTALL_DIR/oracle/response.file/ocm.rsp file missing" 
    exit 1
fi

}

scr_location=$(dirname $0)

INSTALL_LIB_DIR="${scr_location}/../lib"
install_file="${INSTALL_LIB_DIR}/install.sh"
        if [ ! -f $install_file ]; then
                echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR: $install_file file not found" >&2
                exit 1
        fi
. $install_file

function_set_crs_true() {
######## Set CRS TRUE for Oracle Grid Home ##################
OS=`uname`

if [ -f /alcatel/var/home/oracle/.grid_profile ]; then
	. /alcatel/var/home/oracle/.grid_profile
	. $ORACLE_HOME/oraInst.loc
else
	log_message "ERROR" "Grid not present!"
	exit 1
fi

GRIDHOME=${ORACLE_HOME}
INVENTORY=${inventory_loc}/ContentsXML/inventory.xml

HOMELIST=`cat $INVENTORY | grep "CRS=\"true\"" | sed s/LOC=/@/g | $AWK -F@ '{print $2}' | $AWK '{print $1}' | sed s/\"//g`

for i in $HOMELIST
do
        log_message "INFO" "Remove from inventory ${i}"
        su - oracle -c "cd /; ${GRIDHOME}/oui/bin/runInstaller -updateNodeList ORACLE_HOME=\"${i}\" CRS=false"
done

su - oracle -c "cd /; ${GRIDHOME}/oui/bin/runInstaller -updateNodeList ORACLE_HOME=\"${GRIDHOME}\" CRS=true"

}



function_stop_pmon_and_oracle() {
# stop pmon 

log_message "INFO" "Stopping PMON linux"
if [ -f /alcatel/MS/MS_PMON/scripts/pmon.sh ]; then
	pmon_stop="/alcatel/MS/MS_PMON/scripts/pmon.sh stop"
	$pmon_stop >/dev/null 2>&1 || exit 1
	/sbin/init q
fi
sleep 10

# shut down db
log_message "INFO" "*** STOPPING ORACLE DB *** "
oracle_stop

# stop grid listener
file="$ORA_HOME/.grid_profile"
su - oracle -c "
	. $file 
        ${OLD_GRID_HOME}/bin/lsnrctl status  2>&1" > /dev/null
listener_status=$?
if [ $listener_status -eq 0 ] ; then
    log_message "INFO" "GRID Listener is running" 
    log_message "INFO" "Stopping GRID listener" 
    su - oracle -c "
	. $file 
       ${OLD_GRID_HOME}/bin/lsnrctl stop"
else
    log_message "INFO" "GRID Listener is stopped"
fi

# stop grid for patching
$OLD_GRID_HOME/crs/install/roothas.pl -unlock

}

function_patch_grid() {

$OLD_GRID_HOME/crs/install/roothas.pl -patch

#configuration of response file
if [[ -f $OMC_UNIX_INSTALL_DIR/oracle/response.file/grid.rsp ]]
then
        cp $OMC_UNIX_INSTALL_DIR/oracle/response.file/grid.rsp /var/tmp
else
        log_message "ERROR" "$OMC_UNIX_INSTALL_DIR/oracle/response.file/grid.rsp file missing" 
        exit 1
fi
}


function_config_grid_profile_and_rsp() {

file="$ORA_HOME/.grid_profile"
[ -f $file ] && {
        ofile="${file}_`date '+%Y%m%d_%H%M%S'`"
        log_message "INFO" "Moving Oracle Grid .profile file (to $ofile)" 
        mv $file $ofile
}

log_message "INFO" "Creating Oracle Grid .profile file ($file)" 

cat <<- ! > $file
#Oracle Grid environment variable
ORACLE_BASE=$ORACLE_BASE ; export ORACLE_BASE
ORACLE_HOME=$GRID_HOME ; export ORACLE_HOME
ORACLE_SID=+ASM; export ORACLE_SID
!

chown oracle:oinstall $file
chmod 744 $file

log_message "INFO" "Parameters replacement in response file" 
INSTALL_TYPE="UPGRADE"

perl -pi.bak -e "
        s:(ORACLE_BASE=).*:\$1$ORACLE_BASE:;
        s:(INVENTORY_LOCATION=).*:\$1$ORACLE_INVLOC:;
        s:(ORACLE_HOME=).*:\$1$GRID_HOME:;
        s:(ORACLE_HOSTNAME=).*:\$1$HOSTNAME:;
        s:(oracle.install.option=).*:\$1$INSTALL_TYPE:;
        s:(oracle.install.asm.diskGroup.disks=).*:\$1$CLUSTER_DATA:;
        s:(oracle.install.asm.diskGroup.diskDiscoveryString=).*:\$1$CLUSTER_DATA:;
" /var/tmp/grid.rsp


chmod 700 /var/tmp/grid.rsp
chown oracle:oinstall /var/tmp/grid.rsp
}


function_runInstaller() {

mkdir -p $ORACLE_BASE
chmod +w $ORACLE_BASE

chmod 777 /opt/app
chmod 777 $ORACLE_BASE

run_installer=$location_for_disk1/runInstaller
[ -f "$run_installer" ] || {
        log_message "ERROR" "$run_installer not found!" >&2 
        usage
		exit 1
}
ps -ef | $AWK '/[r]unInstaller/{print "kill "$2}'       | sh

# Create new grid directory
(cd ${OLD_GRID_HOME}/..; mkdir ${PKGver}; chown oracle:oinstall ${PKGver})

# Run Grid upgrade 
log_message "INFO" "Installing Oracle Grid ..." 
su - oracle -c " cd /; $run_installer -ignoreSysPrereqs -ignorePrereq -silent -responseFile /var/tmp/grid.rsp"

sleep 30
set +e
echo "Please wait..."
while true
do
        ps -ef | egrep '[O]raInstall|[r]unInstaller' > /dev/null || break
        echo "..........................................................."; sleep 10
done

sleep 30
}

function_modif_grid_rights() {

log_message "INFO" "Changing rights on grid files according to Oracle note ID 1328629.1" 
chmod 0755 $GRID_HOME
chmod 1777 $GRID_HOME/auth/css/$HOSTNAME
chmod 1777 $GRID_HOME/auth/css/
chmod 1777 $GRID_HOME/auth/

}

function_upgrade_ASM_compat_param() {

# Upgrade ASM compatibility param for Cluster and ASM (Linux)
log_message "INFO" "FLASHBACK_STATUS = $FLASHBACK_STATUS"
if [ $FLASHBACK_STATUS = "NO" ]
then
	log_message "INFO" "Upgrading ASM compatibility parameter to $PKGver on all diskgroups" 

	su - oracle -c "
    . ~/.grid_profile
    $GRID_HOME/bin/sqlplus /nolog <<- EOF

    spool $logfile append
    connect / as sysasm

    SET SERVEROUTPUT ON
    declare
    V_sql varchar2(500);
    cursor c is select name from v\\\$asm_diskgroup;
    begin
                for i in c
                loop
                        dbms_output.put_line ( 'Alter diskgroup :' || i.name );
                        V_sql := 'ALTER DISKGROUP ' || i.name || ' SET ATTRIBUTE ''compatible.asm'' = ''' || '$PKGver' || '''';
                        dbms_output.put_line ( V_sql );
                        execute immediate V_sql;
                end loop;
    end;
    /
    disconnect
    spool off
    exit
EOF
"
fi

}


function_rootupgrade() {

	FLASHBACK_STATUS=NO

	log_message "INFO" "Run info_flashback script to check status" 
	$OMC_UNIX_INSTALL_DIR/oracle/info_flashback.sh  || {
                        log_message "ERROR" "$OMC_UNIX_INSTALL_DIR/oracle/info_flashback.sh failed."
                        exit 1
                        }
	sleep 5

	if [ -f /tmp/FLASHBACK.txt ]; then
        FLASHBACK_STATUS=`cat /tmp/FLASHBACK.txt | cut -d "=" -f2`
        export FLASHBACK_STATUS
	else
        log_message "WARNING" "/tmp/FLASHBACK.txt not present"
        exit 1
	fi


	# shut down db (again)
	log_message "INFO" "*** STOPPING ORACLE DB *** "
	oracle_stop

	bfile="rootupgrade.sh"
	file="$GRID_HOME/$bfile"	
	
	log_message "INFO" "Running configuration script ($file)" 
	[ -f "$file" ] || {
        log_message "ERROR" "$file not found. The installation of Oracle GRID failed!" >&2 
        exit 1
	}
	$file 1 > $ORACLE_INVLOC/logs/$bfile.out 2>$ORACLE_INVLOC/logs/$bfile.err

	function_modif_grid_rights
	if [ $ASM -eq 1 ]; then
        log_message "INFO" "Running $GRID_HOME/cfgtoollogs/configToolAllCommands" 
	su - oracle -c "
        $GRID_HOME/cfgtoollogs/configToolAllCommands
	"
	fi
	function_upgrade_ASM_compat_param
}


function_cleaning_and_start_pmon() {

	# Cleanup Old Grid patches to remove space
	log_message "INFO" "Cleanup Old Grid Directory using opatch" 
	su - oracle -c "
	cd $OLD_GRID_HOME/OPatch
./opatch util -silent Cleanup -oh $OLD_GRID_HOME
"
	log_message "INFO" "Cleanup Old Grid Directory manually" 
	rm -fr $GRID_HOME/.patch_storage/*

# Start PMON Linux
log_message "INFO" "Starting PMON linux" 
if [ -f /alcatel/MS/MS_PMON/scripts/pmon.sh ]; then
    pmon_start="/alcatel/MS/MS_PMON/scripts/pmon.sh start"
	$pmon_start >/dev/null 2>&1 || exit 1
	/sbin/init q
fi
sleep 10
}


###MAIN
function_initialize $1
function_set_crs_true
function_stop_pmon_and_oracle
function_patch_grid
function_config_grid_profile_and_rsp
function_runInstaller
function_rootupgrade
function_cleaning_and_start_pmon

} 2>&1 | tee -a ${logfile}
