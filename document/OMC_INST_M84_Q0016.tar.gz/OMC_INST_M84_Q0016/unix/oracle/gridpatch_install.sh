#!/bin/ksh
#set -x

OS_TYPE=`uname -s`
location_for_disk1=$location_for_disk1
ORA_HOME=/alcatel/var/home/oracle
ORACLE_HOME="/opt/app/oracle/product/11.2.0.2"
OLD_ORACLE_HOME_2="/opt/app/oracle/product/11.2.0"
ORACLE_BASE=/opt/app/oracle
ORACLE_INVLOC=$ORACLE_BASE/oraInventory

#Configuration parameters
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

ASM=$ASM
RAC=$RAC

if [ $RAC -eq 1 ]; then
        GRID_HOME=/opt/app/grid/11.2.0.2
        OLD_GRID_HOME=/opt/app/grid/11.2.0
else
        GRID_HOME=/opt/app/oracle/grid/11.2.0.2
        OLD_GRID_HOME=/opt/app/oracle/grid/11.2.0
fi

HOSTNAME=`hostname`
ORACLE_SID=SNM
LOG_FILE=${ORACLE_INVLOC}/logs/gridpatch_install.log_`date '+%d-%m-%y:%H:%M'`
touch $LOG_FILE
chmod 777 $LOG_FILE

check_patch()
{
        if [ $OS_TYPE = "SunOS" ]; then
                Patch=`/usr/bin/cat /var/tmp/patch |/usr/bin/grep $1`
                Patch=$?
        else
                Patch=`/bin/cat /var/tmp/patch | /bin/grep $1`
                Patch=$?
        fi
        if [[ $Patch -eq 0 ]];then
            echo 0
            return 0
        fi
        echo 1
        return 1
}



echo "Applying new OPatch version to Grid home" | tee -a $LOG_FILE

if [ $OS_TYPE = "Linux" ]; then
        if [ -f /tmp/OPatch_version.log ]; then
                /bin/rm /tmp/OPatch_version.log
        fi
        /bin/su - oracle -c "$OLD_GRID_HOME/OPatch/opatch version" > /tmp/OPatch_version.log
        /bin/egrep "OPatch Version: 11.2.0.1.6" /tmp/OPatch_version.log > /dev/null 2>&1
        check_version=$?
        if [[ $check_version -eq 1 ]]; then
                #install opatch patch
                /bin/cp $location_for_disk1/patches/p6880880_112000_Linux-x86-64.zip $OLD_GRID_HOME
		chmod 777 $OLD_GRID_HOME/p6880880_112000_Linux-x86-64.zip
                /bin/su - oracle -c "echo "A" |/usr/bin/unzip $OLD_GRID_HOME/p6880880_112000_Linux-x86-64.zip -d $OLD_GRID_HOME"
        fi
else
        if [ -f /tmp/OPatch_version.log ]; then
                /usr/bin/rm /tmp/OPatch_version.log
        fi
        /usr/bin/su - oracle -c "$OLD_GRID_HOME/OPatch/opatch version" > /tmp/OPatch_version.log
        /usr/bin/egrep "OPatch Version: 11.2.0.1.6" /tmp/OPatch_version.log > /dev/null 2>&1
        check_version=$?
        if [[ $check_version -eq 1 ]]; then
                #install opatch patch
                /usr/bin/cp $location_for_disk1/patches/p6880880_112000_SOLARIS64.zip $OLD_GRID_HOME
		chmod 777 $OLD_GRID_HOME/p6880880_112000_SOLARIS64.zip
                /usr/bin/su - oracle -c "echo "A" |/usr/bin/unzip $OLD_GRID_HOME/p6880880_112000_SOLARIS64.zip -d $OLD_GRID_HOME"
        fi
fi

PATH=/opt/app/oracle/grid/11.2.0/OPatch:$PATH; export PATH

echo "Apply patches to Grid 11.2.0.1 home" | tee -a $LOG_FILE

if [ $OS_TYPE = "SunOS" ]; then
        patch_oracle=`/usr/bin/ls $location_for_disk1/patches/ | /usr/bin/grep -v p12419353 | /usr/bin/grep -v p6880880 | /usr/bin/grep -v p9655006 | sort -r | /usr/bin/awk -F"_" '{print $1}' | /usr/bin/cut -f2 -d 'p'`
else
        patch_oracle=`/bin/ls $location_for_disk1/patches/ | /bin/grep -v p6880880 | /bin/awk '{print $1}' | /bin/cut -f1 -d '_' | /bin/cut -f2 -d 'p'`
fi

echo "$patch_oracle" | tee -a $LOG_FILE

if [ $OS_TYPE = "SunOS" ]; then
        /usr/bin/su - oracle -c " $OLD_GRID_HOME/OPatch/opatch lsinventory -oh $OLD_GRID_HOME > /var/tmp/patch"
        /usr/bin/sync
        /usr/bin/sleep 2
else
        /bin/su - oracle -c " $OLD_GRID_HOME/OPatch/opatch lsinventory -oh $OLD_GRID_HOME > /var/tmp/patch"
        /bin/sync
        /bin/sleep 2
fi

bpatch=0
for i in $patch_oracle ;do
        if [[ `check_patch $i` -eq 1 ]];then
           bpatch=1
        fi
done
if [[ bpatch -eq 0 ]];then
        echo "PATCH already installed!" | /usr/bin/tee -a $LOG_FILE
        exit 0
fi

for i in $patch_oracle;do
	mkdir -p /alcatel/OPatch
	chmod -R 777 /alcatel/OPatch
	if [ $OS_TYPE = "SunOS" ];then
		/usr/bin/cp $location_for_disk1/patches/p$i* /alcatel/OPatch
        	echo "A"| /usr/bin/unzip /alcatel/OPatch/p$i* -d /alcatel/OPatch/$i
		if [ -d /alcatel/grid/11.2.0 ] ; then
			chmod -R 777 /alcatel/grid/11.2.0
		fi
	else
		/bin/cp $location_for_disk1/patches/p$i* /alcatel/OPatch
		echo "A"| /usr/bin/unzip /alcatel/OPatch/p$i* -d /alcatel/OPatch/$i
	fi
		
done

chmod -R 777 $OLD_GRID_HOME

for i in $patch_oracle
do
    [[ `check_patch $i` = 1 ]] && {
	chmod -R 777 /alcatel/OPatch/$j
        if [ $OS_TYPE = "SunOS" ]; then
                /usr/bin/su - oracle -c " cd /alcatel/OPatch/$i; $OLD_GRID_HOME/OPatch/opatch napply -silent -ocmrf /var/tmp/ocm.rsp -oh $OLD_GRID_HOME"  | /usr/bin/tee -a $LOG_FILE
                /usr/bin/cat <<- ! >> /etc/MUSE.signature
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                      -=( Oracle Grid patch $i )=-
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
!
        else
                /bin/su - oracle -c " cd /alcatel/OPatch/$i; $OLD_GRID_HOME/OPatch/opatch napply -silent -ocmrf /var/tmp/ocm.rsp -oh $OLD_GRID_HOME"  | /usr/bin/tee -a $LOG_FILE
                /bin/cat <<- ! >> /etc/MUSE.signature
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                      -=( Oracle Grid patch $i )=-
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
!
        fi
}
rm -rf /alcatel/OPatch/$j
done
