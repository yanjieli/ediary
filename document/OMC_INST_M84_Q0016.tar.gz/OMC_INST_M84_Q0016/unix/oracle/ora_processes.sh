#!/bin/ksh

#                     Stop/Start oracle processes
#                     Last update: 11.01.2017
#                     Author : Andrei JURJ
#set -x

# Set ORACLE_HOME to be equivalent to the ORACLE_HOME
ora_version=`awk -F: '$1 ~/^SNM$/ {print $2}' /etc/oratab | sed -e "s#.*product/##"`
ORACLE_HOME=/opt/app/oracle/product/${ora_version}
GRID_HOME=/opt/app/oracle/grid/${ora_version}
ORACLE_OWNER=oracle
ORACLE_DB_SID=SNM
nr_attempts=0

OMC_HOME=/alcatel/MS

function check_db_state {
	i=0
	max_attempts=10
	db_off=false
	while ((i<max_attempts))
	do
		db_state=$(${GRID_HOME}/bin/crsctl stat res -t | awk '/ora.snm.db/ {getline;print $3}')
		echo "[`date '+%d-%m-%y %H:%M:%S'`]: DB state (crsctl): $db_state"
		if [ "$db_state" == "OFFLINE" ]; then
			ps -ef | egrep "[o]ra_pmon_$ORACLE_DB_SID" > /dev/null
			status=$?
			if [ $status -eq 0 ]; then
				echo "[`date '+%d-%m-%y %H:%M:%S'`]: ora_pmon_$ORACLE_DB_SID is still running."
			else
				echo "[`date '+%d-%m-%y %H:%M:%S'`]: ora_pmon_$ORACLE_DB_SID is not running"
				echo "[`date '+%d-%m-%y %H:%M:%S'`]: Database was successfully shutdown!"
				db_off=true
			fi
		fi
		$db_off && break
		((i++))
		echo "[`date '+%d-%m-%y %H:%M:%S'`]: Warning: Database is not shutdown! Waiting more time ($i/$max_attempts)"
		sleep 30
	done
	$db_off || {
		echo "[`date '+%d-%m-%y %H:%M:%S'`]: ERROR: Database failed to shutdown!!!!"
		exit 1
	}
}

function start_oracle {
	# Start the Oracle databases / ASM and nodeapps:
	# The following command assumes that the oracle login will not prompt the
	# user for any values


	echo ""
	echo "========================================================================="
	echo "[`date '+%d-%m-%y %H:%M:%S'`]: WAIT UNTIL ORACLE PROCESSES ARE STARTED!!!"
	echo "========================================================================="

	su - $ORACLE_OWNER -c "
		$ORACLE_HOME/bin/srvctl start database -d ${ORACLE_DB_SID}
		sleep 30
	"

	db_state=$($GRID_HOME/bin/crsctl stat res -t | awk '/ora.snm.db/ {getline;print $3}')
	echo "[`date '+%d-%m-%y %H:%M:%S'`]: DB state: $db_state"

	if [ "$db_state" == "ONLINE" ]; then
		echo "[`date '+%d-%m-%y %H:%M:%S'`]: Database was successfully started!"
	else
		echo "[`date '+%d-%m-%y %H:%M:%S'`]: Warning:Database failed to start! DB state is still OFFLINE!"
	fi
}



function stop_oracle {
	# Stop the Oracle databases / ASM and nodeapps:
	# The following command assumes that the oracle login will not prompt the
	# user for any values

	echo ""
	echo "========================================================================="
	echo "[`date '+%d-%m-%y %H:%M:%S'`]: WAIT UNTIL ORACLE PROCESSES ARE STOPPED!!!"
	echo "========================================================================="

	env | grep ORA
	set -x

	su - $ORACLE_OWNER -c "
	export ORACLE_SID=$ORACLE_DB_SID
	$ORACLE_HOME/bin/sqlplus -s /nolog <<- EOF
	connect / as sysdba
	shutdown immediate
	exit
	EOF
	"
	sleep 30
	check_db_state
}

case "$1" in

'start')

	start_oracle

;;

'stop')

	stop_oracle

;;

esac
