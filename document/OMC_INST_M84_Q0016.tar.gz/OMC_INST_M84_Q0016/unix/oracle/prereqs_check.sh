#!/bin/ksh

############################################################################################
#		- Check prereqs
#		- Create config file - needed for import (RAC)
#				     
#
#
#	        Author : Ciurea Cristian 17.10.2007	
#
############################################################################################

BACKUPDIR=/alcatel/oracle/oradata
DB_NAME=SNM
DEBUG=$1
ORACLE_HOME_PATH=/alcatel/var/home/oracle
ARCH_DIR=/alcatel/oracle/admin
CONFIG_FILE=${BACKUPDIR}/config

#Find running instance
RunningInstance=`ps  -e -o args | awk '
        BEGIN {Total=0}
        /\/alcatel\/omc1\/MS_PMON\/bin\/pmon/ { Total+=1}
        /\/alcatel\/omc2\/MS_PMON\/bin\/pmon/ { Total+=2}
        END { print Total}'`
case $RunningInstance in
        1)      export OMC_INSTANCE=1
                ;;
        2)      export OMC_INSTANCE=2
                ;;
        *)      echo "ERROR: 2 instances are running!"
                echo "       Delete the old instance and run again this script!"
                exit 1
                ;;
esac

echo "======================================================================================================="
echo " "

#delete config file
rm -fr ${CONFIG_FILE}

HOSTNAME=`hostname`
SIZE=`du -sk ${BACKUPDIR} | awk '{print $1}'`
BACK_UP_SIZE=`perl -e '$SIZE="'$SIZE'"; $MB_SIZE=int($SIZE / 1048576); print $MB_SIZE;'`

#get device for oradata partition
STOREDGE_DEVICE=`awk '$3~/oradata/ {print $1}' /etc/vfstab`
if [ -b $STOREDGE_DEVICE ]
then
        echo "SUN-StorEdge device: $STOREDGE_DEVICE"
else
        echo "ERROR detecting SUN-StorEdge device"
fi

ARCH_SIZE=`du -sk ${ARCH_DIR} | awk '{print $1}'`
ARCH_MB_SIZE=`perl -e '$ARCH_SIZE="'$ARCH_SIZE'"; $MB_SIZE=int($ARCH_SIZE / 1048576); print $MB_SIZE;'`
echo " " 
echo "=======================================DISPLAY MACHINE PARAMETERS======================================" 
echo " "
echo "=======================================DATABASE SIZE - $BACK_UP_SIZE GB  ======================================"
echo "OMC_INSTANCE=$OMC_INSTANCE" |tee -a ${CONFIG_FILE}
echo "DATABASE_SIZE=$BACK_UP_SIZE""GB" |tee -a ${CONFIG_FILE}
echo "HOSTNAME=$HOSTNAME" |tee -a ${CONFIG_FILE}
echo "OMC_HOME=omc"$OMC_INSTANCE |tee -a ${CONFIG_FILE}
echo "OMC_DB_USER=omc_"${HOSTNAME}${OMC_INSTANCE} |tee -a ${CONFIG_FILE}
echo "ARCH_DIR_SIZE="$ARCH_MB_SIZE"GB" |tee -a ${CONFIG_FILE}
echo "STOREDGE_DEVICE=$STOREDGE_DEVICE" |tee -a ${CONFIG_FILE}
echo " "
echo "======================================================================================================="
echo " "
echo "=====================================  CONFIGURATION OK  =============================================="
exit 0
