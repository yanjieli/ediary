#!/bin/ksh

#                 Update failed oracle config files resulted from Clusterware
#                 Author : Mocan Cristina
#                 Last Update : 22.04.2008

#set -x

CRS_HOME=/opt/app/oracle/crs/
HOSTNAME=`hostname`

function get_network {
        ip=$1
        hexmask=$2
        subnet=""
        i=1
        while [ $i -ne 5 ]
        do
                j=$((i*2-1))
                d1=`echo $ip | awk -F"." '{print $'"$i"'}'`
                n1=`echo $hexmask | awk '{print substr($0,'"$j"',2) }'`
                n1=$((16#$n1))
                let " s[i] =  n1 "
                i=$(($i+1))
        done
        subnet=${s[1]}.${s[2]}.${s[3]}.${s[4]}
}

interface=`netstat -i | awk '$3~/^'"$HOSTNAME"'$/ {print $1}`

vip_interface=`ifconfig -a | grep $interface:1`
if [[ "$vip_interface" != "" ]];
then
	echo "The VIP interface is configured!"
else	
	first_ip=`awk '$2 ~ /^'"${HOSTNAME}"'$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
	echo $first_ip
        hexmask=`ifconfig -a | awk '$2~/^'"$first_ip"'$/ {print $0}' | awk ' { print $4 } '`
	echo $hexmask
	
	get_network $first_ip $hexmask 
        mask_net=$subnet
	echo $mask_net

	cmd="$CRS_HOME/bin/srvctl add nodeapps -n $HOSTNAME -o $CRS_HOME -A $HOSTNAME-vip/$mask_net/$interface"
	echo "Run $cmd"
	$cmd 
	cmd="$CRS_HOME/bin/srvctl start nodeapps -n $HOSTNAME"
	echo "Run $cmd"
        $cmd
	echo "Finish configure VIP interface!"
fi
