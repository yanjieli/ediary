#!/usr/bin/expect -f
sleep 5
spawn /usr/bin/obtool
set timeout 5
expect "login:"
send "admin\r"
expect "Password:"
send "admin\r"
expect "ob>"
send "chuser oracle --class admin\r"
expect "ob>"
send "chuser oracle --preauth \"*:oracle+cmdline+rman\"\r"
expect "ob>"
send "lsuser -l oracle\r"
expect "ob>"
