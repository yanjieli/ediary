#!/bin/ksh

ORA_HOME=/alcatel/var/home/oracle
ORACLE_BASE=/opt/app/oracle
ORACLE_INVLOC=$ORACLE_BASE/oraInventory
ORACLE_HOME="/opt/app/oracle/product/11.2.0.2"
GRID_HOME_CRS=/opt/app/grid/11.2.0.2
OLD_GRID_HOME_CRS=/opt/app/oracle/crs
OLD_ORACLE_HOME=/opt/app/oracle/product/10.2.0
hostsfile=/etc/inet/hosts
oratabfile=/var/opt/oracle/oratab

NODELIST=`$OLD_GRID_HOME_CRS/bin/olsnodes`
HOSTNAME=`hostname`
ORACLE_SID=SNM
OS_TYPE=`uname -s`
logfile=/alcatel/install/log/prepare_SLAVE.log_`date '+%d-%m-%y:%H:%M'`
touch $logfile
chmod 777 $logfile

ASM_GID=1053

INSTALL_LIB_DIR="${OMC_UNIX_INSTALL_DIR}/lib"
install_file="${INSTALL_LIB_DIR}/install.sh"
        if [ ! -f $install_file ];then
                echo "ERROR [INSTALL]: $install_file file not found" >&2
                exit 1
        fi
. $install_file

function check_free_space {
        check_part=$1
        free_mb=`df -k $check_part | awk ' $1 !~ /Filesystem/ { print int($4/1024)}'`
}

if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
else
	log_message "ERROR" "/install/data/cluster.conf not found." | tee -a $logfile
	exit 1
fi

if [ $CLUSTER_TYPE != "SLAVE" ]
then
	log_message "INFO" "CLUSTER_TYPE = $CLUSTER_TYPE " | tee -a $logfile
	log_message "INFO" "This script is only for SLAVE node" | tee -a $logfile
	exit 1
fi

ASM_INSTANCE=+ASM2
ps -ef | grep $ASM_INSTANCE >/dev/null
if [ $? -ne 0 ]
then
	log_message "ERROR" "$ASM_INSTANCE not running" | tee -a $logfile
	exit 1
else
	log_message "INFO" "Found ASM instance $ASM_INSTANCE" | tee -a $logfile
fi

if [ -f $hostsfile ]
then
	awk '{ if ( $1~ /^'"${FLOATING_IP}"'$/ && $2 ~ /-scan$/ ) exit 99 }' $hostsfile
	if [ $? -eq 99	]
	then
		log_message "INFO" "SCAN entry already present in $hostsfile" | tee -a $logfile
	else
		log_message "INFO" "Updating $hostsfile with SCAN" | tee -a $logfile	
		CLUSTER_NAME=`awk '$1 ~ /^'"${FLOATING_IP}"'$/ {print $2}' $hostsfile`
		perl -pi.bak -e "s:($FLOATING_IP).*:\$1\t\t$CLUSTER_NAME-scan:;" $hostsfile
	fi
else
	 log_message "ERROR" "$hostsfile file does not exists." | tee -a $logfile
	exit 1
fi

if [ -f ./response.file/spfile+ASM.ora ]
then
	log_message "INFO" "Copy ./response.file/spfile+ASM.ora to $OLD_ORACLE_HOME/dbs" | tee -a $logfile
	cp ./response.file/spfile+ASM.ora $OLD_ORACLE_HOME/dbs
	chown oracle:oinstall $OLD_ORACLE_HOME/dbs/spfile+ASM.ora
else
	log_message "ERROR" "./response.file/spfile+ASM.ora not found!" | tee -a $logfile
	exit 1
fi

if [ -f /SECURITY/ALUipf/scripts/ipf_command.sh ]
then
	log_message "INFO" "Disable ALUipf" | tee -a $logfile
	/SECURITY/ALUipf/scripts/ipf_command.sh -d
fi

if [ -f /etc/rc3.d/S90ipfilter ]
then
	log_message "INFO" "Rename /etc/rc3.d/S90ipfilter" | tee -a $logfile
	mv /etc/rc3.d/S90ipfilter /etc/rc3.d/_S90ipfilter
fi

log_message "INFO" "Disable auditing and ipfilter" | tee -a $logfile
svcadm disable svc:/system/auditd:default
svcadm disable svc:/network/ipfilter:default

# -=-=-=-
#  Group
# -=-=-=-
#
file="/etc/group"
gid=$ASM_GID
for gname in "asmadmin" "asmdba" "asmoper"
do
egrep "^${gname}:" $file > /dev/null || {
        log_message "INFO" "Adding $gname group in $file" | tee -a $logfile
        log_message "INFO" "${gname}::${gid}:oracle" >> $file
}
gid=`expr $gid + 1`
done

file="$ORA_HOME/.grid_profile"
[ -f $file ] && {
        ofile="${file}_`date '+%Y%m%d_%H%M%S'`"
        log_message "INFO" "Moving Oracle Grid .profile file (to $ofile)" | tee -a $logfile
        mv $file $ofile
}

log_message "INFO" "Creating Oracle Grid .profile file ($file)" | tee -a $logfile
if [ $RAC -eq 1 ]; then
cat <<- ! > $file
#Oracle Grid environment variables
ORACLE_BASE=$ORACLE_BASE ; export ORACLE_BASE
ORACLE_HOME=$GRID_HOME_CRS ; export ORACLE_HOME
ORACLE_SID=$ASM_INSTANCE; export ORACLE_SID
PATH=$GRID_HOME_CRS/bin:/usr/bin:/bin; export PATH
LD_LIBRARY_PATH=$GRID_HOME_CRS/lib; export LD_LIBRARY_PATH
!
fi

chown oracle:oinstall $file
chmod 744 $file

chmod 777 /opt/app

log_message "INFO" "Check free space on /opt" | tee -a $logfile
check_free_space "/opt"
if [ $free_mb -lt 10000 ]; then
	log_message "WARNING" "only ${free_mb}MB free space, need at least 10000MB in /opt" | tee -a $logfile

	#Move Oracle in /alcatel partition if enough space
	log_message "INFO" "Check free space on /alcatel" | tee -a $logfile
	check_free_space "/alcatel"

	if [ $free_mb -gt 10000 ]; then

		log_message "INFO" "*** STOPPING ORACLE DB *** " | tee -a $logfile
		oracle_stop

                $OLD_GRID_HOME_CRS/bin/crsctl stop crs
                sleep 100

		#Move Oracle
                if [ -d $OLD_GRID_HOME_CRS ];then
                	log_message "INFO" "Move CRS (10.2.0.3) on /alcatel" | tee -a $logfile
                	log_message "INFO" "PLEASE WAIT..."
                	mv $OLD_GRID_HOME_CRS /alcatel
                	ln -s /alcatel/crs $OLD_GRID_HOME_CRS
		fi
                if [ -d $OLD_ORACLE_HOME ]; then
                	log_message "INFO" "Move Oracle Product (10.2.0) on /alcatel" | tee -a $logfile
                	mkdir -p /alcatel/product
                	mv $OLD_ORACLE_HOME /alcatel/product
                	ln -s /alcatel/product/10.2.0 $OLD_ORACLE_HOME
                fi

                #Start Oracle
                $OLD_GRID_HOME_CRS/bin/crsctl start crs
                sleep 100

		log_message "INFO" "*** STARTING ORACLE DB *** " | tee -a $logfile
		oracle_start
		wait_for_oracle

	else
		log_message "WARNING" "only ${free_mb}MB free space, need at least 10000MB in /alcatel" | tee -a $logfile
		exit 1
	fi
fi

