#!/bin/ksh

############################################################################################
#		- Add node procedure (migrate database from single instance to RAC)
#		- Restore /alcatel/oracle/admin, /alcatel/omc[12] (tablespace) 
#				     
#
#
#	        Author : Cristian Ciurea 06.10.2007	
#
############################################################################################

BACKUPDIR=/alcatel/oracle/oradata
DB_NAME=SNM
DEBUG=$1
DATA_DIR=${BACKUPDIR}/data
LOGFILE=/alcatel/install/log/restore_data.log
RMAN_BACK_DIR=/alcatel/backup
mkdir -p ${RMAN_BACK_DIR}
chown oracle:oinstall ${RMAN_BACK_DIR}
chmod 777 ${RMAN_BACK_DIR}

if [ -n $DEBUG ]
then
	DEBUG=0
fi

#public and private IP cables must be connected
if [ -f ../lib/install.sh ]
then
        . ../lib/install.sh
        check_ip_links || {
                exit 1
        }
else
        echo "ERROR install.sh not ../lib/install.sh not found!" |  tee -a $LOGFILE
        exit 1
fi

touch ${BACKUPDIR}/test
RETURN=$?
if [ $RETURN -ne 0 ]
then
	echo " STORAGE NOT CORRETLY MOUNTED !!!!!"
	exit 1
fi 
#Obtain instance number
if [ -f ${BACKUPDIR}/config ]
then 
	. ${BACKUPDIR}/config
else
	echo "ERROR ${BACKUPDIR}/config not found" | tee -a $LOGFILE
	exit 1
fi

cat >$2 <<!
OMC_INSTANCE=$OMC_INSTANCE
BACK_UP_SIZE=$BACK_UP_SIZE
HOSTNAME=$HOSTNAME
INSTANCE_COUNT=$INSTANCE_COUNT
OMC_HOME=$OMC_HOME
OMC_DB_USER=$OMC_DB_USER
!

#Check if corrent instance was installed
if [ -d /alcatel/${OMC_HOME} ]
then
	echo " Correct instance installed ! "
else
	echo " Install RAC on instance ${OMC_HOME} !!!!!!!!!!!" 
	exit 1     
fi

echo "Log file $LOGFILE"
echo "======================================================================="
echo  `date`
echo " "
OLD_OMC=`ls ${DATA_DIR} | grep omc`
if [ -f ${DATA_DIR}/*.dbf ]
then
	echo "Restore /alcatel/${OMC_HOME}/OMC_DBCF/userdata/*.dbf file" | tee -a $LOGFILE
	cp -pr ${DATA_DIR}/*.dbf /alcatel/${OMC_HOME}/OMC_DBCF/userdata/ | tee -a $LOGFILE
else
	echo "ERROR ${DATA_DIR}/*.dbf not found!" | tee -a $LOGFILE
	exit 1
fi

if [ -d ${DATA_DIR}/admin ]
then
	echo "Restore /alcatel/oracle/admin directory" | tee -a $LOGFILE
	cp -rp ${DATA_DIR}/admin /alcatel/oracle | tee -a $LOGFILE
else
	echo "ERROR ${DATA_DIR}/admin directory does not exits!" | tee -a $LOGFILE
	exit 1
fi
if [ -d ${BACKUPDIR}/backup/rman ]
then
	echo "Restore RMAN database backup in ${RMAN_BACK_DIR}" | tee -a $LOGFILE
	cp -rp ${BACKUPDIR}/backup/rman/* ${RMAN_BACK_DIR} | tee -a $LOGFILE
else
	echo "ERROR: ${BACKUPDIR}/backup/rman directory does not exits!" | tee -a $LOGFILE
	exit 1
fi

#start configure the database
echo " "
echo "Remove old RAC instance "  | tee -a $LOGFILE
if [ ${DEBUG} -eq 1 ]; then
       	sh -x remove_instance.sh
       	sh -x restore_database.sh
	sh -x create_rac_instance.sh	
else
	sh remove_instance.sh | tee -a $LOGFILE
	sh restore_database.sh | tee -a $LOGFILE
	sh create_rac_instance.sh | tee -a $LOGFILE
fi 
echo "======================================================================="
if [ -x /alcatel/omc${OMC_INSTANCE}/MUSE_SERVER/scripts/runLDAPExport.sh ]
then
	echo "Get LDAP database from Oracle." |  tee -a $LOGFILE
	/alcatel/omc${OMC_INSTANCE}/MUSE_SERVER/scripts/runLDAPExport.sh | tee -a $LOGFILE
else
	echo "ERROR: can not perform runLDAPExport.sh" |  tee -a $LOGFILE
fi
echo "======================================================================="

