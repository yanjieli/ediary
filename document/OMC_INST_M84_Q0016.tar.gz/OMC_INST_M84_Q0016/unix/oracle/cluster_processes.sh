#!/bin/ksh

#                     Stop oracle cluster processes
#                     Last update: 15.08.2008
#                     Author : Mocan Cristina

#set -x

# Set ORACLE_HOME to be equivalent to the ORACLE_HOME
ORACLE_HOME=/opt/app/grid/11.2.0.3
ORACLE_OWNER=oracle

OMC_HOME=/alcatel/MS
OLS_NODES=/opt/app/grid/11.2.0.3/bin/olsnodes
nodes_list=`$OLS_NODES`

case "$1" in

'start')

# Start the Oracle databases / ASM and nodeapps:
# The following command assumes that the oracle login will not prompt the
# user for any values
echo ""
echo "=============================================="
echo "WAIT UNTIL ALL ORACLE PROCESSES ARE STARTED!!!"
echo "=============================================="

	$ORACLE_HOME/bin/crsctl start crs
	sleep 100

su - $ORACLE_OWNER -c "
        $ORACLE_HOME/bin/srvctl start database -d SNM
        sleep 30
        "

if [ -f $OMC_HOME/OMC_DBCF/scripts/restart_services.sh ]; then
	echo "Restart services"
	$OMC_HOME/OMC_DBCF/scripts/restart_services.sh
else
        echo "The script doesn't exist in this version!"
fi

;;

'stop')

# Stop the Oracle databases / ASM and nodeapps:
# The following command assumes that the oracle login will not prompt the
# user for any values

echo ""
echo "=============================================="
echo "WAIT UNTIL ALL ORACLE PROCESSES ARE STOPPED!!!"
echo "=============================================="

su - $ORACLE_OWNER -c "
        $ORACLE_HOME/bin/srvctl stop database -d SNM
        sleep 30
        "

$ORACLE_HOME/bin/crsctl stop crs
sleep 100

;;

esac
