#!/bin/bash

logfile=/alcatel/install/log/psu_postinstall.log_`date '+%d-%m-%y:%H:%M'`

scr_location=$(dirname $0)

INSTALL_LIB_DIR="${scr_location}/../lib"
install_file="${INSTALL_LIB_DIR}/install.sh"

        if [ ! -f $install_file ];then
                echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR [INSTALL]: $install_file file not found" >&2
                exit 1
        fi
. $install_file

if [ ! "$(whoami)" = "oracle" ];then
	echo "this script should be run as user oracle ..."
	exit 
fi

export ORACLE_HOME=/opt/app/oracle/product/11.2.0.4
export PATH=$PATH:$ORACLE_HOME/bin
export ORACLE_SID=SNM

cd $ORACLE_HOME/rdbms/admin

oracle_stop | tee -a $logfile

sqlplus /nolog <<- EOF
connect / as sysdba
startup
@utlrp.sql
@catbundle.sql psu apply
EOF

oracle_stop | tee -a $logfile

cd $ORACLE_HOME/sqlpatch/22674697
sqlplus /nolog <<- EOF
connect / as sysdba
startup upgrade
@postinstall.sql
EOF

oracle_stop | tee -a $logfile

cd $ORACLE_HOME/rdbms/admin
sqlplus /nolog <<- EOF
connect / as sysdba
startup
@utlrp.sql
quit
EOF



