#!/bin/ksh
# this script must be started on RAC Sslave
# it will add the 3 groups needed by Oracle 11 Grid

ASM_GID=1053

# -=-=-=-
#  Group
# -=-=-=-
#
file="/etc/group"
gid=$ASM_GID
for gname in "asmadmin" "asmdba" "asmoper"
do
egrep "^${gname}:" $file > /dev/null || {
        echo "Adding $gname group in $file"
        echo "${gname}::${gid}:oracle" >> $file
}
gid=`expr $gid + 1`
done

