alter system switch logfile;
SET SERVEROUTPUT ON;
declare
         switchlog varchar2(1024);
        checkpoint varchar2(1024);
        logstatus varchar2(1024);
        groupnr varchar2(1024);
        dropredo varchar2(1024);
  cursor redos is select a.status,a.group# from v$log a, v$logfile b where a.group# = b.group# and b.MEMBER like '%redo%';
begin
   open redos;
   switchlog := 'alter system switch logfile';
   checkpoint := 'ALTER SYSTEM CHECKPOINT GLOBAL';
   dropredo := 'ALTER DATABASE DROP LOGFILE GROUP ';
   fetch redos into logstatus,groupnr;
   if logstatus='CURRENT' then
        dbms_output.put_line('REDOLOG status ' || logstatus);
        execute immediate switchlog;
        execute immediate checkpoint;
        execute immediate dropredo || groupnr;
   elsif logstatus='INACTIVE' THEN
        execute immediate checkpoint;
        execute immediate dropredo || groupnr;
        dbms_output.put_line('REDOLOG status ' || logstatus);
   elsif logstatus='ACTIVE' THEN
        execute immediate switchlog;
        execute immediate checkpoint;
        execute immediate dropredo || groupnr;
   else
        dbms_output.put_line('REDOLOG status ' ||'Redolog not in good condition ');
   end if;
end;
/
declare
        lognr number;
  cursor redos is select count(*) from v$log a, v$logfile b where a.group# = b.group# and b.MEMBER like '%redo%';
begin
   open redos;
   fetch redos into lognr;
   if lognr>=1 then
        dbms_output.put_line('===========================================================');
        dbms_output.put_line('WARNING: REDOLOG status not good! Please check logs !!!!');
        dbms_output.put_line('===========================================================');
   else
        dbms_output.put_line('===========================================================');
        dbms_output.put_line('REDOLOG status OK');
        dbms_output.put_line('===========================================================');
   end if;
end;
/
