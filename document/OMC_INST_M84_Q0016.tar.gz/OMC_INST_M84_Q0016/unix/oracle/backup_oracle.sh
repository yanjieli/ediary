#!/bin/ksh

############################################################################################
#		- Backup Oracle database using RNAM
#		- Backup /alcatel/oracle/admin, /alcatel/omc[12]  
#				     
#
#
#	        Author : Ciurea Cristian 06.10.2007	
#
############################################################################################

set -- `df -k |grep -v swap |grep -v Filesys|grep alcatel|sort -rnk4|awk 'NR==1 {print $6" "$4}'`
#echo " Using $1 directory for export ..."
sleep 3
BACKUPDIR=/alcatel/oracle/oradata
MINSIZE=10242880
DB_NAME=SNM
DEBUG=$1
ORACLE_HOME_PATH=/alcatel/var/home/oracle
CONFIG_FILE=${BACKUPDIR}/config

#check if config file exist else exit with error
if [ ! -f ${CONFIG_FILE} ] 
then
	echo "         RUN FIRST SCRIPT prereqs_check.sh         "
	exit 1
fi

. ${CONFIG_FILE}
cat >$2 <<!
OMC_INSTANCE=$OMC_INSTANCE
BACK_UP_SIZE=$BACK_UP_SIZE
HOSTNAME=$HOSTNAME
INSTANCE_COUNT=$INSTANCE_COUNT
OMC_HOME=$OMC_HOME
OMC_DB_USER=$OMC_DB_USER
!

echo ""
if [ $2 -lt ${MINSIZE} ]
then
	echo "Partition /alcatel has to have at least 5GB free space ! Now is $2 KB"
	exit 1
fi

exptdir=${BACKUPDIR}/backup/rman
mkdir -p ${exptdir}
chown oracle:oinstall $exptdir
chmod 777 $exptdir
LOGFILE=${exptdir}/backup.log
rm -fr ${BACKUPDIR}/backup/rman/*

snmuser=$hostname${OMC_INSTANCE}

ORACLE_HOME=`cat $ORACLE_HOME_PATH/.profile |grep ORACLE_HOME |awk '{print $1}' |cut -d = -f2`

echo " +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" | tee -a $LOGFILE
if [ -x /alcatel/omc${OMC_INSTANCE}/MUSE_SERVER/scripts/runLDAPImport.sh ]
then
        echo "Import LDAP database to Oracle." |  tee -a $LOGFILE
        /alcatel/omc${OMC_INSTANCE}/MUSE_SERVER/scripts/runLDAPImport.sh | tee -a $LOGFILE
else
        echo "ERROR: can not perform runLDAPImport.sh" |  tee -a $LOGFILE
fi

echo " +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" | tee -a $LOGFILE
#create pfile from spfile
echo "Start backup database using RMAN" | tee -a $LOGFILE
echo " " | tee -a $LOGFILE
su - oracle -c "
export ORACLE_SID=$DB_NAME
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
	create pfile='${BACKUPDIR}/backup/rman/old_pfile.ora' from spfile;
        exit
EOF
" | tee -a $LOGFILE


echo " +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" | tee -a $LOGFILE
#Back database using RMAN
echo "Start backup database using RMAN" | tee -a $LOGFILE
echo " " | tee -a $LOGFILE
su - oracle -c "
export ORACLE_SID=$DB_NAME
$ORACLE_HOME/bin/rman target / nocatalog <<- EOF
	configure controlfile autobackup on;
       	backup current controlfile format='$exptdir/ctl_after_backup.ctl';
	
        exit
EOF
" | tee -a $LOGFILE 
echo " " | tee -a $LOGFILE
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" | tee -a $LOGFILE
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" | tee -a $LOGFILE
mkdir -p ${BACKUPDIR}/data
echo "Backup /alcatel/omc[12] on ${BACKUPDIR}/data"
echo `date` | tee -a $LOGFILE
cp -rp /alcatel/omc${OMC_INSTANCE}/OMC_DBCF/userdata/* ${BACKUPDIR}/data | tee -a $LOGFILE
echo "Backup /alcatel/oracle/admin  on ${BACKUPDIR}/data"
cp -rp /alcatel/oracle/admin ${BACKUPDIR}/data | tee -a $LOGFILE
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" | tee -a $LOGFILE

