#!/bin/sh

HOSTNAME=`hostname`
export HOSTNAME
KEYGEN=/usr/bin/ssh-keygen
export KEYGEN

ORA_UID=1050                            # oracle user  id (oracle)
ORA_GID=1050                            # oracle group id (oinstall)
ORA_PWD=Kj5W5TCFgPux.                   # oracle encrypt password
ORA_HOME=/alcatel/var/home/oracle       # oracle user home directory
export ORA_HOME
ROOT_HOME=`awk -F: '/^root:/{print $6}' /etc/passwd`
SERVER_HW=`uname -i`

export ROOT_HOME

# -=-=-=-
#  Group
# -=-=-=-
#
file="/etc/group"
gid=$ORA_GID
for gname in "oinstall" "dba" "oper"
do
egrep "^${gname}:" $file > /dev/null || {
        echo "Adding $gname group in $file"
        echo "${gname}::${gid}:oracle" >> $file
}
gid=`expr $gid + 1`
done


# -=-=-=-=-=-
#  Password
# -=-=-=-=-=-
#
file="/etc/passwd"
egrep '^oracle:' $file > /dev/null || {
        echo "Adding oracle user in $file"
        echo "oracle:x:${ORA_UID}:${ORA_GID}::${ORA_HOME}:/bin/ksh" >> $file
}


# -=-=-=-=-
#  Shadow
# -=-=-=-=-
#
file="/etc/shadow"
egrep '^oracle:' $file > /dev/null || {
        echo "Adding oracle user in $file"
        echo "oracle:${ORA_PWD}:11708::::::" >> $file
}


# -=-=-=-
#  Home
# -=-=-=-
#
[ -d "$ORA_HOME" ] || {
        echo "Creating oracle home directory ($ORA_HOME)"
        mkdir -p $ORA_HOME
        chown oracle:oinstall $ORA_HOME
}

cwd=`pwd`
tar_dir=$cwd
if [ x$OMC_UNIX_INSTALL_DIR != "x" ]
then
	tar_dir=$OMC_UNIX_INSTALL_DIR/oracle
fi

if [ ! -f $KEYGEN ]
then
        echo "ERROR: $KEYGEN not found."
        exit 1
fi

echo yes | $KEYGEN -t rsa -b 768 -N "" -f /etc/ssh/ssh_host_rsa_key
echo yes | $KEYGEN -t dsa -N "" -f /etc/ssh/ssh_host_dsa_key

#oracle configuration
	cd $ORA_HOME
	if [ -d .ssh ]
        then
                rm -fr .ssh
	else
		mkdir .ssh
		chown -R oracle:oinstall $ORA_HOME/.ssh
        fi
	if [ $SERVER_HW = "SUNW,Sun-Fire-V490" ]
	then
		tar xvf  $tar_dir/oracle_ssh.tar
	else
		su - oracle -c "echo yes | $KEYGEN -t dsa -N '' -f ${ORA_HOME}/.ssh/id_dsa"	
		su - oracle -c "echo yes | $KEYGEN -t rsa -N '' -f ${ORA_HOME}/.ssh/id_rsa"
	fi

	cp ${ORA_HOME}/.ssh/id_rsa.pub ${ORA_HOME}/.ssh/authorized_keys
	chown -R oracle:oinstall $ORA_HOME

axadmin_home=`awk -F:  '$1 ~ /^axadmin$/ {print $6}' /etc/passwd`
export axadmin_home
#axadmin configuration
        cd $axadmin_home
        if [ -d .ssh ]
        then
                rm -fr .ssh
	else
		mkdir .ssh 
		chown -R axadmin:gadmin $axadmin_home	
        fi
	if [ $SERVER_HW = "SUNW,Sun-Fire-V490" ]
        then
        	tar xvf  $tar_dir/axadmin_ssh.tar
	else
		su - axadmin -c "echo yes | $KEYGEN -t dsa -N '' -f ${axadmin_home}/.ssh/id_dsa"
        	su - axadmin -c "echo yes | $KEYGEN -t rsa -N '' -f ${axadmin_home}/.ssh/id_rsa"
	fi

        cp ${axadmin_home}/.ssh/id_rsa.pub ${axadmin_home}/.ssh/authorized_keys
        chown -R axadmin:gadmin $axadmin_home

#root configuration
	cd $ROOT_HOME
	if [ -d .ssh ]
        then
                rm -fr .ssh
	else
		mkdir .ssh
        fi
	if [ $SERVER_HW = "SUNW,Sun-Fire-V490" ]
        then
		tar xvf $tar_dir/root_ssh.tar
	else
		echo yes | $KEYGEN -t dsa -N '' -f ${ROOT_HOME}/.ssh/id_dsa
		echo yes | $KEYGEN -t rsa -N '' -f ${ROOT_HOME}/.ssh/id_rsa
	fi

	cp ${ROOT_HOME}/.ssh/id_rsa.pub ${ROOT_HOME}/.ssh/authorized_keys

cd $cwd

svcadm disable svc:/network/ssh:default
svcadm enable svc:/network/ssh:default

#key
mkdir -p /OracleClusterware/ssh_public_key/
chown oracle:oinstall /OracleClusterware/ssh_public_key/
chmod 755 /OracleClusterware/ssh_public_key/

su - oracle -c "
	cp .ssh/id_rsa.pub /OracleClusterware/ssh_public_key/id_rsa_${HOSTNAME}.pub
	cp .ssh/id_dsa.pub /OracleClusterware/ssh_public_key/id_dsa_${HOSTNAME}.pub
	cat /OracleClusterware/ssh_public_key/*.pub > .ssh/authorized_keys
"

su - axadmin -c "cat ./.ssh/*.pub > .ssh/authorized_keys"

if [ ! -L /usr/local/bin/ssh ]
then
	ln -s /usr/bin/ssh /usr/local/bin/ssh
fi

#Configure ssh for root, oracle and axadmin
cd $tar_dir
if [ -f script.exp ]
then
        cp ./script.exp /var/tmp/script.exp
else
        echo "ERROR: script.exp not found!"
fi

EXPR="s/__hostname__/${HOSTNAME}/g"
/usr/bin/sed $EXPR /var/tmp/script.exp > /var/tmp/script.exp.run
chmod +x /var/tmp/script.exp.run
echo "Configure ssh for root on localhost"
/var/tmp/script.exp.run
echo "Configure ssh for oracle on localhost"
su - oracle -c "/var/tmp/script.exp.run"
echo "Configure ssh for axadmin on localhost"
su - axadmin -c "/var/tmp/script.exp.run"

#In case of slave node
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

if [ $SERVER_HW = "SUNW,Sun-Fire-V490" ]
then
        SSHD_CONFIG=/etc/ssh/sshd_config
        grep "PermitRootLogin no" $SSHD_CONFIG
        if [ $? -eq 0 ]
        then
                echo "Updating $SSHD_CONFIG : permit remote root login"
                perl -pi.bak -e 's/^PermitRootLogin.*/PermitRootLogin yes/' $SSHD_CONFIG
        fi
fi

cat >$2 <<!
CLUSTER_TYPE=$CLUSTER_TYPE
MASTER_HOSTNAME=$MASTER_HOSTNAME
!

if [ $CLUSTER_TYPE = "SLAVE" ]
then
	REMOTE_SCRIPT_DIR=/var/tmp/sshscrit	
	EXPR="s/__hostname__/${MASTER_HOSTNAME}/g"
	/usr/bin/sed $EXPR /var/tmp/script.exp > /var/tmp/script.exp.mast
	chmod +x /var/tmp/script.exp.mast
	echo "Configure ssh for root to connect to ${MASTER_HOSTNAME}"
	/var/tmp/script.exp.mast
	echo "Configure ssh for oracle on localhost ${MASTER_HOSTNAME}"
	su - oracle -c "/var/tmp/script.exp.mast"
	echo "Configure ssh for axadmin on localhost ${MASTER_HOSTNAME}"
        su - axadmin -c "/var/tmp/script.exp.mast"

	#edit hostname on master 
	cd $tar_dir
	if [ -f addhosts.sh ]
	then
       		 cp ./addhosts.sh /var/tmp/addhosts.sh
	else
       		 echo "ERROR: addhosts.sh not found!"
	fi
	EXPR1="s/__HOST_SLAVE__/${HOSTNAME}/g"
	HOST_SLAVE_IP=`awk '$2 ~ /^'"${HOSTNAME}"'$/ && $1 !~ /^#/ {print $1}' /etc/hosts`	
        EXPR2="s/__HOST_SLAVE_IP__/${HOST_SLAVE_IP}/g"
	HOST_SLAVE_VIP=`awk '$2 ~ /^'"${HOSTNAME}"'-vip$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
        EXPR3="s/__HOST_SLAVE_VIP__/${HOST_SLAVE_VIP}/g"	
	HOST_SLAVE_PRIV=`awk '$2 ~ /^'"${HOSTNAME}"'-priv$/ && $1 !~ /^#/ {print $1}' /etc/hosts`
        EXPR4="s/__HOST_SLAVE_PRIV__/${HOST_SLAVE_PRIV}/g"
	/usr/bin/sed -e $EXPR1 -e $EXPR2 -e $EXPR3 -e $EXPR4 /var/tmp/addhosts.sh > /var/tmp/addhosts.sh.mast
	ssh ${MASTER_HOSTNAME} -l root mkdir -p $REMOTE_SCRIPT_DIR
	ssh ${MASTER_HOSTNAME} -l root chmod +w $REMOTE_SCRIPT_DIR
	scp /var/tmp/addhosts.sh.mast ${MASTER_HOSTNAME}:$REMOTE_SCRIPT_DIR
	#add slave hosts on master /etc/hosts
	echo "Add ${MASTER_HOSTNAME} hosntame in master /etc/hosts"
	ssh ${MASTER_HOSTNAME} -l root chmod +x $REMOTE_SCRIPT_DIR/addhosts.sh.mast
	ssh ${MASTER_HOSTNAME} -l root $REMOTE_SCRIPT_DIR/addhosts.sh.mast
	echo "Configure ssh on Master to connect to slave"
	scp /var/tmp/script.exp.run ${MASTER_HOSTNAME}:$REMOTE_SCRIPT_DIR
	ssh ${MASTER_HOSTNAME} -l root chmod +x $REMOTE_SCRIPT_DIR/script.exp.run
	ssh ${MASTER_HOSTNAME} -l root $REMOTE_SCRIPT_DIR/script.exp.run
	su - oracle -c "ssh ${MASTER_HOSTNAME} -l oracle $REMOTE_SCRIPT_DIR/script.exp.run"
	su - axadmin -c "ssh ${MASTER_HOSTNAME} -l axadmin $REMOTE_SCRIPT_DIR/script.exp.run"
fi

