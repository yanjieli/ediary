#!/bin/ksh
#set -x
#script for installing and configuring Oracle Secure Backup

OS=`uname`

#
# Functions
#

install_10_1() {

echo "Version is Oracle_solaris64_secure_backup_10.1.0.2"

cd /usr/local/oracle/backup

/bin/csh $path/setup $input <<END
1
no
END

sed -e "s/customized obparameters: no/customized obparameters: yes/" < /usr/local/oracle/backup/install/obparameters > /usr/local/oracle/backup/install/obparameters.temp
sed -e "s/create pre-authorized oracle user: no/create pre-authorized oracle user: yes/" < /usr/local/oracle/backup/install/obparameters.temp > /usr/local/oracle/backup/install/obparameters
rm /usr/local/oracle/backup/install/obparameters.temp
sed -e "s/^Listen.*/Listen 446/" < /usr/local/oracle/backup/apache/conf/httpd.conf.orig > /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp
cp /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp /usr/local/oracle/backup/apache/conf/httpd.conf.orig
rm /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp

sleep 5

/usr/local/oracle/backup/install/installdriver

sleep 10

ws=`hostname`
tape=1
condition=1

for i in 0 1 2 3 4 5 6 7 8 9
        do
        /usr/bin/mt -f /dev/rmt/${i}n config 2>/dev/null |egrep 'SDLT[36][02]0'\|'DAT.72'\|'LTO.3'\|'LTO.4' 1>/dev/null 2>&1
        condition=$?
        tape_search=`/usr/bin/mt -f /dev/rmt/${i}n config 2>/dev/null |egrep 'SDLT[36][02]0'\|'DAT.72'\|'LTO.3'\|'LTO.4' |cut -f2,4 -d '"'` 1>/dev/null 2>&1
        tape=$?
        if [ $tape -eq 0 ]
        then
                case $tape_search in
                *SDLT600*) tp=sdlt600;port=$i;break;;
                *SDLT320*) tp=sdlt320;port=$i;break;;
		*DAT*72*) tp=dat72;port=$i;break;;
		*LTO*3*) tp=lto3;port=$i;break;;
		*LTO*4*) tp=lto4;port=$i;break;;
                *) echo "No supported tape device found on /dev/rmt/${i}n, searching..."
                esac
                if [ $condition -eq 0 ]
                then
                        break
                fi
        fi
done

if [ $condition -ne 0 ]
then
        echo "\nNo existing tape  attached to the server or tape is offline"
        echo "Exiting installation script...\n"
        exit 0
fi

#3BKA17FBR298264.Correction introduced by Alex Gheboianu.
dir=`ls -l /dev/rmt/$port | cut -f2 -d '>' | sed -e 's/ //g' | cut -f5 -d '.' |
sed 's/st.*//'`
bus1=`ls $dir |grep pci |cut -f2 -d ':' |sed '/^$/d' | sed -e 's/ //g'`


count=`echo $bus1 | wc -m`
if [ $count -gt 2 ]
then
        echo "Bus is $bus1"
        break
else
        echo "No minor device found for the ob driver"
        echo "OSB installation will not continue"
        exit 1
fi

TGID=`ls -l /dev/rmt/$port | sed 's/.*st@//' | cut -d"," -f1`
LUN=`ls -l /dev/rmt/$port | sed 's/.*st@//' | cut -d"," -f2 | cut -d":" -f1`

/usr/local/oracle/backup/install/installob $in <<EOF
a
a
admin
admin
n
y
1
0
$bus1
$TGID
$LUN
y
no
EOF

sleep 5

su - oracle -c "
ln -s /usr/local/oracle/backup/lib/libobk.so /opt/app/oracle/product/11.2.0.3/lib/libobk.so"
su - oracle -c "$OMC_UNIX_INSTALL_DIR/oracle/obtool_config.sh"

sleep 10

su - oracle -c "
obtool << EOF
chhost --addrole mediaserver $ws
mkdev --type tape --attach $ws:/dev/obt0 $tp
EOF
"

}

install_10_2() {

echo "Version is Oracle_solaris64_secure_backup_10.2.0.2"

cd /usr/local/oracle/backup

/bin/csh $path/setup $input <<END
no
END

sed -e "s/customized obparameters: no/customized obparameters: yes/" < /usr/local/oracle/backup/install/obparameters > /usr/local/oracle/backup/install/obparameters.temp
sed -e "s/create pre-authorized oracle user: no/create pre-authorized oracle user: yes/" < /usr/local/oracle/backup/install/obparameters.temp > /usr/local/oracle/backup/install/obparameters
rm /usr/local/oracle/backup/install/obparameters.temp
sed -e "s/^Listen.*/Listen 446/" < /usr/local/oracle/backup/apache/conf/httpd.conf.orig > /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp
cp /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp /usr/local/oracle/backup/apache/conf/httpd.conf.orig
rm /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp

sleep 5

/usr/local/oracle/backup/install/installdriver

sleep 10

ws=`hostname`
tape=1
condition=1

for i in 0 1 2 3 4 5 6 7 8 9
        do
        /usr/bin/mt -f /dev/rmt/${i}n config 2>/dev/null |egrep 'SDLT[36][02]0'\|'DAT.72'\|'LTO.3'\|'LTO.4' 1>/dev/null 2>&1
        condition=$?
        tape_search=`/usr/bin/mt -f /dev/rmt/${i}n config 2>/dev/null |egrep 'SDLT[36][02]0'\|'DAT.72'\|'LTO.3'\|'LTO.4' |cut -f2,4 -d '"'` 1>/dev/null 2>&1
        tape=$?
        if [ $tape -eq 0 ]
        then
                case $tape_search in
                *SDLT600*) tp=sdlt600;port=$i;break;;
                *SDLT320*) tp=sdlt320;port=$i;break;;
                *DAT*72*) tp=dat72;port=$i;break;;
                *LTO*3*) tp=lto3;port=$i;break;;
                *LTO*4*) tp=lto4;port=$i;break;;
                *) echo "No supported tape device found on /dev/rmt/${i}n, searching..."
                esac
                if [ $condition -eq 0 ]
                then
                        break
                fi
        fi
done

if [ $condition -ne 0 ]
then
        echo "\nNo existing tape  attached to the server or tape is offline"
        echo "Exiting installation script...\n"
        exit 0
fi

#3BKA17FBR298264.Correction introduced by Alex Gheboianu.

dir=`ls -l /dev/rmt/$port | cut -f2 -d '>' | sed -e 's/ //g' | cut -f5 -d '.' |
sed 's/st.*//'`
bus1=`ls $dir |grep pci |cut -f2 -d ':' |sed '/^$/d' | sed -e 's/ //g'`

count=`echo $bus1 | wc -m`
if [ $count -gt 2 ]
then
        echo "Bus is $bus1"
        break
else
        echo "No minor device found for the ob driver"
        echo "OSB installation will not continue"
        exit 1
fi

TGID=`ls -l /dev/rmt/$port | sed 's/.*st@//' | cut -d"," -f1`
LUN=`ls -l /dev/rmt/$port | sed 's/.*st@//' | cut -d"," -f2 | cut -d":" -f1`

/usr/local/oracle/backup/install/installob $in <<EOF
a
admin
admin
admin
admin
root@$ws
n
y
1
0
$bus1
$TGID
$LUN
y
EOF

sleep 5

su - oracle -c "
ln -s /usr/local/oracle/backup/lib/libobk.so /opt/app/oracle/product/10.2.0/lib/libobk.so"
su - oracle -c "$OMC_UNIX_INSTALL_DIR/oracle/obtool_config.sh"

sleep 10

su - oracle -c "
obtool << EOF
chhost --addrole mediaserver $ws
mkdev --type tape --attach $ws:/dev/obt0 $tp
chuser oracle --rmdomain *
EOF
"

}

install_10_3() {

if [[ $OS = "SunOS" ]]
then
	echo "Version is Oracle_solaris64_secure_backup_10.3.0.1"
       cd /usr/local/oracle/backup

/bin/csh $path/setup $input <<END
no
END

sed -e "s/customized obparameters: no/customized obparameters: yes/" < /usr/local/oracle/backup/install/obparameters > /usr/local/oracle/backup/install/obparameters.temp
sed -e "s/create pre-authorized oracle user: no/create pre-authorized oracle user: yes/" < /usr/local/oracle/backup/install/obparameters.temp > /usr/local/oracle/backup/install/obparameters
rm /usr/local/oracle/backup/install/obparameters.temp
sed -e "s/^Listen.*/Listen 446/" < /usr/local/oracle/backup/apache/conf/httpd.conf.orig > /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp
cp /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp /usr/local/oracle/backup/apache/conf/httpd.conf.orig
rm /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp

sleep 5

/usr/local/oracle/backup/install/installdriver 

sleep 10

ws=`hostname`
tape=1
condition=1

for i in 0 1 2 3 4 5 6 7 8 9
        do
        /usr/bin/mt -f /dev/rmt/${i}n config 2>/dev/null |egrep 'SDLT[36][02]0'\|'DAT.72'\|'LTO.3'\|'LTO.4' 1>/dev/null 2>&1
        condition=$?
        tape_search=`/usr/bin/mt -f /dev/rmt/${i}n config 2>/dev/null |egrep 'SDLT[36][02]0'\|'DAT.72'\|'LTO.3'\|'LTO.4' |cut -f2,4 -d '"'` 1>/dev/null 2>&1
        tape=$?
        if [ $tape -eq 0 ]
        then
                case $tape_search in
                *SDLT600*) tp=sdlt600;port=$i;break;;
                *SDLT320*) tp=sdlt320;port=$i;break;;
                *DAT*72*) tp=dat72;port=$i;break;;
                *LTO*3*) tp=lto3;port=$i;break;;
                *LTO*4*) tp=lto4;port=$i;break;;
                *) echo "No supported tape device found on /dev/rmt/${i}n, searching..."
                esac
                if [ $condition -eq 0 ]
                then
                        break
                fi
        fi
done

if [ $condition -ne 0 ]
then
        echo "\nNo existing tape  attached to the server or tape is offline"
        echo "Exiting installation script...\n"
        exit 0
fi

SCSI=`ls -l /dev/rmt/$port | cut -f2 -d '>' | sed -e 's/ //g' | tr -s "[/]" "[\n]" |egrep 'scsi|sas'`
dir=`ls -R /devices |grep $SCSI:$ |cut -f1 -d ":"`

for i in $dir
do

echo "Directory is $i"

bus1=`ls $i |grep pci |cut -f2 -d ':' |sed '/^$/d' | sed -e 's/ //g'`
count=`echo $bus1 | wc -m`
if [ $count -gt 2 ]
then
        echo "Bus is $bus1"
        break
else
        echo "No bus found"
        bus1=0
fi
done

#Check is any bus found

if [ $bus1 = 0 ]
then
        echo "No minor device found for the ob driver"
        echo "OSB installation will not continue"
        exit 1
fi

TGID=`ls -l /dev/rmt/$port | sed 's/.*st@//' | cut -d"," -f1`
LUN=`ls -l /dev/rmt/$port | sed 's/.*st@//' | cut -d"," -f2 | cut -d":" -f1`

/usr/local/oracle/backup/install/installob $in <<EOF
a
admin
admin
admin
admin
root@$ws
n
y
1
0
$bus1
$TGID
$LUN
y
EOF

sleep 5

su - oracle -c "
ln -s /usr/local/oracle/backup/lib/libobk.so /opt/app/oracle/product/11.2.0.3/lib/libobk.so"
su - oracle -c "$OMC_UNIX_INSTALL_DIR/oracle/obtool_config.sh"

sleep 10

su - oracle -c "
obtool << EOF
chhost --addrole mediaserver $ws
mkdev --type tape --attach $ws:/dev/obt0 $tp
chuser oracle --rmdomain *
setp devices/errorrate none
EOF
"

else

echo "Version is Oracle_linux64_secure_backup_10.3.0.1"

cd /usr/local/oracle/backup
ln -s /bin/gunzip uncompress

tape=1
for i in 0 1 2 3 4 5 6 7 8 9
do
        /bin/mt -f /dev/st${i} status 1>/dev/null 2>&1
        tape=$?
        if [ $tape -eq 0 ]
        then
                echo "tape device found"
                break
        fi
done

if [[ $tape -ne 0 ]]
then
	echo "No tape device found"
	echo "Exiting installation script"
	exit 1
fi

/bin/csh $path/setup $input <<END
no
END

sed -e "s/customized obparameters: no/customized obparameters: yes/" < /usr/local/oracle/backup/install/obparameters > /usr/local/oracle/backup/install/obparameters.temp
sed -e "s/create pre-authorized oracle user: no/create pre-authorized oracle user: yes/" < /usr/local/oracle/backup/install/obparameters.temp > /usr/local/oracle/backup/install/obparameters
rm /usr/local/oracle/backup/install/obparameters.temp

sleep 5

ws=`hostname`

# get scsi information
SCSInfo=/tmp/scsi.info
rm -fr $SCSInfo
cat /proc/scsi/scsi | egrep -B 2 Sequential-Access > $SCSInfo

if [[ -s $SCSInfo ]]
then
	echo "Parsing $SCSInfo"
else
	echo "File $SCSInfo not ok"
	echo "exiting installation script"
	exit 1
fi

SCSIadapter=`cat $SCSInfo | grep Host | awk '{print $2}' | sed -e 's/[a-z]\{1,4\}//'`
SCSIbus=`cat $SCSInfo | grep Host | awk '{print $4}'`
SCSItarget=`cat $SCSInfo | grep Host | awk '{print $6}'`
SCSIlun=`cat $SCSInfo | grep Host | awk '{print $8}'`
tp=`cat $SCSInfo | grep Model | cut -f3 -d ':' | sed -e 's/Rev//' -e 's/ //g' | cut -f1 -d "-"`


cd  /usr/local/oracle/backup/
./install/installob $in <<EOF
a
admin
admin
admin
admin
root@$ws
n
y
1
0
$SCSIadapter
$SCSIbus
$SCSItarget
$SCSIlun
y
EOF

sleep 5

su - oracle -c "
ln -s /usr/local/oracle/backup/lib/libobk.so /opt/app/oracle/product/11.2.0.3/lib/libobk.so"
su - oracle -c "$OMC_UNIX_INSTALL_DIR/oracle/obtool_config_linux.sh"

sleep 10

su - oracle -c "
obtool << EOF
chhost --addrole mediaserver $ws
mkdev --type tape --attach $ws:/dev/obt0 $tp
chuser oracle --rmdomain *
EOF
"

fi

}

install_10_4() {

if [[ $OS = "SunOS" ]]
then
	echo "Version is Oracle_solaris64_secure_backup_10.4.0.2"
	cd /usr/local/oracle/backup

	/bin/csh $path/setup $input <<END
no
END

	sed -e "s/customized obparameters: no/customized obparameters: yes/" < /usr/local/oracle/backup/install/obparameters > /usr/local/oracle/backup/install/obparameters.temp
	sed -e "s/create pre-authorized oracle user: no/create pre-authorized oracle user: yes/" < /usr/local/oracle/backup/install/obparameters.temp > /usr/local/oracle/backup/install/obparameters
	rm /usr/local/oracle/backup/install/obparameters.temp
	sed -e "s/^Listen.*/Listen 446/" < /usr/local/oracle/backup/apache/conf/httpd.conf.orig > /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp
	cp /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp /usr/local/oracle/backup/apache/conf/httpd.conf.orig
	rm /usr/local/oracle/backup/apache/conf/httpd.conf.orig.temp

	sleep 5


	ws=`hostname`


	/usr/local/oracle/backup/install/installob $in <<EOF
a
admin
admin
admin
admin
root@ws
n
n
EOF

	echo "Creating the symbolic link towards the tape device..."
	rm -f /dev/obt0
	tape_dev=$(ls /dev/scsi/sequential)
	if [ $? -eq 0 ]; then
		ln -s /dev/scsi/sequential/${tape_dev} /dev/obt0
	else
		echo "Cannot find the sequential tape device in /dev/scsi!"
		exit 1
	fi


	su - oracle -c "ln -s /usr/local/oracle/backup/lib/libobk.so /opt/app/oracle/product/11.2.0.3/lib/libobk.so"
	su - oracle -c "$OMC_UNIX_INSTALL_DIR/oracle/obtool_config.sh"

	sleep 10

	su - oracle -c "
obtool << EOF
chhost --addrole mediaserver $ws
mkdev --type tape --attach $ws:/dev/obt0 tapedev
chuser oracle --rmdomain *
setp devices/errorrate none
EOF
"

fi



}
update_osb () {

#remove old version if installed
#avoid overwriting over an existing version

def_ver=`echo $osb_version | cut -f5 -d '_'`

if [ ! -d /usr/local/oracle/backup ]
	then
		echo "Creating /usr/local/oracle/backup"
		mkdir -p /usr/local/oracle/backup
	else
		echo "OSB software already present on this server"
		cd /usr/local/oracle/backup/bin
		if [ -f obtool ]
			then
				inst_ver=`/usr/local/oracle/backup/bin/obtool -V | grep 10\..\..\.. | awk {'print $3'}`
				if [ x${inst_ver} = x${def_ver} ]
				then
					echo "$inst_ver is already installed"
					PKGname="CDOSBver"
					PKGver="10.4.0.2.0_P1"
					count=`pkginfo | grep -i $PKGname | awk '{print $2}' | xargs |wc -w`
					if [ $count -gt 0 ]; then
                                        	INSTver=`pkginfo -l $PKGname |grep VERSION | awk '{print $2}'`
                                                if [ "x$INSTver" = "x$PKGver" ]; then
                                                	echo "Exiting OSB installation script"
                                                	exit 1
                                                else
                                                	echo "An older Oracle version is installed on this machine"
                                                	echo "y" | pkgrm ${PKGname} 2>&1 > /dev/null
                                                fi
                                       fi
                                       versioning_install
                                       cat <<- ! >> /etc/MUSE.signature
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
               -=( $osb_version )=-
      Customized installation of Oracle Secure Backup for $OS 64
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
!
                                       echo "Exiting OSB installation script"
                                       exit 0
			else
					echo "Uninstalling previous OSB version: $inst_ver"
					$OMC_UNIX_INSTALL_DIR/oracle/uninstall_osb.sh
					echo "Recreating /usr/local/oracle/backup"
					mkdir -p /usr/local/oracle/backup
			fi
			else				
				echo ""
				echo "Backup directory already exists...Aborting installation"
				exit 1
		fi
fi

}

versioning_install () { 

verpkg=`ls $path | grep CDOSBver*`
res=$?
if [[ $res -eq 0 ]]
then
	if [[ $OS = "SunOS" ]]
        then
        	PKG_DIR=/var/tmp/pkdir_$$
        	echo "Versioning package is $verpkg"

        	mkdir $PKG_DIR
		gzip -cd ${path}/${verpkg} | (cd ${PKG_DIR} ; cpio -icdumD ) 2>&1 > /dev/null
        	echo "Installing ${verpkg} in none interactive mode..."

                pkgadd -d ${PKG_DIR} -n CDOSBver
		rm -fr $PKG_DIR
        else
		echo "Versioning package is $verpkg"
                rpm -ivvh ${path}/${verpkg} --ignoreos --nodeps --force
		rm -fr /CDOSBver
	fi

	echo "Finished installing versioning package from ${verpkg}"
else
	echo "No versioning package found in ${path}"
fi

}

workaround_for_OSB103 () {

echo "Copying $OMC_UNIX_INSTALL_DIR/oracle/S99osb_wa.sh to /etc/rc2.d"

cp $OMC_UNIX_INSTALL_DIR/oracle/S99osb_wa.sh /etc/rc2.d 

}

#
# Main
#

path=$1
#get version to be installed
osb_version=`cat /var/tmp/server.profile |grep ORACLE_BACKUP |awk '{print $2}'`

update_osb

echo "Installing Oracle Secure Backup"

case $osb_version in
	Oracle_linux64_secure_backup_10.3.0.1.0) install_10_3;;
	Oracle_solaris64_secure_backup_10.3.0.1.0) install_10_3;;
	Oracle_solaris64_secure_backup_10.2.0.2.0) install_10_2;;
	Oracle_solaris64_secure_backup_10.1.0.2) install_10_1;; 
	Oracle_solaris64_secure_backup_10.4.0.2.0) install_10_4;;
	Oracle_solaris64_secure_backup_10.4.0.2.0_P1) install_10_4;;
	*) echo "OSB version provided: $osb_version is not supported, exiting...";exit 1;;
	esac

versioning_install
workaround_for_OSB103

cat <<- ! >> /etc/MUSE.signature
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
               -=( $osb_version )=-
      Customized installation of Oracle Secure Backup for $OS 64
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
!

echo "Finished installing $osb_version !\n"
