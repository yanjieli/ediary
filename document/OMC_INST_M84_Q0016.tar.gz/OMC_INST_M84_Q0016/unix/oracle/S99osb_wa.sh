#!/bin/ksh
#set -x

#####
# Variables
#####

LOG_DIR=/alcatel/MS/data/traces
LOG_FILE="OSB_WA.$$.log"
LOGS=${LOG_DIR}/${LOG_FILE}


#####
# Pre-checks
#####

ME=$(basename $0)
OS=$(uname)

[ "$(id | awk -F\( '{print $2}' | awk -F\) '{print $1}')" = root ] || {
        echo "ERROR: You must be logged in as root to run $ME" >&2
        echo "       Log in as root and restart $ME execution." >&2
        exit 1
}

if [[ $OS != "SunOS" ]]
then
        echo "This script must be run only on Solaris systems"
        exit 1
fi

#init log dir
mkdir -p $LOG_DIR

#get version to be installed
osb_installed=`cat /etc/MUSE.signature | grep Oracle_solaris64_secure_backup`
res=$?

if [ $res -ne 0 ] 
then
	echo "OSB is not installed on this server"  | tee -a $LOGS
	echo "Script $ME will exit" | tee -a $LOGS
	exit 1
else
	osb=`echo ${osb_installed} | cut -f5 -d '_' | cut -f1 -d ' '`

	echo "OSB version installed is: $osb" | tee -a $LOGS
	if [ $osb != 10.3.0.1.0 ]
	then
		echo "OSB version installed does not require running this script" | tee -a $LOGS
		exit 0
	fi
fi

#exit 0

#####
# Main
#####

echo "Starting $ME at `date`" | tee -a $LOGS

echo "Renaming $ME to _$ME" | tee -a $LOGS

mv /etc/rc2.d/$ME /etc/rc2.d/_$ME 1>>$LOGS 2>&1
sync;sync;sync;
sleep 10

echo "Commenting lines in  /kernel/drv/st.conf" | tee -a $LOGS

sed -e 's/^/\#/g' /kernel/drv/st.conf > /tmp/temp.txt
cp /tmp/temp.txt /kernel/drv/st.conf

echo "Removing OSB driver" | tee -a $LOGS
rem_drv ob 1>>$LOGS 2>&1 

echo "Copying ob driver files" | tee -a $LOGS
cp /usr/local/oracle/backup/.drv.solaris64/ob /usr/kernel/drv/ob 1>>$LOGS 2>&1
cp /usr/local/oracle/backup/.drv.solaris64/ob.conf /usr/kernel/drv/ob.conf 1>>$LOGS 2>&1
cp /usr/local/oracle/backup/.drv.solaris64/ob64 /usr/kernel/drv/sparcv9/ob 1>>$LOGS 2>&1

echo "Adding ob driver" | tee -a $LOGS
/usr/sbin/add_drv -v -m '* 0666 bin bin' ob 1>>$LOGS 2>&1

echo "Running devfsadm" | tee -a $LOGS

devfsadm -Cv 1>>$LOGS 2>&1

#echo "Please restart the server using \"init 6\" command to finalize the OSB workaround" | tee -a $LOGS
init 6

echo "Finished running $ME at `date`" | tee -a $LOGS
echo "Restarting server" | tee -a $LOGS
sleep 15

init 6
