#!/bin/ksh

#        - Restore database using information from external storage and RMAN backup
#        - Move database to ASM disks  
#        - Switch database to copy (ASM disks) 
#        Author : Cristian Ciurea - 07.10.2007

DB_NAME=SNM
RMAN_BACK_DIR=/alcatel/backup
LOGFILE=/alcatel/install/log/restore_data.log
ORACLE_HOME_PATH=/alcatel/var/home/oracle
ORACLE_HOME=`cat $ORACLE_HOME_PATH/.profile |grep ORACLE_HOME |awk '{print $1}' |cut -d = -f2`
RECOVERY_DISKGROUP="+RECOVERY"
DATA_DISKGROUP="+DATA"
FILE="${RMAN_BACK_DIR}/old_pfile.ora"
DB_PASSWD="orapower"
CONTROL1="+DATA/SNM/CONTROLFILE/cf1.ctl"
CONTROL2="+DATA/SNM/CONTROLFILE/cf2.ctl"
DUMP_FILE=/var/tmp/dump
CRE_SQL_FILE=/var/tmp/log.sql
SQL_FILE=logmember.sql
SQL="select member from v\$logfile lf , v\$log l where l.status='CURRENT' and lf.group#=l.group#;"
echo $SQL > ${CRE_SQL_FILE}
RESTORE_SQL=/var/tmp/rest.sql

#Obtain instance number
if [ -f /install/data/cluster.conf ]
        then . /install/data/cluster.conf
fi

cat >$2 <<!
INSTANCE_NUMBER=$INSTANCE_NUMBER
!


#su - oracle -c "
#export ORACLE_SID=+ASM${INSTANCE_NUMBER}
#$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
#
#        startup
#        disconnect
#        exit
#EOF
#" | tee -a $LOGFILE

#create arch directory for archive log
su - oracle -c "
        export ORACLE_SID=+ASM${INSTANCE_NUMBER}
        asmcmd <<- EOF
        cd RECOVERY
        mkdir ${DB_NAME}
        cd ${DB_NAME}
        mkdir arch
        exit
EOF
"

#Move CONTROLFILE to +DATA DISKGROUP
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
	startup nomount pfile='${FILE}';
	alter database mount;
	alter database backup controlfile to '${CONTROL1}';
	alter database backup controlfile to '${CONTROL2}';
        exit
EOF
" | tee -a $LOGFILE

su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
        @${CRE_SQL_FILE}
        exit
EOF
" > ${DUMP_FILE}

#shuting down oracle
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
	shutdown immediate
        exit
EOF
" | tee -a $LOGFILE

REDO_LOG=`cat ${DUMP_FILE} | grep redo`
echo "recover database until cancel using backup controlfile;" > ${RESTORE_SQL}
echo ${REDO_LOG} >> ${RESTORE_SQL}

cp ${FILE} ${FILE}.bak
EXPR="/control_files/d"

/usr/bin/sed -e $EXPR ${FILE} > ${FILE}.ctl | tee -a $LOGFILE

sync
sleep 10
echo "*.control_files='+DATA/SNM/CONTROLFILE/cf1.ctl','+DATA/SNM/CONTROLFILE/cf2.ctl'" >> ${FILE}.ctl | tee -a $LOGFILE

#Move CONTROLFILE to +DATA DISKGROUP
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
        startup mount pfile='${FILE}.ctl';
        exit
EOF
" | tee -a $LOGFILE

#Recover database && disable block change tracking
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
	@${RESTORE_SQL}
	alter database open resetlogs;
	alter database disable block change tracking;
	shutdown immediate
        exit
EOF
" | tee -a $LOGFILE

#restart database 
su - oracle -c "
export ORACLE_SID=${DB_NAME}
$ORACLE_HOME/bin/sqlplus / as sysdba <<- EOF
	startup mount pfile='${FILE}.ctl';
        exit
EOF
" | tee -a $LOGFILE

#copy database to +ASM
su - oracle -c "
export ORACLE_SID=$DB_NAME
$ORACLE_HOME/bin/rman target / nocatalog <<- EOF
       backup as copy database format '+DATA';
       switch database to copy;

       exit
EOF
" | tee -a $LOGFILE

#cp $FILE $FILE.bak
EXPR1="/db_recovery_file_dest=/d"
EXPR2="/control_files/d"
EXPR3="/log_archive_dest_1/d"

/usr/bin/sed -e $EXPR1 -e $EXPR3 $FILE.ctl > $FILE.new | tee -a $LOGFILE

echo "*.db_create_file_dest='${DATA_DISKGROUP}'"  >> $FILE.new | tee -a $LOGFILE
echo "*.db_recovery_file_dest='${RECOVERY_DISKGROUP}'" >> $FILE.new | tee -a $LOGFILE
echo "*.log_archive_dest_1='LOCATION=${RECOVERY_DISKGROUP}/SNM/arch/'" >> $FILE.new | tee -a $LOGFILE
#echo "*.control_files='${DATA_DISKGROUP}/SNM/CONTROLFILE/cf1.ctl','${DATA_DISKGROUP}/SNM/CONTROLFILE/cf2.ctl'" >> $FILE.new | tee -a $LOGFILE
echo "*.db_create_online_log_dest_1='${RECOVERY_DISKGROUP}'" >> $FILE.new | tee -a $LOGFILE

exit 0
