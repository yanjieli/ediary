#!/bin/ksh

#    Add hosts on MASTER node
#
HOSTS_FILE=/etc/hosts

check=`awk '$2 ~ /^__HOST_SLAVE__$/ && $1 !~ /^#/ {print "OK"}'< $HOSTS_FILE`
if [[ x$check = "xOK" ]]
then
        echo __HOST_SLAVE__ is already present in $HOSTS_FILE
else
        echo "__HOST_SLAVE_IP__         __HOST_SLAVE__" >> $HOSTS_FILE
fi

check=`awk '$2 ~ /^__HOST_SLAVE__-vip$/ && $1 !~ /^#/ {print "OK"}'< $HOSTS_FILE`
if [[ x$check = "xOK" ]]
then
        echo __HOST_SLAVE__-vip is already present in $HOSTS_FILE
else
        echo "__HOST_SLAVE_VIP__        __HOST_SLAVE__-vip" >> $HOSTS_FILE
fi

check=`awk '$2 ~ /^__HOST_SLAVE__-priv$/ && $1 !~ /^#/ {print "OK"}'< $HOSTS_FILE`
if [[ x$check = "xOK" ]]
then
        echo __HOST_SLAVE__-priv is already present in $HOSTS_FILE
else
        echo "__HOST_SLAVE_PRIV__       __HOST_SLAVE__-priv" >> $HOSTS_FILE
fi

