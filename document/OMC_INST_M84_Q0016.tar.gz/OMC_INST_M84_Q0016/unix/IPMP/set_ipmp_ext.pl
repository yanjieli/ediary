#!/usr/bin/perl
$|++;
sub my_die {
	my ($msg) = @_;
	print $msg, "\n";
	exit 7;
}

sub answer_normalizer {

    my ($answer) = @_ ;
    $answer=lc($answer) ;
    if ( ($answer eq "yes") || ($answer eq "y") ) {
       $answer="yes"
    }
    else {
       $answer="no"
    }
    return $answer
}

sub get_network_interfaces {

   my %interfaces=() ;
   my @interfaces=() ;
   $dladm=`dladm show-dev` ;
   @interfaces=split("\n",$dladm) ;
   for (my $i=0;$i<@interfaces;$i++) {
     $interfaces[$i]=~s/\s+/#/g ;
     $interfaces[$i]=~/(\w+)#link:#\w+#speed:#(\d+)#.+$/ ;
     $interfaces{$1}=$2 ;
   }
   return \%interfaces ;
}

sub list_network_interfaces {
   my ($hash_addr)=@_ ;
   my %nic_list=%{$hash_addr} ;

   foreach $nic (sort { $a cmp $b } keys %nic_list) {
      if ( $nic_list{$nic} != 0 ) {
         print "$nic\tLink : UP \tSpeed : $nic_list{$nic}\n" ;
      }
      else {
         print "$nic\tLink : DOWN \tSpeed : $nic_list{$nic}\n" ;
      }
   }
   print "\n" ;
}

sub write_hostname {
   my ($interface,$type,$group)=@_ ;
   my $hostname="" ;

   my $hostname_file="hostname.".$interface ;
   if ( $type eq "primary" ) { $hostname=`cat $basedir/etc/$hostname_file | head -1` ; chomp $hostname ; $hostname=$hostname." " ;}
   $content=$hostname."group ".$group ;
   open(HOSTNAME, "> $basedir/etc/$hostname_file") || my_die("Can't create $hostname_file file");
   print HOSTNAME "$content\n" ;
   close HOSTNAME ;
   #if secondary interface add to transfer list
   if ( $type eq "secondary" ) {
     open (TRANS, ">>$basedir/etc/transfer_list") || my_die("Can't create transfer_list file");
     print TRANS "/etc/$hostname_file SUNWcsr OVERWRITE\n" ;
     close TRANS ;
   }
}

sub get_configured_nics {
  my $hostname_list=`(cd $basedir/etc; ls hostname.*)` ; chomp $hostname_list ;
  my @configured_nics=split("\n",$hostname_list) ;
  my %nic_matching={} ;
  
  for ($i = 0; $i < @configured_nics; $i++) {$configured_nics[$i]=~s/hostname\.// ;}
  return @configured_nics ;
}

#directory where the hostname files will be saved
$basedir="/" ;
#ipmp group names
%ipmp_groups = ( 0, "public",
                 1, "private",
                 2, "ne",
                 3, "backup", 
                 4, "public",
                 5, "private",
                 6, "ne",
                 7, "backup" ) ;

$machine_type=`uname -i` ; chomp $machine_type ;

$primary_nic_temp=`ifconfig -a | egrep -v "ether|inet|lo"` ; chomp $primary_nic_temp ;
$primary_nic_temp=~/(^.*):/ ;
$primary_nic=$1 ;

print "\nChecking Network Interfaces suitable for IPMP...\n" ;

#check for suitable network interfaces
%network_interfaces=%{&get_network_interfaces()} ;
     
%nic_groups=() ;
foreach $nic (keys %network_interfaces) {
  $nic=~s/\d+$//g ;
  if ( defined $nic_groups{$nic} ) {
     $nic_groups{$nic}++ ;
  }
  else {
     $nic_groups{$nic}=1 ;
  }
}

#check if have dual quad cards
#if have 2 same type will have 8 interfaces in the same group
#if have 2 different type will have 2 groups with 4 interfaces

foreach $group (keys %nic_groups) {
  if ( $nic_groups{$group} == 4 ) {
    $four_nic_group{$group}=4 ;
  }
  if ( $nic_groups{$group} == 8 ) {
    $eight_nic_group{$group}=8 ;
  }
  if ( $nic_groups{$group} > 8 ) {
    $ten_nic_group{$group}=10 ;
  }
}

#check if we have an 8 interface group
if ( defined %ten_nic_group ) {
  if (keys %ten_nic_group == 1 ) {
    print "\nFound dual Quad Gigabit Network Interface with internal ce cards\n" ;
    $configure_ipmp=1 ;
    $ipmp_nics=8 ;
  }
}
elsif ( defined %eight_nic_group ) {
  if (keys %eight_nic_group == 1 ) {
    print "\nFound dual Quad Gigabit Network Interface\n" ;
    $configure_ipmp=1 ;
    $ipmp_nics=8 ;
  }
}
elsif ( defined %four_nic_group ) {
  if (keys %four_nic_group == 2 ) {
    print "\nFound 2 Quad Gigabit Network Interface\n" ;
    $configure_ipmp=1 ;
    $ipmp_nics=4 ;
  }
}
else {
  print "No suitable Network Interfaces found. Exiting ... \n" ;
  exit 1 ;
}

#if the conditions were met ask the user if he/she want to configure IPMP
if ( $configure_ipmp ) {
   print "Available Network Interfaces are : \n\n" ;
   &list_network_interfaces(\%network_interfaces) ;
   print "Do you want to setup IPMP on this machine (yes/no) : ";
   $ipmp=<STDIN>; chomp $ipmp; $ipmp=&answer_normalizer($ipmp) ;

   if ( $ipmp eq "yes" ) {
     @configured_nics=&get_configured_nics() ;
     #if we have 2 groups must check which is the primary one
     foreach $nic (@configured_nics) {
       $nic_temp=$nic;
       $nic_temp=~s/\d+$//g ;
       if ( defined $configured_groups{$nic_temp} ) {
          $configured_groups{$nic_temp}++ ;
       }
       else {
         $configured_groups{$nic_temp}=1 ;
       }
     }
     #if interfaces are configured from both groups we don't know which the 
     #primary one is
     if (keys %configured_groups > 1) {
       print "Configured interfaces are from both groups. Confused. Exiting ...\n" ;
       exit 2 ;
     }
     if ( $ipmp_nics == 4 && $machine_type eq "SUNW,Netra-240" ) {
       $primary_group="ce" ;
       for ( $i=0 ; $i < 2 ; $i++ ) { $j=$i+2 ; $nic_matching{ce.$i}=ce.$j }
     }
     elsif ( $ipmp_nics == 4 ) {
       @conf_groups=keys %configured_groups ; $primary_group=$conf_groups[0] ;
       foreach my $group (keys %four_nic_group ) {
         if ($group ne $primary_group ) { $secondary_group=$group }
       }
       for ( $i=0 ; $i < 4 ; $i++ ) { $nic_matching{$primary_group.$i}=$secondary_group.$i }
     }
     elsif ( $ipmp_nics == 8 ) {
       @conf_groups=keys %configured_groups ; $primary_group=$conf_groups[0] ;
       for ( $i=0 ; $i < 4 ; $i++ ) { $j=$i+4 ; $nic_matching{$primary_group.$i}=$primary_group.$j }
     }
     else {
       @conf_groups=keys %configured_groups ; $primary_group=$conf_groups[0] ;
       for ( $i=2 ; $i < 6 ; $i++ ) { $j=$i+4 ; $nic_matching{$primary_group.$i}=$primary_group.$j }
     }
     %reversed_nic_matching=reverse(%nic_matching) ;
   
     foreach $nic (@configured_nics) {
       if (defined $nic_matching{$nic}) {
          $ipmp_pair=$nic_matching{$nic} ;
          $pair_ok=1;
          foreach $pair (@configured_nics) {
            if ( $pair eq $ipmp_pair ) { $pair_ok=0 }
          }
          if ( $pair_ok == 1) { 
            print "Configuring IPMP for $nic\n" ;
            $nic=~/(\d+$)/ ;
            $group=$ipmp_groups{$1} ;
            if (not defined $group) {$group="default" }
            &write_hostname($nic,"primary",$group) ;
            &write_hostname($ipmp_pair,"secondary",$group) ;
          }
          else {
            print "IPMP Pair $ipmp_pair already configured for other purpose. Skipping interface $nic\n" ;
            print "IPMP not configured for $nic\n"; 
          }
       }
       elsif (defined $reversed_nic_matching{$nic}) {
          $ipmp_pair=$nic_matching{$nic} ;
          $pair_ok=1;
          foreach $pair (@configured_nics) {
            if ( $pair eq $ipmp_pair ) { $pair_ok=0 }
          }
          if ( $pair_ok == 1) { 
            print "Configuring IPMP for $nic\n" ;
            &write_hostname($nic,"primary") ;
            &write_hostname($ipmp_pair,"secondary") ;
          }
          else {
            print "IPMP Pair $ipmp_pair already configured for other purpose. Skipping interface $nic\n" ;
            print "IPMP not configured for $nic\n"; 
          }
       }
       else {
         print "Can't find IPMP Pair for interface $nic\n" ;
         print "IPMP not configured for $nic\n"; 
       }
     }  
  }  
  else {
    print "IPMP won't be configured\n" ;
    exit 5 ;
  }
}
print "IPMP configuration finished. Please reboot the machine to activate IPMP\n"
