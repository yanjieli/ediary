#!/bin/bash

case $1 in

	"start")
		echo "Starting pmon ..."
		/sbin/start pmon
	;;
	"stop")
		echo "Stopping pmon ..."
		/sbin/stop pmon
	;;
esac
echo "exit status: $?"
