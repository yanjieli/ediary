#!/bin/bash
#set -x
#########################################################################
#   Authors: Zheng Zhaoqing				#
#   Date: 08/08/2017							#
#									#
#   Description: The following script will update /root/DVD1L_install/VAR.pre file so that correct number of 
#                       raw devices can be taken into account in RedHat 6 to RedHat7 upgrade  #
#	  Version: 01.04
#    Updates: 
#                 01.02 Use /etc/udev/rules.d/60-raw.rules instead of /etc/udev/rules.d/60-raw.rules.rpmsave, this file may rename with OS rpm pakcage update. 
#                 01.03 Script enhanced to take care of both 60-raw.rules and 81-raw.rules files
#                 01.04 Script updated with new algo.
#########################################################################


###########################Variables#####################################
unalias cp 2>/dev/null

LOG=/alcatel/install/log/$(basename $0)_$(date +%Y-%m-%d_%H-%M-%S).log.$$
rule_file_81=/etc/udev/rules.d/81-raw.rules
rule_file_60=/etc/udev/rules.d/60-raw.rules
rule_file_60_save=/etc/udev/rules.d/60-raw.rules.rpmsave
export effective_raw_rules=""
var_file=/root/DVD1L_install/VAR.pre
cluster_conf=/install/data/cluster.conf

###########################Functions#####################################
# Check on raw device number, and if those files available which will be used by this script, exit if not available on server
check_file(){
	
	test ! -f /install/data/OMC_INSTALL && echo "/install/data/OMC_INSTALL is not available on server, exiting..." && exit 1
	omc_conf=$(perl -lne 'print $1 if /^\s*OMC_CONF=(\S+)/' /install/data/OMC_INSTALL)
	echo "Omc conf:       $omc_conf"
	if [ "x${omc_conf}" != "xXLARGE" ]; then
		echo "Server conf is ${omc_conf}, not XLARGE server, no need to apply the W/A, exiting"
		exit 0
	fi
	
	test ! -f ${var_file} && echo "${var_file} is not available on server, exiting..." && exit 1
	
	raw_nb=""
	asm_part_nb=""
	
	raw_nb=`raw -qa | wc -l`
	asm_part_nb=`cat ${var_file} | grep ASM_PART | wc -l`
	
	[[ -z "${raw_nb}" ]] && {
		echo "The raw device number is abnormal, exiting..."
		echo "`raw -qa`"
		exit 1
	}
	
	[[ -z "${asm_part_nb}" ]] && {
		echo "The ASB_PART number is abnormal, exiting..."
		echo "`cat ${asm_part_nb}`"
		exit 1
	}
	
	if [ "x${raw_nb}" = "x${asm_part_nb}" ]; then
		echo "There are ${raw_nb} raw devices on server, while the same ${asm_part_nb} number in ${var_file} file, no need to apply the W/A, exiting..."
		exit 0
	else
		echo "There are ${raw_nb} raw device on server..."
		echo "There are ${asm_part_nb} ASM_PART in ${var_file} file..."
		if [ -f "${rule_file_60_save}" ]; then
			echo "${rule_file_60_save} is available on server, use it to get the unique id..."
			effective_raw_rules=${rule_file_60_save}
		elif [ -f "${rule_file_60}" ]; then
			echo "${rule_file_60_save} is not available on server..."
			echo "${rule_file_60} is available on server, use it to get the unique id..."
			effective_raw_rules=${rule_file_60}
		else
			echo "Neither ${rule_file_60_save} nor ${rule_file_60} is available on server, invalid scenario, exiting..."
			exit 1
		fi	
	fi	
	[[ -z "${effective_raw_rules}" ]] && {
		echo "The effective raw rules file on server is empty, exiting..."
		exit 1
	}
	
	cp ${var_file} /alcatel/install/log/VAR.pre_$(date +%Y-%m-%d_%H-%M-%S)
}

#Update VAR.pre file with new entries calculated based on raw.rules file
update_var_pre(){
	
	raw_nb=`raw -qa | wc -l`
	[[ -z "${raw_nb}" ]] && {
		echo "The raw device number is abnormal, exiting..."
		echo "`raw -qa`"
		exit 1
	}
	
	num_tmp=10
	
	#Standard XLARGE should have 9 raw devices
	if [ ${raw_nb} -gt 9 ]; then
		while [ $num_tmp -le $raw_nb ]; do			
			uniq_id_tmp=`cat ${effective_raw_rules} | grep raw${num_tmp} | awk -F, '{print $3}' | awk -F\" '{print tolower ($2)}'`
			uniq_id_num=`ls /dev/disk/by-id | grep -i ${uniq_id_tmp} | grep scsi | grep part2 | wc -l`
			if [ "x${uniq_id_num}" = "x1" ]; then
				uniq_id_new=`ls /dev/disk/by-id | grep -i ${uniq_id_tmp} | grep scsi | grep part2`
				is_there=`cat ${var_file} | grep ASM_PART | grep ${uniq_id_new} | wc -l`
				if [ "x${is_there}" = "x0" ]; then 
					echo "Append ASM_PART${num_tmp}=/dev/disk/by-id/${uniq_id_new} to file ${var_file} "
					echo "ASM_PART${num_tmp}=/dev/disk/by-id/${uniq_id_new}" >> ${var_file}
				else
					echo "Unique id = ${uniq_id_new} is already available in ${var_file}, exiting..."
					exit 1
				fi
			else
				echo "Cannot locate correct the unique id in /dev/disk/by-id folder, exiting... "
				exit 1
			fi
			let num_tmp++
		done
	else
		echo "Raw device number is less than 9 on this server, invalid scenario, exiting..."
		exit 1
	fi
	
}
###########################Main#####################################
{
echo "$(date) starting $0 ..."

check_file
update_var_pre

echo "$(date) end $0 ..."

} 2>&1 | tee -a $LOG
global_exit_code=${PIPESTATUS[0]}
if [ $global_exit_code -ne 0 ]; then
	exit $global_exit_code
fi
exit 0
