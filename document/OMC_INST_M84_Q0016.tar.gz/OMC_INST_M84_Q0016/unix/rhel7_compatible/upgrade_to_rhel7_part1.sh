#!/bin/bash

#set -x
OMC_INSTALL_DIR=_OMC_INSTALL_DIR_
omcr=_OMCR_
install_lib=$OMC_INSTALL_DIR/unix/lib/install
. $install_lib.sh
LOG=/alcatel/install/log/$(basename $0)_$(date +%Y-%m-%d_%H-%M-%S).log
BACKUP_FOLDER=/alcatel/backup
REDHAT_MOUNT_POINT=${INSTALL_DIR}/REDHAT_DVD


{

umount ${REDHAT_MOUNT_POINT} 2>/dev/null
mkdir -p ${REDHAT_MOUNT_POINT}
mount -o loop ${ISO_DIR}/${REDHAT_DVD}* ${REDHAT_MOUNT_POINT}

echo_msg() {
	echo -e $1
	echo -e "[$(date +'%Y-%m-%d %H:%M:%S')] $1" >> ${LOG}
}

echo_line () {

echo "========================================================================"

}

echo_light_line () {

echo '------------------------------------------------------------------------' 


}

update_signature () {

echo -e "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" >> /etc/MUSE.signature
echo "	RHEL6 to RHEL7 upgrade by $REDHAT_DVD" >> /etc/MUSE.signature
echo -e "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" >> /etc/MUSE.signature

}

run_command() {
	echo_light_line
	echo "Running $@ ..."
	$@
	if [ $? -ne 0 ];then
		echo "Command $1 failed ! exiting"
		echo_light_line
		exit 1
	else
		echo "Success. "
		echo_light_line
	fi
}

exit_upgrade() {
	[[ "$enable_rollback" == "yes" ]] || (echo_msg "Rollback NOT enabled")
	echo_msg "$1"
	local codeReturn=$2
	exit ${codeReturn}
}

uninstall_csa () {

#RCA: apparently, CSA need also on AUXs ...
#if [ "$omcr" != "MS_PORTAL" ];then 
#	return
#fi

OLD_OMC_HOME=/alcatel/MS
CSACF_BACKUP=$OLD_OMC_HOME/OMC_CSACF/data/backup

echo "Disclaimer export "
if [ -f $OLD_OMC_HOME/MS_IBOX/config/defaultBanner.txt ]; then
	echo "Copying $OLD_OMC_HOME/MS_IBOX/config/defaultBanner.txt in $OLD_OMC_HOME/OMC_CSACF/data/backup/defaultBanner.txt"
	cp $OLD_OMC_HOME/MS_IBOX/config/defaultBanner.txt $OLD_OMC_HOME/OMC_CSACF/data/backup/defaultBanner.txt
elif [ -f $OLD_OMC_HOME/MS_IBOX/iboxV2/config/defaultBanner.txt ]; then
	echo "Copying $OLD_OMC_HOME/MS_IBOX/iboxV2/config/defaultBanner.txt in $OLD_OMC_HOME/OMC_CSACF/data/backup/defaultBanner.txt"
	cp $OLD_OMC_HOME/MS_IBOX/iboxV2/config/defaultBanner.txt $OLD_OMC_HOME/OMC_CSACF/data/backup/defaultBanner.txt
else
	echo "$OLD_OMC_HOME/MS_IBOX/config/defaultBanner.txt file not found"
fi

old_file=`find $CSACF_BACKUP/export_csa.out 2>/dev/null`
if [ x$old_file != "x" ]; then
	#save old csa export file
	echo "Saving old $CSACF_BACKUP/export_csa.out file"
	mv $CSACF_BACKUP/export_csa.out $CSACF_BACKUP/export_csa.old
fi

if [ ! -f $CSACF_BACKUP/export_csa.out ];then
	#perform CSA export only if export_csa.out file does not exists
	echo "Start csa before export."
	$OLD_OMC_HOME/MS_PMON/scripts/startstop/start_csa > /dev/null
	echo "Waiting for csa to start ..."
	sleep 100
	i=1
	while true; do
		check_csa_status
		res=$?
		if [ $res -eq 0 ]; then
			echo "CSA is running."
			break
		fi
		echo "Waiting for csa to start ..."
		sleep 60
		((i=i+1))
		if [ $i -eq 10 ]; then
			echo "ERROR unable to start csa!"
			restore_motd 1
			exit 1
		fi
	done
	echo "Export csa data."
	if [ ! -d $CSACF_BACKUP ]; then
		mkdir -p $CSACF_BACKUP
		chown axadmin:gadmin $CSACF_BACKUP
	fi
	if [ ! -d $CSACF_BACKUP/csa_registry_backup ]; then
		mkdir -p $CSACF_BACKUP/csa_registry_backup
		chown axadmin:gadmin $CSACF_BACKUP/csa_registry_backup
	fi
	$OLD_OMC_HOME/OMC_CSACF/scriptscsa21/export_csa.sh $CSACF_BACKUP/export_csa.out

	#check again if the CSA export was performed
	if  [ ! -f $CSACF_BACKUP/export_csa.out ]; then
		echo "ERROR $CSACF_BACKUP/export_csa.out file missing!"
		# exit 1
	fi

	$OLD_OMC_HOME/MS_PMON/scripts/startstop/stop_csa
	sleep 5
else
	echo "CSA export already performed"
fi

#CSA registry export
if [ -f /alcatel/MS/OMC_CSACF/scriptscsa21/exportRegistry.sh ]; then
        echo "Performing CSA registry export"
        /alcatel/MS/OMC_CSACF/scriptscsa21/exportRegistry.sh
fi

/alcatel/MS/MS_PMON/scripts/pmon.sh stop
$OLD_OMC_HOME/MS_PMON/scripts/startstop/stop_csa
$OLD_OMC_HOME/MS_PMON/scripts/startstop/stop_http
(cd /alcatel/FULL_INSTALL_CSA/;echo y|/alcatel/FULL_INSTALL_CSA/uninstall_csa.sh)

rpm -e CSA


}

save_ssh () {

#RCA: save ssh keys in case of aux types

if [ "$omcr" != "MS_PORTAL" ];then

	echo "Saving ssh keys for user $user ..."
	for user in root axadmin;do
		homedir=$(awk '{split($0,a,":");if(a[1]=="'$user'"){print a[6]}}' /etc/passwd)
		export user homedir
		(cd $homedir; mv saved_ssh_${user}.tar saved_ssh_${user}.tar_$$ 2>/dev/null ;tar -cf saved_ssh_${user}.tar .ssh)
	done
	
fi


}


[[ -d ${REDHAT_MOUNT_POINT}/upgrade7 ]] ||  exit_upgrade "No upgrade packages on DVD1" 1

OPWD=$(pwd)
cd $OMC_INSTALL_DIR/migration/scripts
. ./functions
cd $OPWD

check_rollback

chattr -i /boot/grub/grub.conf


echo_msg "Searching for packages that are candidate for remove ..."
list_to_remove=$(rpm -qa | grep 686)
list_to_remove_x11=$(rpm -qa | grep xorg-x11)
list_to_remove="${list_to_remove} ${list_to_remove_x11} control-center cups libtiff openjpeg mysql-libs gdm gnome-panel gnome-power-manager gnome-screensaver gnome-session gnome-terminal metacity nautilus notification-daemon polkit-gnome yelp eog gnome-applets gnome-media gok orca vino httpd ALUiptables gdm preupgrade-assistant-el6toel7 "
#list_rpm_to_remove=''
echo_msg "Cleaning old yum repositories"
tar -czf /alcatel/install/log/repos_upg7.tgz /etc/yum.repos.d/*repo
rm -rf /etc/yum.repos.d/*repo
run_command "yum clean all"

yum remove -y ${list_to_remove} 2>&1 |grep -v "No such file or directory"

if [ ! -f /etc/ld.so.conf ];then
	 echo 'include ld.so.conf.d/*.conf' > /etc/ld.so.conf
	 ldconfig 2>/dev/null
fi

# install pre-upgrade packages

echo_msg "Installing packages needed for upgrade to RHEL 7"
(cd ${REDHAT_MOUNT_POINT}/upgrade7;run_command "yum -y install *rpm")

#RCA: fix /etc/fstab to have 6 entries for all relevant lines, otherwise upgrade will fail

cp /etc/fstab /etc/fstab_$$

awk '{if((NF==5)&&(!/^#/)){print $0" 2"}else{print}}' /etc/fstab_$$ > /etc/fstab

if [ ! -s /etc/fstab ];then
	#file is empthy or does not exist, rollback ...
	cp /etc/fstab_$$ /etc/fstab
fi

preupg --cleanup
if [ -f /usr/share/preupgrade/RHEL6_7/system/SystemVersion/check ];then
	echo_msg "Skipping rhel version test ..."
	sed -i '/END GENERATED/a exit $RESULT_PASS' /usr/share/preupgrade/RHEL6_7/system/SystemVersion/check
fi

# The /etc/preupgrade-assistant.conf should be created after related rpm installed.
# The /etc/pa_blacklist will be created if not present on server, and add /alcatel as the only one filter
# See tracker [#164452]
file_tmp=/etc/preupgrade-assistant.conf
pab_file=/etc/pa_blacklist
if [ -f ${file_tmp} ]; then
	echo -e "" >> ${file_tmp}
	echo "[xccdf_preupg_rule_system_BinariesRebuild_check]" >> ${file_tmp}
	echo "exclude_file=/etc/pa_blacklist" >> ${file_tmp}
	echo "" >> ${file_tmp}
	echo -e "" >> ${file_tmp}
	
	if [ -f ${pab_file} ]; then
		echo_msg "${pab_file} is present on server: `cat ${pab_file}`"
	else
		touch ${pab_file}
		chmod 777 ${pab_file}
	fi
	echo "/alcatel" >> ${pab_file}
		
else
	echo_msg "${file_tmp} is not present on server, exiting..."
	exit 1
fi

if [ -f ${pab_file} ]; then
	echo_msg " /etc/pa_blacklist is present on server, display contents: "
	echo_msg " ${file_tmp} contents are  `cat ${file_tmp}` "
	echo_msg " /etc/pa_blacklist contents are  `cat /etc/pa_blacklist` "
else
	echo_msg " WARNING! /etc/pa_blacklist is NOT present on server, filter function cannot be activated!!!"
fi


echo_msg "Launching pre-upgrade proccesses..."
preupg --force 
echo_msg "Launching pre-upgrade proccesses is finished"

echo_msg "Launching pre-upgrade risk check..."
preupg --riskcheck
if [ $? -eq 2 ];then
	echo_line
	echo "Extreme upgrade risk detected !!!, cannot continue"
	echo_line
	exit 2
fi

uninstall_csa
save_ssh

echo_msg "Starting upgrade to RH 7"
run_command "redhat-upgrade-tool --iso /alcatel/iso/${REDHAT_DVD}* --cleanup-post --force --nogpgcheck"

#RCA: if we get here then no issue, so far

echo_msg "Disabling selinux"
if [ "$omcr" != "MS_PORTAL" ];then
	sed -i 's/SELINUX=.*/SELINUX=disabled/' /etc/selinux/config
else
	sed -i 's/SELINUX=.*/SELINUX=permissive/' /etc/selinux/config
fi
sed -i 's/SELINUXTYPE=.*/SELINUXTYPE=targeted/' /etc/selinux/config


cp $OMC_INSTALL_DIR/unix/scripts/launch-serverinstall /etc/init.d/
chmod 755 /etc/init.d/launch-serverinstall
cp $OMC_INSTALL_DIR/unix/rhel7_compatible/upgrade_to_rhel7_part2.sh   /etc/init.d/upgrade_to_rhel7_part2.sh
chmod 755 /etc/init.d/upgrade_to_rhel7_part2.sh
ln -s /etc/init.d/upgrade_to_rhel7_part2.sh /etc/rc3.d/S98upgrade_to_rhel7_part2.sh
ln -s /etc/init.d/launch-serverinstall /etc/rc3.d/S99launch-serverinstall

echo_line

echo "Upgrade to RH 7 part 1 done successful." 
echo "Upgrade will continue with several reboots "
echo "Please switch to system console to see upgrade progress !"
echo_line 

update_signature

sleep 5

init 6

sleep 100

} 2>&1 |tee -a $LOG
