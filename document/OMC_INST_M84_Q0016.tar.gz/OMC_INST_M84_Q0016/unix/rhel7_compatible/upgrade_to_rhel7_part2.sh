#!/bin/bash
#set -x
#########################################################################
#   Authors: Radu Carp, Bront Paul					#
#   Date: 14/03/2017							#
#									#
#   Description: The following script supports the upgrade from         #
#                RedHat 6 to RedHat7 Linux Server.			#
#									#
#									#
#########################################################################


###########################Variables#####################################
unalias cp 2>/dev/null

OMC_INSTALL_DIR=_OMC_INSTALL_DIR_
raw_rules=/etc/udev/rules.d/81-raw.rules
var_file=/root/DVD1L_install/VAR.pre
asm_part_file=/tmp/ASM_PART_FILE.txt
LOG=/alcatel/install/log/$(basename $0)_$(date +%Y-%m-%d_%H-%M-%S).log
RHEL7_COMPATIBLE=$OMC_INSTALL_DIR/unix/rhel7_compatible/
TYPE=`cat /etc/MUSE.signature | grep -i type | awk ' {print $2}'`


###########################Functions#####################################

function create_raw_rules(){

if [ -f $var_file ];then
	cat $var_file |grep -i ASM_PART >$asm_part_file
	mv $raw_rules /alcatel/install/log/81-raw.rules_$$
	k=0
	for asm_part in  `cat $asm_part_file |awk -F= '{print $NF}'`; do
	disk_prefix=`echo "$asm_part"|awk -F/ '{split($NF,a,"-");print a[1]}'`
	let k++
	case $disk_prefix in
        	                md[0-9])
                	                #disk_prefix is the mirror name, in fact, like "md7"
                        	        echo "ACTION==\"add|change\", KERNEL==\"$disk_prefix\", SUBSYSTEM==\"block\", RUN+=\"/bin/raw /dev/raw/raw$k %N\"" >> $raw_rules
	
        	                ;;
                	        dm)
                        	        #check_part $asm_part
					systemctl status multipathd >/dev/null 2>&1	
					if [ $? -ne 0 ];then
						systemctl start multipathd
						sleep 5
					fi
					ls -l $asm_part
					sleep 2
                                	dm_uuid=`udevadm info -q all -n $asm_part|awk '/DM_UUID=/{split($2,a,"=");print a[2]}'`
                                	echo "ACTION==\"add|change\", KERNEL==\"dm-[0-9]*\",  ENV{DM_UUID}==\"$dm_uuid\", RUN+=\"/bin/raw /dev/raw/raw$k %N\"" >> $raw_rules
                                	systemctl enable multipathd
                        	;;
                        	*)
                                	#check_part $asm_part
                                	if [[ $asm_part == *"virtio"* ]]; then
                                       		vitual_string=`echo $asm_part | awk -F'/' '{print $5}'`
                                        	final_string=`echo $vitual_string | awk -F'.' '{print $1}'`
                                        	part_string=`echo $vitual_string | awk -F'.' '{print $2}'`
                                        	finalpart=`echo $part_string | awk -F'-' '{print $NF}'`
                                        	finalasm=/dev/disk/by-path/virtio-$final_string.0-$finalpart
                                        	asm_part=$finalasm
                                	fi
                                	id_serial=`udevadm info -q all -n $asm_part|awk '/ID_SERIAL=/{split($2,a,"=");print a[2]}'`
                               		id_part_number=`udevadm info -q all -n $asm_part|awk '/ID_PART_ENTRY_NUMBER=/{split($2,a,"=");print a[2]}'`
                                	id_part_uuid=`udevadm info -q all -n $asm_part|awk '/ID_PART_ENTRY_UUID=/{split($2,a,"=");print a[2]}'`
                                	if [ "$id_part_uuid" ];then
                                	       echo "ACTION==\"add|change\", SUBSYSTEM==\"block\", ENV{ID_PART_ENTRY_UUID}==\"$id_part_uuid\", RUN+=\"/bin/raw /dev/raw/raw$k %N\"" >> $raw_rules
                                	else
                                	        echo "ACTION==\"add|change\", SUBSYSTEM==\"block\", ENV{ID_SERIAL}==\"$id_serial\", ENV{ID_PART_ENTRY_NUMBER}==\"$id_part_number\", RUN+=\"/bin/raw /dev/raw/raw$k %N\"" >> $raw_rules
                                	fi

                       		;;
                	esac
#moved 60-raw.rules to 81-raw.rules, need to be after /lib/udev/rules.d/80-udisks.rules
	done
	echo "ACTION==\"add\", KERNEL==\"raw*\", OWNER==\"oracle\", GROUP==\"dba\", MODE==\"0660\"" >> $raw_rules
else
	#In case of OpenStack recreate raw rules from one previous to RHEL upgrade
        cp $raw_rules /alcatel/install/log/81-raw.rules_$$
        sed -i 's/add", S/add\|change", S/' $raw_rules
        sed -i 's/UDISKS_PARTITION_UUID/ID_PART_ENTRY_UUID/g' $raw_rules
        sed -i 's/\(}==\"\)\(.*\)\(\",\)/\1\L\2\E\3/' $raw_rules
fi


i=1
while sleep 5;do
  udevadm control --reload-rules 2>/dev/null
  udevadm trigger --type=devices --action=change 2>/dev/null
  raw_number=`raw -qa |wc -l`
  asm_number=`cat /tmp/ASM_PART_FILE.txt |wc -l`
  if [ $raw_number -eq $asm_number ]; then
	echo "The file /etc/udev/rules.d/81-raw.rules was created with success"
	rm -rf $asm_part_file
	break
  else
	echo "Raw devices not ready yet ... actual: $raw_number , needed: $asm_number "
	
  fi
  if [ $i -eq 10 ];then
	echo "Error creating raw devices ! "
	exit 1
  fi
  let i++
done
}

migrate_oracle () {

#
GRID_HOME=/opt/app/oracle/grid/11.2.0.4
ONLINE_RES=$($GRID_HOME/bin/crsctl status res |\
awk '{if($1~/NAME/){split($1,a,"=");name=a[2]}
      if($1~/STATE/){split($1,b,"=");status[name]=b[2]}
}END{
        for(res in status){if(status[res] == "ONLINE"){printf res" "}}

}')


if [ "$ONLINE_RES" ];then
        echo "Oracle online resources: $ONLINE_RES"
        $GRID_HOME/bin/crsctl stop res $ONLINE_RES
else
        echo "No Oracle online resource ..."
fi

stop oracle-ohasd 2>/dev/null
stop ohasd

echo "Migrating oracle clusterware services to upgraded redhat version ..."

$GRID_HOME/crs/install/roothas.pl -verbose -upgrade 2>&1|grep -v "srvctl upgrade model"|grep -v "ACFS drivers installation"
if [ $? -eq 0 ];then
        echo "Migration successful."
else
        echo "Migration failed !"
        exit 1
fi

start ohasd
sleep 20
stop ohasd
start ohasd
#start oracle-ohasd

}

#needed preparations before NPO software migration from RHEL6 to RHEL7
upgrade_tools() {

if [ ! -f /etc/sysconfig/i18n ];then
        ln -s /etc/sysconfig/i18n /etc/locale.conf 2>/dev/null
fi
echo "/homelocal/cyrus-sasl/lib" > /etc/ld.so.conf.d/CSA.conf

cp -p $RHEL7_COMPATIBLE/stop /usr/sbin/
cp -p $RHEL7_COMPATIBLE/start /usr/sbin/
cp -p $RHEL7_COMPATIBLE/status /usr/sbin/
cp -pf $RHEL7_COMPATIBLE/pmon.sh /alcatel/MS/MS_PMON/scripts/pmon.sh
chmod +x /alcatel/MS/MS_PMON/scripts/pmon.sh

#creating pmon service file
cp -p $RHEL7_COMPATIBLE/pmon.service /etc/systemd/system/
pmon_conf_rhel7=/etc/ld.so.conf.d/pmon.conf
echo "Creating pmon.conf file for PMON service"
echo "/usr/jdk1.7.0/lib/amd64/jli" > ${pmon_conf_rhel7}
ldconfig 2>/dev/null

cp -p $RHEL7_COMPATIBLE/clock /etc/init.d/
chmod +x /etc/init.d/clock
systemctl daemon-reload
systemctl enable clock
systemctl start clock
systemctl disable firewalld 2>/dev/null
systemctl stop firewalld 2>/dev/null
systemctl disable iptables 2>/dev/null
systemctl stop iptables 2>/dev/null
systemctl disable alu-iptables 2>/dev/null
systemctl stop alu-iptables 2>/dev/null

}

cleanup_rpms () {

echo "Cleaning up rpms ..."

if [ $(rpm -qa|grep 686|wc -l) -gt 0 ];then
	yum remove -y $(rpm -qa|grep 686)
fi

rpm -rebuilddb --dbpath /alcatel/MS/lib/rpm

if [ -f /etc/yum.repos.d/redhat-upgrade-upgradeiso.repo ];then
	rm -rf /etc/yum.repos.d/redhat-upgrade-upgradeiso.repo 
fi

}

cleanup_dead_links () {

mv /etc/init.d/upgrade_to_rhel7_part2.sh /alcatel/install/log/ 2>/dev/null
echo "Cleaning dead links ..."
for f in $(find /etc -type l);do readlink -e $f >/dev/null;if [ $? -ne 0 ];then rm -rf $f;fi;done

}

post_upgrade_actions () {

for f in $(ls /etc/pam.d/*);do
	sed -i "/pam_fprintd.so/d" $f
done

}

restore_ssh () {

if [ "$TYPE" != "NPO" ];then
	for user in root axadmin;do
		echo "Restore ssh keys for user $user ..."
		homedir=$(awk '{split($0,a,":");if(a[1]=="'$user'"){print a[6]}}' /etc/passwd)
		export user homedir
		(cd $homedir; tar -xvf saved_ssh_${user}.tar)
	done
fi

}

###########################Main#####################################
{
echo "$(date) starting $0 ..."
#DBA-temporarly wa until a more permanent solution will be found
if [ "$TYPE" != "NPO" ];then
echo "Checking if the partitions are mounted:"
        df -h | grep -i alcatel 2>/dev/null
        if [ $? -eq 1 ];then
                echo "Mounting the partitions:"
                mount -a
                sleep 10
        fi
fi

upgrade_tools
if [ "$TYPE" == "NPO" ];then
        WA_FILE="wa_raw_v4.sh"
        if [ -f ${RHEL7_COMPATIBLE}/${WA_FILE} ]; then
           ${RHEL7_COMPATIBLE}/${WA_FILE}
           if [ $? -eq 1 ]; then
              echo "Something is not fit for this WA, please see the wa_raw_v4 log for more detail!"
           fi
        fi
	create_raw_rules
	migrate_oracle
fi
cleanup_rpms
restore_ssh
cleanup_dead_links
post_upgrade_actions

echo "$(date) end $0 ..."

} 2>&1 |tee -a $LOG
