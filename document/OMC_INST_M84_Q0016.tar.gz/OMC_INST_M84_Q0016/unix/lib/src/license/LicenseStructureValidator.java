package license;

import java.io.File;
import java.net.URI;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

public class LicenseStructureValidator {

	public static void main(String[] args) {
		String licenceXMLFileLocation = args[0];
		boolean isValid;
		try {
			validateXMLSchema(licenceXMLFileLocation);
			isValid = true;
		} catch (Exception ex) {
			ex.printStackTrace();
			isValid = false;
		}

		System.out.println(isValid ? "Valid license.": "Invalid license.");

	}
	public static void validateXMLSchema(String xmlPath) throws Exception {
		SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		ClassLoader classLoader = LicenseStructureValidator.class.getClassLoader();
		Schema schema = factory.newSchema(classLoader.getResource("license/LicenseFile.xsd"));
		Validator validator = schema.newValidator();
		validator.validate(new StreamSource(new File(xmlPath)));
			
	}
}

