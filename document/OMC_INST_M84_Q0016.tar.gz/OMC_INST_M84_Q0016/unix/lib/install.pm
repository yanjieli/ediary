#!/bin/usr/perl

package install;
require Exporter;
use strict;


BEGIN() {
	use Exporter ();
	use vars     qw(@ISA @EXPORT);
	@ISA         = qw(Exporter);
	@EXPORT      = qw(&get_profile &check_profile &set_sh_var_from_profile);
}



sub set_sh_var_from_profile {
	my $filename=shift;
	my %profile;
	my ($k,$v);

	%profile=get_profile($filename);
	while(($k,$v)=each(%profile)) {
		$v="" if not defined $v;
		$v="\"$v\"";
		printf "%16s=%-35s ; export %s\n",$k,$v,$k;
	}
}

sub get_profile {
	my $filename=shift;
	my %profile;
	my %tmpprofile;

	# Read profile file
	#
	open PF,$filename	or die "ERROR: Can't open $filename: $!\n";
	while(<PF>) {
		next if /^\s*$/ or /^\s*#/;
		chomp;
		s/\s*#.*//;
		my @entries = split /\s+/;
		$tmpprofile{$entries[0]}=$entries[1];
		if (defined $entries[2] and ($entries[2] eq "N" or $entries[2] eq "n")) {
			$profile{$entries[0]}=undef;
		}
		else {
			# Case of PC_NM = $NM for example
			if($entries[1]=~/^\$(.*)/) {
				$profile{$entries[0]}=(defined $tmpprofile{$1}?$tmpprofile{$1}:undef);
			}
			else {
				$profile{$entries[0]}=$entries[1];
			}
		}
	}
	close PF;

	# Add other variables to profile
	#
	if(not defined $profile{ISO_DIR}) {
			$profile{ISO_DIR}="/cdrom/cdrom0";
	}
	if(not defined $profile{DEPOT_DIR}) {
			$profile{DEPOT_DIR}="/cdrom/cdrom0";
	}
	if(defined $ENV{INSTALL_DIR}) {
		$profile{INSTALL_DIR}="$ENV{INSTALL_DIR}";
	}
	else {
		$profile{INSTALL_DIR}="/alcatel/install";
	}
	if(defined $profile{ORACLE} and not (defined $profile{ORACLE_DISK1} and
	defined $profile{ORACLE_DISK2} and defined $profile{ORACLE_DISK3})) {
		$profile{ORACLE_DISK1}="$profile{ORACLE}.Disk1";
		$profile{ORACLE_DISK2}="$profile{ORACLE}.Disk2";
		$profile{ORACLE_DISK3}="$profile{ORACLE}.Disk3";
	}

	return %profile;
}

sub check_profile {
	my %profile=shift;
	my $error=0;
	my $pwd;

	return $error;
}

1;

