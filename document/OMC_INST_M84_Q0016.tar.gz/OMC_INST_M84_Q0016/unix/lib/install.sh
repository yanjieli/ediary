#!/bin/ksh
#
# Note: Before using any functions, PERLLIB environement variable
#       should be set properly to locate install perl module

get_profile() {
	file=$1

	eval $(perl -e 'use install; set_sh_var_from_profile("'$file'")')
}

log_message () {
    timestamp=`date '+%d-%m-%y %H:%M:%S'`
    echo -e "[${timestamp}] $1: $2"
}

print_summary () {
	txt=""

	print
	printf "%15s = %s\n" OMCR "$type"
	printf "%15s = %s\n" ACTION "$ACTION"
	printf "%15s = %s\n" OS "$OS_TYPE"
	print

	txt="${txt}"$(eval printf \"%-30s\" \"Third parties:\")
	if [[ "$THIRD_PARTIES" != "" ]]; then
		printf "%15s = %s\n" THIRD_PARTIES    "$THIRD_PARTIES"
		txt="${txt} to be installed.\n"
	else
		txt="${txt} not to be installed.\n"
	fi

	txt="${txt}"$(eval printf \"%-30s\" \"Documentation:\")
        if [[ "$GCDM" != "" ]]; then
                printf "%15s = %s\n" GCDM    "$GCDM"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi

	txt="${txt}"$(eval printf \"%-30s\" \"Patches:\")
	if [[ "$PATCHES" != "" ]]; then
		printf "%15s = %s\n" PATCHES    "$PATCHES"
		txt="${txt} to be installed.\n"
	else
		txt="${txt} not to be installed.\n"
	fi

	txt="${txt}"$(eval printf \"%-30s\" \"Oracle Grid:\")
	if [[ "$ORACLE_GRID" != "" ]]; then
		printf "%15s = %s\n" ORACLE_GRID  "$ORACLE_GRID"
		txt="${txt} to be installed.\n"
	else
		txt="${txt} not to be installed.\n"
	fi

	txt="${txt}"$(eval printf \"%-30s\" \"Oracle:\")
	if [[ "$ORACLE_DISK1" != "" ]]; then
		printf "%15s = %s\n" ORACLE_DISK1  "$ORACLE_DISK1"
		txt="${txt} to be installed.\n"
	else
		txt="${txt} not to be installed.\n"
	fi

	txt="${txt}"$(eval printf \"%-30s\" \"Oracles patches:\")
	if [[ "$ORACLE_PATCH" != "" ]]; then
		printf "%15s = %s\n" ORACLE_PATCH    "$ORACLE_PATCH"
		txt="${txt} to be installed.\n"
	else
		txt="${txt} not to be installed.\n"
	fi

	txt="${txt}"$(eval printf \"%-30s\" \"Oracles backup:\")
        if [[ "$ORACLE_BACKUP" != "" ]]; then
                printf "%15s = %s\n" ORACLE_BACKUP    "$ORACLE_BACKUP"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi

	txt="${txt}"$(eval printf \"%-30s\" \"OMCR:\")
        if [[ "$MS_PORTAL" != "" ]]
        then
                printf "%15s = %s\n" "$type"  "$MS_PORTAL"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi

	txt="${txt}"$(eval printf \"%-30s\" \"CD4 GSM plugs:\")
        if [[ "$CD4_GSM" != "" ]]; then
                printf "%15s = %s\n" CD4    "$CD4_GSM"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi

	txt="${txt}"$(eval printf \"%-30s\" \"CD4 UMTS plugs:\")
        if [[ "$CD4_UMTS" != "" ]]; then
                printf "%15s = %s\n" CD4    "$CD4_UMTS"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi

	txt="${txt}"$(eval printf \"%-30s\" \"CD4 LTE plugs:\")
        if [[ "$CD4_LTE" != "" ]]; then
                printf "%15s = %s\n" CD4    "$CD4_LTE"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi

        txt="${txt}"$(eval printf \"%-30s\" \"CD4 FEMTO:\")
        if [[ "$CD4_FEMTO" != "" ]]; then
                printf "%15s = %s\n" CD4    "$CD4_FEMTO"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi
 	txt="${txt}"$(eval printf \"%-30s\" \"CD4 NA:\")
        if [[ "$CD4_NA" != "" ]]; then
                printf "%15s = %s\n" CD4    "$CD4_NA"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi
	
	txt="${txt}"$(eval printf \"%-30s\" \"CD4 EPC:\")
        if [[ "$CD4_EPC" != "" ]]; then
                printf "%15s = %s\n" CD4    "$CD4_EPC"
                txt="${txt} to be installed.\n"
        else
                txt="${txt} not to be installed.\n"
        fi

	txt="${txt}"$(eval printf \"%-30s\" \"BUNDLE Patch:\")
	if [[ "$BP_VERSION" != "" ]]; then
		printf "%15s = %s\n" BP    "$BP_VERSION"
		txt="${txt} to be installed.\n"
	else
		txt="${txt} not to be installed.\n"
	fi

	print
	print "$txt"
}

check_ip() {
	tag=$1

	check_value_tbc "$tag"    || return 1
	value=$(eval print \$$tag)
	echo $value | perl -lne '
		exit 1 if not @t=/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/;
		for (@t) { exit 1 if $_<0 or $_>255 ; }
	' || {
		print "ERROR: Unexpected value for tag \"$tag\" ($value). IP adress expected." >&2
		return 1
	}
	return 0
}

check_plmn() {
	tag=$1

	check_value_tbc "$tag"    || return 1
	echo $value | perl -lne 'exit 1 if not /^\d{3}\/\d{2,5}$/' || {
		print "ERROR: Unexpected value for tag \"$tag\" ($value). Not a PLMN identifier." >&2
		return 1
	}
	return 0
}

check_emid() {
	tag=$1

	check_value_tbc "$tag"    || return 1
	echo $value | perl -lne 'exit 1 if not /^(\d+)$/ or $1<1' || {
		print "ERROR: Unexpected value for tag \"$tag\" ($value). Not an EM identifier." >&2
		return 1
	}
	return 0
}
check_value_tbc() {
	tag=$1

	value=$(eval print \$$tag)
	[[ "$value" = "to_be_completed" ]] && {
		print "ERROR: Value for tag \"$tag\" has to be set." >&2
		return 1
	}
	return 0
}
check_value() {
	tag=$1
	shift
	list_values=$*

	value=$(eval print \$$tag)
	valok=0
	for ival in $list_values
	do
		[[ "$value" = "$ival" ]] && {
			valok=1
			break
		}
	done

	[[ "$valok" -eq 1 ]] || {
		print "ERROR: Unexpected value for tag \"$tag\" ($value)." >&2
		return 1
	}
	return 0
}

check_profile() {
	file=$1
	error=0;
	LIST_OF_ISO=""

	#
	# First, check main values (others will be done later)
	#
	check_value "OMCR" "MS_PORTAL" "NPO" "AUX_PCMD" "AUX_WCT" "AUX_GL2" "AUX_SON" || error=1
	check_value "ACTION" "COMMISSIONING" "UPGRADE" || {
		error=1
		print "       Only \"COMMISSIONING\" and \"UPGRADE\" are supported." >&2
	}
	[[ "$error" -eq 0 ]] || return $error

	#
	# Type of OMCR
	#
	file=/etc/A1353RA.signature
	if [[ -f $file ]] && [[ ! -f /etc/MUSE.signature ]]
	then
		mv $file /etc/MUSE.signature
	fi
	file=/etc/MUSE.signature
	omcr=""
	if [[ -a $file ]]; then
		type=$(awk '/^TYPE/{print $2;exit}' $file)
		case "$type" in
		    NM)		export omcr=NM     ;;
		    NPO) export omcr=MS_PORTAL  ;;
		    AUX_PCMD) export omcr=AUX_PCMD  ;;
	            AUX_WCT) export omcr=AUX_WCT  ;;
		    AUX_GL2) export omcr=AUX_GL2  ;;
		    AUX_SON) export omcr=AUX_SON  ;;
		    *)
			print "ERROR: \"TYPE\" tag (NM, NPO, AUX_PCMD, AUX_WCT, AUX_GL2, AUX_SON) not found in $file file." >&2
			error=1;
			;;
		esac
	else
		print "ERROR: $file file not found." >&2
		error=1
	fi
	[[ "$omcr" != "" && "$omcr" != "$OMCR" ]] && {
		print "ERROR: The type of OMCR selected at CD1 installation ($omcr)" >&2
		print "       is different from the type of OMCR selected in server profile ($OMCR)." >&2
		error=1;
	}

	#
	# Check ISO images / directories
	#
	dir_nok=0
	for i in ISO_DIR DEPOT_DIR
	do
		dir=$(eval print \$$i)
		[[ -z "$dir" ]] && {
			log_message "ERROR" "$i not set in server profile" >&2
			dir_nok=1
			continue
		}
		[[ -d "$dir" ]] || {
			log_message "ERROR" "$i does not exist or is not a directory" >&2
			dir_nok=1
			continue
		}
	done
	if [[ "$dir_nok" -eq 1 ]]; then
		error=1
	else
		tags_of_cd="REDHAT_DVD THIRD_PARTIES GCDM PATCHES ORACLE_GRID ORACLE_DISK1 ORACLE_DISK2 ORACLE_DISK3 ORACLE_PATCH"
		tags_of_cd="$tags_of_cd MS_PORTAL CD4_GSM CD4_UMTS CD4_LTE CD4_FEMTO CD4_NA CD4_EPC BP_VERSION"
		for tag in $tags_of_cd
		do
			cd=$(eval print \$$tag)
			[[ -z "$cd" ]] && continue
			if [[ "$cd" = BP_NPO* ]]; then
                                n=$(ls $ISO_DIR/$cd.tar* 2>/dev/null | wc -l)
                                [[ "$n" -eq 1 ]] && {
                                        LIST_OF_ISO="$LIST_OF_ISO "$(ls $ISO_DIR/$cd.tar*)
                                        continue
                                }
                                [[ "$n" -gt 1 ]] && {
                                        print "ERROR: Wrong value for tag $tag" >&2
                                        print "       More than one $cd.tar found." >&2
                                        error=1
                                        continue
                                }

                                #
				# n=0, so check if it is a directory
                                #
                                depot_dir=$DEPOT_DIR/$cd
                                [[ -d $depot_dir ]] && continue

                        	print "ERROR: Wrong value for tag $tag" >&2
                        	print "       Can't find file    $ISO_DIR/$cd.tar*"   >&2
                        	print "       neither directory  $depot_dir"     >&2
                        	error=1
			else
				n=$(ls $ISO_DIR/$cd.iso* 2>/dev/null | wc -l)
				[[ "$n" -eq 1 ]] && {
					LIST_OF_ISO="$LIST_OF_ISO "$(ls $ISO_DIR/$cd.iso*)
					continue
				}
				[[ "$n" -gt 1 ]] && {
					print "ERROR: Wrong value for tag $tag" >&2
					print "       More than one $cd.iso found." >&2
					error=1
					continue
				}

				#
				# n=0, so check if it is a directory
				#
				depot_dir=$DEPOT_DIR/$cd
				[[ -d $depot_dir ]] && continue

				print "ERROR: Wrong value for tag $tag" >&2
				#print "       More than one $cd.iso found." >&2
				print "       Can't find file    $ISO_DIR/$cd.iso*"   >&2
				print "       neither directory  $depot_dir"     >&2
				error=1
			fi	
		done
	fi

	#
	# Check other values
	#
	case "$OMCR" in
	    MS_PORTAL)
		check_emid      "EMID"                 || error=1
		check_plmn      "PLMN"                 || error=1
		;;
	    RNONPA)
		check_value_tbc "MS_PORTAL_SERVER"                     || error=1
		check_ip        "MS_PORTAL_SERVER_IP_ADR"              || error=1
		check_value     "RNO_1ST_DAY_WEEK" \
		 "Monday" "Tuesday" "Wednesday" \
		 "Thursday" "Friday"  "Saturday" "Sunday"       || error=1
		check_value     "RNO_CORBA_NAME_SERVICE_PORT" \
		 "5001" "5002"                                  || error=1
	        ;;
	esac

	return $error
}

check_raw() {
        status=0
        NR_OF_RAW=`grep "\/dev\/raw\/raw" /install/data/cluster.conf | wc -l`
        NR_OF_AVAILABLE_RAW=`raw -qa | wc -l`

        if [ ${NR_OF_RAW} -eq ${NR_OF_AVAILABLE_RAW} ]
        then
                print "Correct number of Raw Devices detected." >&2
        else
                status=1
        fi
        return $status
}

check_timezone() {
    status=0
	os_major_release=`lsb_release -r | awk -F' ' '{print $2}' | awk -F'.' '{print $1}'`
    if [[ ${os_major_release} -eq 6 ]]; then
		file=/etc/sysconfig/clock
		#tzval=$(awk -F\= '/^ZONE/{print $2;exit}' | awk -F\" '{print $2}' $file)
		tzval=$(awk 'BEGIN {FS="\""} /^ZONE/ {print $2}' $file)
    elif [[ ${os_major_release} -eq 7 ]]; then
        tzval=`timedatectl status | grep "Time zone" | awk -F ": " '{print $2}' | awk -F " " '{print $1}'`
	fi
        printf "%2s = %s\n" TIMEZONE "$tzval"

        listtz_file=$OMC_UNIX_INSTALL_DIR/lib/timezone_list.txt
        #egrep "$tzval" $listtz_file >/dev/null 2>&1
	grep "$tzval" $listtz_file >/dev/null 2>&1
        btime=$?
        if [[ $btime -eq 1 ]]; then
                status=1
        fi
        return $status
}

check_iso_files() {
	error=0

	print "=== Verifying for checksum of ISO images  ($(date))"
	for iso in $(echo $LIST_OF_ISO | sort -u)
	do
		cksum1=$(echo $iso | perl -lne 'print $1 if /cksum_(.*)/')
		[[ -z "$cksum1" ]] && {
			file="$ISO_DIR/CHECKSUMLIST.TXT"
			if [[ -a "$file" ]]; then
		        	biso=$(basename $iso)
				cksum1=$(awk '/^'$biso'[ \t]/{print $2}' $file)
                                [[ -z "$cksum1" ]] && {
                                      print "ERROR: Can't verify checksum for $iso because it isn't present in CHECKSUMLIST.TXT" >&2
                                      error=1
				      continue
                                }
                        else
		           print "WARNING $file file missing....... Can't verify checksum!" >&2
                           continue
			fi
		}
		printf "Checking ${iso}....  "
		if [ $OS_TYPE = "solaris" ]; then
			cksum2=$(cksum $iso | cut -f1)
		else
			cksum2=$(cksum $iso | cut -f1 -d ' ')
		fi
		if [[ "$cksum1" -eq "$cksum2" ]]; then
			log_message "INFO" "OK"
		else
			log_message "ERROR" "NOK"
			error=1
		fi
	done
	print "=== End of verification of checksum of ISO images  ($(date))"

	return $error
}

umount_all_cd() {
	os_type=`perl -e "print $^O"`
	if [ $os_type = "solaris" ]
	then
		mount   | awk '/\/dev\/lofi/{print "umount "$3" 2>/dev/null"}'     | sh
		lofiadm | awk '/\/dev\/lofi/{print "lofiadm -d "$1" 2>/dev/null"}' | sh
	else
		mount  -t iso9660 | awk '{print "umount "$1" 2>/dev/null"}'     | sh
	fi
}


#
# "cd"   is either an ISO file in $ISO_DIR directory
#        or a directory in $DEPOT_DIR directory
#        or a tar file in $DEPOT_DIR directory
#
mount_cd_int() {
	cd=$1
	mount_point=$2
	print "Mounting $cd on $mount_point"
	[[ $(ls $ISO_DIR/$cd.iso* 2>/dev/null | wc -l) -gt 1 ]] && {
		print "ERROR: more than one $cd.iso" >&2
		exit 1
	}
	image_iso=$(ls $ISO_DIR/$cd.iso* 2>/dev/null)
	os_type=`perl -e "print $^O"`
	[[ ! -z "$image_iso" ]] && [[ $os_type = "solaris" ]] && {
		lofiadm $image_iso > /dev/null 2>&1 || {
			lofiadm -a $image_iso > /dev/null || exit 1
		}
		sleep 3
		dev=$(lofiadm $image_iso)
		mount | grep " $dev " > /dev/null || {
			rm -fr $mount_point   || exit 1
			mkdir -p $mount_point || exit 1
			mount -F hsfs $dev $mount_point || {
				#try again the mount
				sleep 1
				mount -F hsfs $dev $mount_point || exit 1
			}
		}
		return
	}	
	
	[[ ! -z "$image_iso" ]] && [[ $os_type = "linux" ]] && {
		mount | grep " $image_iso " > /dev/null || {
                        rm -fr $mount_point   || exit 1
                        mkdir -p $mount_point || exit 1
                        mount -o ro,loop -t iso9660 $image_iso $mount_point || exit 1
                }
		return
	}	

	depot_dir=$DEPOT_DIR/$cd
	[[ -d $depot_dir ]] && {
		rm -fr $mount_point           || exit 1
		ln -s $depot_dir $mount_point || exit 1
		return
	}

	btarfile=$DEPOT_DIR/$cd
	[[ $(ls $btarfile.tar $btarfile.TAR 2>/dev/null | wc -l) -gt 1 ]] && {
		print "ERROR: more than one $cd.tar tarfiles" >&2
		exit 1
	}
	tarfile=$(ls $btarfile.tar $btarfile.TAR 2>/dev/null)
	[[ -z "$tarfile" ]] || {
		rm -fr $mount_point                             || exit 1
		(cd $(dirname $mount_point) && tar xf $tarfile) || exit 1
		[[ -d $mount_point ]] || {
			print "ERROR: $tarfile should have $(banename $mount_point) as top directory." >&2
			exit 1
		}
		return
	}
	
	print "Can't find $ISO_DIR/$cd.iso* file"             >&2
	print "   neither $depot directory"                   >&2
	print "   neither $depot.tar or $depot.TAR tar file"  >&2
	exit 1
}

mount_cd() {
	cd_key=$1			# CD key (ie: THIRD_PARTIES)
	
	cd=$(eval print \$$cd_key)	# CD value (ie: $THIRD_PARTIES)
	[[ -z "$cd" ]] && {
		print "ERROR: Unknown value of $cd_key" >&2
		exit 1
	}

	mount_cd_int $cd $INSTALL_DIR/$cd_key
}

umount_cd() {
	cd_key=$1			# CD key (ie: THIRD_PARTIES)
	
	cd=$(eval print \$$cd_key)	# CD value (ie: $THIRD_PARTIES)
	[[ -z "$cd" ]] && {
		print "ERROR: Unknown value of $cd_key" >&2
		exit 1
	}
	print "Unmounting $cd_key ($cd)"
	image_iso=$(ls $ISO_DIR/$cd.iso* 2>/dev/null)
	os_type=`perl -e "print $^O"`
	if [ $os_type = "solaris" ]
	then
		dev=$(lofiadm "$image_iso")
		mount_point=$(mount | grep "$dev " | awk '{print $1}')
		[[ -z "$mount_point" ]] || umount $mount_point
        	[[ -z "$dev" ]]         || lofiadm -d $dev
	else
		umount $image_iso
	fi
}

if [ -f $OMC_UNIX_INSTALL_DIR/delivery.data ]
then
        . $OMC_UNIX_INSTALL_DIR/delivery.data
fi

print_version() {
        if [ x${SI_LABEL} != x ]
        then
                log_message "INFO" "--- OMC_INST version: M50_$SI_LABEL ---"
        fi
}

check_storedge() {
 for port in `fcinfo hba-port | awk '/HBA Port WWN/ {print $4}' | uniq`
 do
        state=`fcinfo hba-port $port | awk '/State:/ {print $2}'`
        if [ "x$state" = "xonline" ]
        then
                #search for SE3510 and SE2540, we can have mixed configurations
                #echo "PORT $port is $state"
                for remoteWWN in `fcinfo remote-port -sp $port | awk '/Remote Port WWN:/ {print $4}'`
                do
                        #echo " Working on $port $remoteWWN"
                        fcinfo remote-port -sp $port $remoteWWN | grep "/dev/rdsk" > /dev/null
                        c1=$?
                        fcinfo remote-port -sp $port $remoteWWN | grep "Product: LCSM100_F" > /dev/null
                        c2=$?
                        fcinfo remote-port -sp $port $remoteWWN | grep "Product: StorEdge 3510" > /dev/null
                        c3=$?
                        #count only 2540 devices
                        if [ $c1 -eq 0 -a $c2 -eq 0 ]
                        then
                                nodeWWN=`fcinfo remote-port -sp $port $remoteWWN | awk '/Node WWN:/ {print $3}'`
                                echo $remoteWWN2540 | grep $nodeWWN
                                if [ $? -ne 0 ]
                                then
                                        #echo "Add $nodeWWN to 2540 list"
                                        remoteWWN2540=${remoteWWN2540}" ${nodeWWN}"
                                fi
                        fi
                        #count 3510 devices
                        if [ $c1 -eq 0 -a $c3 -eq 0 ]
                        then
                                nodeWWN=`fcinfo remote-port -sp $port $remoteWWN | awk '/Node WWN:/ {print $3}'`
                                echo $remoteWWN3510 | grep $nodeWWN
                                if [ $? -ne 0 ]
                                then
                                        #echo "Add $nodeWWN to 3510 list"
                                        remoteWWN3510=${remoteWWN3510}" ${nodeWWN}"
                                fi
                        fi
                done
        fi
 done
 nr2540=`echo $remoteWWN2540 | awk  '{print NF}'`
 log_message "INFO" "Number of connected StorEdge 2540: $nr2540"
 nr3510=`echo $remoteWWN3510 | awk  '{print NF}'`
 log_message "INFO" "Number of connected StorEdge 3510: $nr3510"
 ((total=$nr2540+$nr3510))
 return $total;
}

#Check IP links for Cluster 
check_ip_links() {
        status=0
        HOST_NAME=`hostname`
        public_interface=`netstat -i | awk '$4 ~ /^'"${HOST_NAME}"'$/ { print $1 }'`
        if [ x${public_interface} == "x" ]
        then
                log_message "WARNING" "can not find public IP interface, status check not performed."
                public_status=1
        else
                public_status=`kstat \`echo $public_interface | sed -e "s/\(.*\)\([0-9]\)/\1:\2/"\` | awk '/link_up/ {print $2;exit}'`
        fi
        log_message "INFO" "Public interface: $public_interface       status: $public_status"
        private_interface=`netstat -i | awk '$4 ~ /^'"${HOST_NAME}"'-priv$/ { print $1 }'`
        if [ x${private_interface} == "x" ]
        then
                log_message "WARNING" "can not find private IP interface, status check not performed."
                private_status=1
        else
                private_status=`kstat \`echo $private_interface | sed -e "s/\(.*\)\([0-9]\)/\1:\2/"\` | awk '/link_up/ {print $2;exit}'`
        fi
        log_message "INFO" "Private interface: $private_interface     status: $private_status"
        if [ $public_status -eq 0 ]
        then
                log_message "ERROR" "connect IP cable to the public interface $public_interface!"
                status=1
        fi
        if [ $private_status -eq 0 ]
        then
                log_message "ERROR" "connect IP cable to the private interface $private_interface!"
                status=1
        fi
        return $status
}

function check_partition {
  if [ x$1 = "x" ]
  then
    log_message "ERROR" "running check_partition: give the partition to be checked"
    return 0
  fi
  os_type=`perl -e "print $^O"`
  if [ $os_type = "solaris" ]
  then 
	mount | /usr/xpg4/bin/grep "^$1[[:space:]]"
  else
	mount | grep "[[:space:]]$1[[:space:]]"
  fi
  if [ $? -ne 0 ]
  then
	log_message "ERROR" "missing partition $1"
        exit 1
  fi
}

function get_os {
	OS_TYPE=`perl -e "print $^O"`
	return $OS_TYPE
}

function check_free_space {
        check_part=$1
        OS_TYPE=`perl -e "print $^O"`
        if [ $OS_TYPE = "solaris" ]
        then
                free_mb=`df -k $check_part | awk ' $1 !~ /Filesystem/ { print int($4/1024)}'`
        else
                free_mb=`df -m $check_part | awk ' $1 !~ /Filesystem/ { print $4}'`
        fi
}

function check_file_rights {
	check_Ora_version
	binfile_location="/opt/app/oracle/product/${ora_version}/bin"
	if [ -f ${binfile_location}/oracle ]; then
		log_message "INFO" "Binary files rights:" | tee -a $logfile
		ls -l ${binfile_location}/oracle* | tee -a $logfile
	else
		log_message "WARNING" "Location ${binfile_location}/oracle does not exist" | tee -a $logfile
	fi
}

function check_Ora_version {
        orafile=/etc/oratab
        if [ -f $orafile ]; then
                ora_version=`awk -F: '$1 ~/^SNM$/ {print $2}' $orafile | sed -e "s#.*product/##"`
                if [ ! "$ora_version" ];then
                        ora_version=$(ls /opt/app/oracle/product/)
                fi
                log_message "INFO" "Found Oracle version : $ora_version" | tee -a $logfile
        else
                log_message "ERROR" "$orafile does not exists" | tee -a $logfile
                restore_motd 1
                exit 1
        fi

}

function check_Ora_processes {
        #use in case of upgrade
        #check SNM processes
        PROC1=`ps -ef | grep SNM | grep -v grep | grep -v find | grep -v gzip | grep -v racg`
	res=$?
        if [ $res -eq 0 ]; then
                log_message "WARNING" "Oracle database processes are stil running:" | tee -a $logfile
                log_message "WARNING" "$PROC1" | tee -a $logfile
                log_message "WARNING" "Exiting installation script" | tee -a $logfile
                restore_motd 1
                exit 1
	else
		log_message "INFO" "Oracle database processes are not running" | tee -a $logfile
        fi
	
	#DCTPD01880427 - check_ora_processes fails to kill all processes
        #stop LISTENER process
        GRID_ENV=`grep ORACLE_HOME /alcatel/var/home/oracle/.grid_profile`

	log_message "INFO" "Checking Listener" | tee -a $logfile
	su - oracle -c "$GRID_ENV; $"ORACLE_HOME"/bin/lsnrctl status" | tee -a $logfile

	log_message "INFO" "Stopping Listener" | tee -a $logfile
        su - oracle -c "$GRID_ENV; $"ORACLE_HOME"/bin/lsnrctl stop" | tee -a $logfile
        sleep 30

        #check if LISTENER process is indeed stopped
        PROC2=`ps -ef | grep tnslsnr | grep -v grep`
        res=$?
        if [ $res -eq 0 ]; then
                log_message "INFO" "Oracle Listener process $PROC2 is stil running, forcing process termination" | tee -a $logfile
                LSNR_PID=`ps -ef | grep tnslsnr | grep -v grep | awk '{print $2}'`
                log_message "INFO" "Terminating process $LSNR_PID" | tee -a $logfile
                kill -9 $LSNR_PID

                #wait few seconds for stopping listener , then check again
                sleep 20

                count=0
                while [ $count -le 10 ]; do
                        sleep 10
                        LSNR_CHECK=`ps -eaf | grep tnslsnr | grep -v grep`
                        if [ $? -eq 0 ]; then
                                log_message "ERROR" "Listener pid: $LSNR_CHECK" | tee -a $logfile
                                log_message "ERROR" "Listener is still running and it could not be killed, exiting..." | tee -a $logfile
                                su - oracle -c "$GRID_ENV; $"ORACLE_HOME"/bin/lsnrctl status" | tee -a $logfile
                                exit 1
                        fi
                        let "count=count+1"
                done
        else
                log_message "INFO" "Oracle Listener process is not running" | tee -a $logfile
        fi

}

function oracle_stop {

$OMC_UNIX_INSTALL_DIR/oracle/ora_processes.sh stop || {
	log_message "ERROR" "[INSTALL]: could not stop Oracle."
        exit 1
}
sleep 30

}

function oracle_start {

$OMC_UNIX_INSTALL_DIR/oracle/ora_processes.sh start || {
        log_message "ERROR" "[INSTALL]: could not start Oracle."
        exit 1
}
sleep 30


}


function pmon_stop {

if [ -f /alcatel/MS/MS_PMON/scripts/pmon.sh ]; then
	/alcatel/MS/MS_PMON/scripts/pmon.sh stop >/dev/null 2>&1 || {
                log_message "ERROR" "[INSTALL]: The processes are still running."
		exit 1
	}
else
	log_message "ERROR" "[INSTALL]: /alcatel/MS/MS_PMON/scripts/pmon.sh not found ..." 
	exit 1
fi
sleep 10

}

function pmon_start {

if [ -f /alcatel/MS/MS_PMON/scripts/pmon.sh ]; then
        /alcatel/MS/MS_PMON/scripts/pmon.sh start >/dev/null 2>&1 || {
                  log_message "ERROR" "[INSTALL]: The processes could not be started."
                  exit 1
	}
else
        log_message "ERROR" "[INSTALL]: /alcatel/MS/MS_PMON/scripts/pmon.sh not found ..."
        exit 1
fi
sleep 10

}


function open_required_ports_in_iptables {
	SERVER_TYPE=`grep TYPE /etc/MUSE.signature | awk '{print $2}'`
	if [ $OS_TYPE = "linux" ] && [ "$SERVER_TYPE" = "NPO" ]; then
		#CR 560148:  add the entry 1521 in  /etc/sysconfig/alu-iptables.sh in OPEN_TCP_PORTS and OPEN_UDP_PORTS
		introduce_port_in_iptables 1521
		introduce_port_in_iptables 10050:10070
	fi	
	#RCI: DCTPD00987054 - FO_AL:NPO5.3 LR13.1W:NPO:Java exception occurs when accessing the Log Browser tab on the PMON web pages for Aux servers
        if [ "$SERVER_TYPE" != "NPO" ]; then
              introduce_port_in_iptables 5310
        fi

	if [ "$SERVER_TYPE" = "AUX_SON" ]; then
		introduce_port_in_iptables 8013
	fi
}

function introduce_port_in_iptables {
		port_to_add=$1	
		file="/etc/sysconfig/alu-iptables.sh"
		perl -e '
                        ($file, $port)=@ARGV;
			
                        open(F,"$file") or die "Cannot open $file: $!\n";
                        @file=<F>;
                        close F;
                        for(@file) {
                        if(/^\s*OPEN_(TCP|UDP)_PORTS="/) {
                                if(not /["\s]$port["\s]/) {
                                        s/="/="$port /;
                                        $file_to_be_modifed=1;
                                }
                                }
                        }
                	if($file_to_be_modifed) {
                        	print "$file: Adding ports $port in iptables $file\n";
                        	system("cp -p $file ${file}.${port}") if not -f "$file.$port";
                        	open(F,">$file")        or die "Cannot open $file: $!\n";
                        	print F @file;
                        	close F;
                	}
                	else {
                        	print "$file: port $port OK \n";
                	}
                ' "$file" "$port_to_add" || {
                        log_message "ERROR" "$file file modification failed" >&2
                        exit 1
                }

}

function terminate_sqlplus_sessions {
        # kills active SQL+ sessions

        session_list=$(ps -ef | grep sqlplus | grep -v grep | awk '{ print $2; }')
        if [ -z "$session_list" ]; then
		log_message "INFO" "No SQLplus sessions are running" | tee -a $logfile
	else
		log_message "INFO" "Found the following SQLplus sessions running on this machine: $session_list" | tee -a $logfile
                for pid in $session_list
                do
                        log_message "INFO" "Terminating process: $pid"
                        kill -9 $pid
                done
        fi

}

#RCI: DCTPD01228706 - [GSM][NPO][B12][95156] During the migration, the server is rebooted for ipv6, and CSA has no sufficient time to be running
function check_csa_status {
        #set -x
        log_message "INFO" "+---  CHECK CSA STATUS ---+"
        CSAPWDFILE=/alcatel/MS/OMC_CSACF/config/p.file
        CSA_ADMIN="csaadmin"
        RUN_CLI_PATH=/alcatel/csa/ngsec/NGSEC/bin/system/cli
        error_status=-1
        tmp=/tmp/out.$$

        x=`ps -ef | grep csa | grep jboss | grep run`
        if [ "$x" != "" ]
        then

                (exec  ${RUN_CLI_PATH}/runCLI.sh -login [$CSA_ADMIN] -passEncrypt [$CSAPWDFILE] -unInteractive -action [list_users] > $tmp) > /dev/null 2>&1
                result=`tail -1 $tmp`
                if [ "$result" == "SUCCESS" ]
                then
                        status=0
                else
                        status=$error_status
                fi
                rm -f $tmp
        else
                status=$error_status
        fi
        if [ $status -eq 0 ]; then
                log_message "INFO" "CSA status = RUNNING"
        else
                log_message "INFO" "CSA status = NOK"
        fi
        return $status
}


function wait_for_oracle {

	log_message "INFO" "Please wait..."
	set +e
	while true
	do
       		mon=`ps -ef | grep ora_pmon_SNM | grep -v grep | wc -l | awk '{print $1}'`
        	if [ $mon -ne 0 ]; then
                	break
        	fi
        	sleep 20
	done

	log_message "INFO" "Wait until Database is up..."
	check_db_open
	while [ $DB_OK = 1 ]
	do
		log_message "INFO" "Database not up yet."
		sleep 2
		check_db_open
	done
	sleep 15
	log_message "INFO" "Oracle is running"

}

function check_db_open {

check_Ora_version
DB_HOME="/opt/app/oracle/product/${ora_version}"

if [ $RAC -eq 1 ]; then
	export ORACLE_SID=SNM1
else
	export ORACLE_SID=SNM
fi

export ORACLE_HOME=$DB_HOME

STATUS=`su - oracle -c "export ORACLE_SID=$ORACLE_SID;
	export ORACLE_HOME=$DB_HOME
	$ORACLE_HOME/bin/sqlplus -s /nolog <<- EOF
	connect sys/orapower as sysdba
	set feed off echo off head off
        SET SERVEROUTPUT ON;
	SELECT 'Open' FROM dual;
	quit
	EOF
	"
	`

STATUS=`echo $STATUS | tr -d '	'`
if [ "$STATUS" = "Open" ]; then
	DB_OK=0
else
	DB_OK=1
fi

}

check_RH_version ()
{
	rh_minor_ver=`lsb_release -r | awk '{print $2}' | awk -F. '{print $1}'`
	return $rh_minor_ver
}

function check_db_state {
. /install/data/cluster.conf
rm -rf /tmp/database_state.lst
check_Ora_version
DB_HOME="/opt/app/oracle/product/${ora_version}"
DB_STATE=1
timer=0
while [ $DB_STATE -eq 1 ] && [ $timer -lt 12 ]; do
        sleep 5
if [ $RAC -eq 1 ]; then
        export ORACLE_SID=SNM1
else
        export ORACLE_SID=SNM
fi

export ORACLE_HOME=$DB_HOME

timer=timer=$(($timer+1))

su - oracle -c "export ORACLE_SID=$ORACLE_SID;
                export ORACLE_HOME=$DB_HOME
        $ORACLE_HOME/bin/sqlplus -s /nolog <<- EOF
connect sys/orapower as sysdba
SET SERVEROUTPUT ON;
spool /tmp/database_state
SELECT open_mode FROM v\\\$database;
spool off
quit
EOF
"

        cmd=`egrep 'READ|MOUNTED' /tmp/database_state.lst`
        if [ $? -eq 1 ]; then
                DB_STATE=1
        else
                DB_STATE=0
        fi

        rm -rf /tmp/database_state.lst

done


if [ $DB_STATE -eq 1 ]; then
        log_message "ERROR" "Data base not mounted. Exiting...."
    exit 1

else
        log_message "INFO" "Data base mounted"
fi
}

broadcast_AUX_message_on_MAIN () {
#set -x
        MESSAGE=" $(date '+DATE: %m/%d/%g TIME: %H:%M:%S') -  AUX $(hostname) :"
        if [ $1 -eq 0 ]; then
                MESSAGE="${MESSAGE} UPGRADE ACTION FINISHED. Please check the INSTALLATION LOG FILES on AUX server. "
        else
                MESSAGE="${MESSAGE} UPGRADE ACTION FINISHED ABNORMALLY. Please check the INSTALLATION LOG FILES on AUX server. "
        fi
        su - axadmin -c "ssh $CONTROLLER_IP sudo -u root /alcatel/MS/MS_AUTOINSTALL/scripts/broadcast_message.sh $MESSAGE"
}


## restore the original welcome message for terminal connections
restore_motd () {
#set -x
  exitVal=$1
  log_message "INFO" "End    $0"
  log_message "INFO" " Exit value: $exitVal"
  log_message "INFO" "================================================================="
  if [ ! -z $2 ]; then
  	log_message "INFO" "$2"
  fi
  pwdLoc=`pwd`
  cd $OMC_UNIX_INSTALL_DIR/../log
  put_msg "  `date '+DATE: %m/%d/%g TIME: %H:%M:%S'` *** CHECKING INSTALL LOGS***"
  ./check_install_logs.sh
  cd $pwdLoc
  put_msg "  `date '+DATE: %m/%d/%g TIME: %H:%M:%S'` *** INSTALL/UPGRADE ACTION FINISHED. Please check the INSTALLATION LOG FILES. ***"
  [ -f $file_motd_orig ] && cp -f $file_motd_orig $file_motd

# In case of UPGRADE on AUX, broadcast message to main that install is finished
if [ "$ACTION" = "UPGRADE" ]; then
        if [ "$SERVER_TYPE" != "NPO" ]; then
                broadcast_AUX_message_on_MAIN $exitVal
        fi
fi
  
}

## send the specified messege to all conected terminals
put_msg() {
        msg="$1"
        echo -e "\n\n${msg}\n\n " > ${file_motd}
        wall "`cat ${file_motd}`"
}

history_configuration() {
custom=/etc/profile.d/custom.sh
profile=/etc/profile
ora_profile=/alcatel/var/home/oracle/.bashrc
tmp_file=/tmp/profile_tmp


rm -f ${tmp_file}


if [[ ! -f  $custom ]]; then
        echo "$custom doesn't exit. Starting HISTORY configuration... "
        grep "History configuration for Linux"  $profile
        if [ $? -eq 0 ];then
                echo "Removing old HIST configuration from $profile"
                sed '/ ### History/,/export HISTSIZE HISTTIMEFORMAT HISTFILESIZE HISTFILE/d' /etc/profile > ${tmp_file}
                mv ${tmp_file} $profile
                rm -f ${tmp_file}
        fi
        grep "HISTSIZE="  $profile
        if [ $? -eq 0 ];then
                echo "Removing HIST configuration from $profile"
                cp $profile ${profile}_ORIG
                /bin/cat $profile | /bin/sed -e '/HISTSIZE=/d' $profile \
                -e "s/HISTSIZE HISTCONTROL/ /g" > ${tmp_file}
                mv ${tmp_file} $profile
                rm -f ${tmp_file}
        fi

        grep "History configuration for Linux"  $ora_profile
        if [ $? -eq 0 ];then
                echo "Removing HIST configuration from $ora_profile"
                rm -f ${tmp_file}
                sed '/ ### History/,/export HISTSIZE HISTTIMEFORMAT HISTFILESIZE HISTFILE/d' $ora_profile > ${tmp_file}
                mv ${tmp_file} $ora_profile
                rm -f ${tmp_file}
                chown oracle:oinstall $ora_profile
        chmod 640 $ora_profile
        fi
        mkdir  /home/.hist
        chmod 777 /home/.hist
        touch $custom
        chmod +x $custom

        echo -e "#!/bin/bash
### History configuration for Linux ###\n
HISTSIZE=500000
HISTTIMEFORMAT='%F %T '
HISTFILESIZE=500000
user=\`/usr/bin/id|/bin/sed 's/).*//;s/.*(//'\`
HISTFILE=/home/.hist/sh_hist_\${user}_\`date '+%m-%d-%Y_%H:%M:%S'\`
export HISTSIZE  HISTFILE HISTFILESIZE HISTTIMEFORMAT " >> ${custom}
else
	echo "$custom exists, skipping HIST configuration steps..."
fi
}

add_syslog_filter() {
	conf_file=/etc/rsyslog.d/ignore-su-session-slice.conf
	if [ -f ${conf_file} ]; then
		log_message "INFO" "${conf_file} exists on server, make it empty"
		cat /dev/null > ${conf_file}
	else
		log_message "INFO" "${conf_file} is not existed on server, create a new one"
		mkdir -p /etc/rsyslog.d
		touch ${conf_file}
		chmod 777 ${conf_file}
	fi
	echo 'if ($programname == "su" and ($msg contains "root on none")) or ($programname == "systemd" and ($msg contains "Starting Session" or $msg contains "Started Session")) or ($programname == "systemd-logind" and ($msg contains "New session" or $msg contains "Removed session")) then stop' > ${conf_file}
}
