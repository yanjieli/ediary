#!/bin/bash
#===============================================================================
#
#          FILE:  install_patch.sh
# 
#         USAGE:  bash install_patch.sh [--rollback]
# 
#   DESCRIPTION:  Patch for TLS1.0 security vulnerability
#   DCT 01928682.02 -- AT&T_FOA_FL17: Security Vulnerability - TLS 1.0 to be removed from NPO
#          BUGS:  ---
#         NOTES:  ---
#        AUTHOR:  ZHENG Zhaoqing A <Zhaoqing.a.Zheng@nokia-sbell.com>
#       COMPANY:  Nokia
#       VERSION:  1.0
#       CREATED:  28/08/2017 16:00 CST
#      REVISION:  ---
#===============================================================================

###########################Variables#####################################
unalias cp 2>/dev/null


LOG=/alcatel/install/log/$(basename $0)_$(date +%Y-%m-%d_%H-%M-%S).log.$$

patchName=$(basename $0 | sed 's/\.sh//g')
patchVersion="1.0"

file1="/alcatel/csa/ngsec/jboss-6.1.0.Final/server/NGSEC/deploy/jbossweb.sar/server.xml"
file2="/opt/apache/conf/httpd.conf"
signatureFile="/etc/MUSE.signature"

file_list="/alcatel/MS/MS_PMON/scripts/pmon.sh /alcatel/MS/MS_PMON/scripts/startstop/stop_omc /alcatel/MS/MS_PMON/scripts/startstop/start_omc /alcatel/MS/MS_PMON/scripts/startstop/stop_http /alcatel/MS/MS_PMON/scripts/startstop/stop_csa /alcatel/MS/MS_PMON/scripts/startstop/start_http /alcatel/MS/MS_PMON/scripts/startstop/start_csa $file1 $file2 $signatureFile"

backup_dir=/alcatel/muse/scripts/${patchName}/backup

patch_installed="false"
cat $signatureFile | grep $patchName > /dev/null && patch_installed="true"

omc_process_flag="stop"
ps -ef | egrep ' /[t]mp/notserv' > /dev/null && omc_process_flag="start"
pmon_process_flag="stop"
ps -ef | grep "/alcatel/MS/MS_PMON/bin/pmon" | grep -v grep > /dev/null && pmon_process_flag="start"
http_process_flag="stop"
ps -ef | grep "/opt/apache/bin/httpd" | grep -v grep >/dev/null 2>&1 && http_process_flag="start"
csa_process_flag="stop"
ps -ef | grep "/alcatel/csa/ngsec/jboss/bin/run.sh" | grep -v grep >/dev/null 2>&1 && csa_process_flag="start"

usage() {
	cat <<- ! >&2
		Usage: bash $(basename $0) [--rollback]
	!
	exit 1
}

init_check() {
	[ "x$(uname -s)" = "xLinux" ] || { 
		log_message "ERROR" "This patch is applicable only to Linux"
		exit 1 
	}
	
	[ "x$(whoami)" = "xroot" ] || { 
		log_message "ERROR" "Only root can run this script"
		exit 1 
	}
	
	for FILE in ${file_list}; do
		[ -f "${FILE}" ] || { 
			log_message "ERROR" "${FILE} is not available on server"
			exit 1
		}
	done
	
	if [ -d ${backup_dir} ]; then
		log_message "WARNING" "${backup_dir} is available on server, empty it"
		/bin/rm -rf ${backup_dir}/*
	else
		log_message "INFO" "Creating ${backup_dir}"
		if /bin/mkdir -p ${backup_dir}; then
			log_message "ACTION" "${backup_dir} is created."
			chmod 777 ${backup_dir}
		else
			log_message "ERROR" "${backup_dir} cannot be created."
			exit 1
		fi
		
		
	fi
	
}

check_and_stop_omc() {
	ps -ef | egrep ' /[t]mp/notserv' > /dev/null && {
		
		log_message "INFO" "OMC will be stopped in 5s"
		for ((i=0;i<5;i++))
		do
			echo "."
			sleep 1
		done
		
		log_message "ACTION" "Stop OMC..."
		/alcatel/MS/MS_PMON/scripts/startstop/stop_omc > /dev/null
		
		# Waiting for 10 mn max
		for ((i=0;i<120;i++))
		do
			sleep 5
			#grep "OMC" /alcatel/var/export/pub/MS/pmon/PMON_state.html | grep stopped > /dev/null && break
			ps -ef | egrep ' /[t]mp/notserv' > /dev/null || break
		done
		log_message "INFO" "OMC is stopped"
		
		[ $i -eq 120 ] && log_message "ERROR" "Can't stop OMC in 10 minutes" && exit 1
	}
}

check_and_start_omc() {
	ps -ef | egrep ' /[t]mp/notserv' > /dev/null || {		
		log_message "ACTION" "Start OMC..."
		/alcatel/MS/MS_PMON/scripts/startstop/start_omc > /dev/null
		
		# Waiting for 10 mn max
		for ((i=0;i<120;i++))
		do
			sleep 5
			ps -ef | egrep ' /[t]mp/notserv' > /dev/null && break
			#grep "OMC" /alcatel/var/export/pub/MS/pmon/PMON_state.html | grep running > /dev/null && break
		done
		log_message "INFO" "OMC is startted"
		
		[ $i -eq 120 ] && log_message "ERROR" "Can't start OMC in 10 minutes" && exit 1
	}
}

update_file() {
	log_message "ACTION" "Start to update $file1 for sslEnabledProtocols..."
	log_message "INFO" "Old value in $file1 on sslEnabledProtocols:"
	cat $file1 | grep sslEnabledProtocols
	/bin/cp -f $file1 ${backup_dir}
	perl -pi -e 's#sslEnabledProtocols=.*#sslEnabledProtocols="-all +TLSv1.1 +TLSv1.2"#g;' $file1
	log_message "INFO" "New value in $file1 on sslEnabledProtocols:"
	cat $file1 | grep sslEnabledProtocols
	
	log_message "ACTION" "Start to update $file2 for SSLProtocol..."
	log_message "INFO" "Old value in $file2 on SSLProtocol:"
	cat $file2 | grep SSLProtocol
	/bin/cp -f $file2 ${backup_dir}
	perl -pi -e 's#SSLProtocol.*#SSLProtocol -all +TLSv1.1 +TLSv1.2#g;' $file2
	log_message "INFO" "New value in $file2 on SSLProtocol:"
	cat $file2 | grep SSLProtocol
}

pmon_stop() {
	log_message "INFO" "Check and Stop PMON..."
	ps -ef | grep "/alcatel/MS/MS_PMON/bin/pmon" | grep -v grep > /dev/null && {
		log_message "ACTION" "PMON is running, stop it..."
		/alcatel/MS/MS_PMON/scripts/pmon.sh stop >/dev/null 2>&1 || { 
			log_message "ERROR" "[INSTALL]: The PMON is still running."
			exit 1
		}
	}
	sleep 10
}

pmon_start() {
	log_message "INFO" "Check and Start PMON..."
	ps -ef | grep "/alcatel/MS/MS_PMON/bin/pmon" | grep -v grep > /dev/null || {
		log_message "ACTION" "PMON is not running, start it..."
		/alcatel/MS/MS_PMON/scripts/pmon.sh start >/dev/null 2>&1 || {
			log_message "ERROR" "[INSTALL]: The PMON could not be started."
			exit 1
		}
	}
	sleep 10
}

check_restart_http_csa() {
	
	log_message "INFO" "Check and restart HTTP server..."
	[ $http_process_flag = "start" ] && {
		log_message "ACTION" "HTTP server is running, stop it..."
		/alcatel/MS/MS_PMON/scripts/startstop/stop_http >/dev/null 2>&1 || {
			log_message "ERROR" "[INSTALL]: The HTTP could not be stopped." 
			exit 1
		}
		sleep 5
		
		/alcatel/MS/MS_PMON/scripts/startstop/start_http >/dev/null 2>&1 || {
			log_message "ERROR" "[INSTALL]: The HTTP could not be started." 
			exit 1
		}
		sleep 5
	}
	
	log_message "INFO" "Check and restart CSA..."
	[ $csa_process_flag = "start" ] && {
		log_message "ACTION" "CSA is running, stop it..."
		/alcatel/MS/MS_PMON/scripts/startstop/stop_csa >/dev/null 2>&1 || {
			log_message "ERROR" "[INSTALL]: The CSA could not be stopped."
			exit 1
		}
		sleep 5
		
		/alcatel/MS/MS_PMON/scripts/startstop/start_csa >/dev/null 2>&1 || {
			log_message "ERROR" "[INSTALL]: The CSA could not be started."
			exit 1
		}
		sleep 5
	}
	
	
}

log_message () {
    timestamp=`date '+%d-%m-%y %H:%M:%S'`
    echo -e "[${timestamp}] $1: $2"
}

install_patch_sign() {
	log_message "ACTION" "Installing the patch signature"
	installDate=`date`
	echo -e "\n" >> $signatureFile
	echo -e "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" >> $signatureFile
	echo -e "     -=( $patchName )=- by Nokia on $installDate    " >> $signatureFile
	echo -e "           CSA TLS1.0 removal patch version $patchVersion       " >> $signatureFile
	echo -e "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" >> $signatureFile
}

rollback_file() {
	log_message "ACTION" "Rollback patch updated files..."
	tmp_list="$file1 $file2"
	for FILE in ${tmp_list}; do
		file_tmp=$(basename $FILE)
		[ -z "$file_tmp" ] || /bin/mv ${backup_dir}/$file_tmp $FILE
	done
	/bin/rm -rf $(dirname ${backup_dir})
}

remove_patch_sign() {
	log_message "ACTION" "Removing the patch signature"
	
	SIGNATUREFILE_ORI=$signatureFile
	SIGNATUREFILE_BAK="/etc/MUSE.signature.bak"
	SIGNATUREFILE_NEW="/etc/MUSE.signature.new"
	/bin/cp -f ${SIGNATUREFILE_ORI} ${SIGNATUREFILE_BAK}
    
    LN=`egrep -n "${patchName}" ${SIGNATUREFILE_ORI} | cut -d: -f1`
    if [ "x${LN}" != "x" ]; then
    	ST=`expr $LN - 1`
    	ED=`expr $LN + 2`
    	echo "sed '${ST},${ED}d' ${SIGNATUREFILE_ORI} > ${SIGNATUREFILE_NEW}" | sh
    	if [ $? = 0 ]; then
    		/bin/mv -f ${SIGNATUREFILE_NEW} ${SIGNATUREFILE_ORI}
    	else
    		/bin/cp -f ${SIGNATUREFILE_BAK} ${SIGNATUREFILE_ORI}
    		log_message "ERROR" "$patchName signature cannot be removed"
    		exit 1
    	fi
    else
    	log_message "ERROR" "$patchName cannot be located in $signatureFile"
    	exit 1
    fi
}

###########################Main#####################################
{
  log_message "ACTION" "Start $0 ..."
  
  rollback=false
  if [ $# -gt 0 ]; then
	case "$1" in
	    --rollback)	rollback=true ; shift ;;
	    *)		usage ;;
	esac
  fi
  [ $# -gt 0 ]	&& usage
  
  [ "$patch_installed" = "false" ] && {
  	[ "$rollback" = "true" ] && {
  		log_message "ERROR" "$patchName is not installed, cannot rollback!"
  		exit 1
  	}
  	
  	init_check
  	[ $omc_process_flag = "start" ] && check_and_stop_omc
  	[ $pmon_process_flag = "start" ] && pmon_stop
  	update_file
  	check_restart_http_csa
  	install_patch_sign
  	[ $pmon_process_flag = "start" ] && pmon_start
  	[ $omc_process_flag = "start" ] && check_and_start_omc
  	
  }
  
  [ "$patch_installed" = "true" ] && {
  	[ "$rollback" = "false" ] && {
  		log_message "INFO" "$0 is installed already, no need to apply again."
  		exit 0
  	}
  	rollback_file
  	check_restart_http_csa
  	remove_patch_sign
  }

  log_message "ACTION" "End $0 ..."

} 2>&1 | tee -a $LOG

global_exit_code=${PIPESTATUS[0]}
[ "x${global_exit_code}" = "x" ] && {
	echo "Cannot fetch correct exit code from PIPESTATUS" | tee -a $LOG
	exit 1
}
if [ "${global_exit_code}" -ne 0 ]; then
	exit $global_exit_code
fi
exit 0

