#!/bin/ksh
#set -x
CUR_DIR=`pwd`

me=`basename $0`

ls $CUR_DIR | grep $me > /dev/null
if [ $? -ne 0 ]
then
	echo "ERROR : $me not found in current directory: $CUR_DIR"
	exit 1
fi

SERVER_TYPE=`awk '$1 ~ /^TYPE$/ {print $2;exit}' /etc/MUSE.signature`
if [ x$SERVER_TYPE = "x" ]
then
	echo "ERROR : Can not detect server type"
	exit 2
fi

OMC_UNIX_INSTALL_DIR="$CUR_DIR/.."
export OMC_UNIX_INSTALL_DIR

if [ -f /install/data/OMC_INSTALL ]; then
    . /install/data/OMC_INSTALL
else
    echo "ERROR could not load file /install/data/OMC_INSTALL"
    exit 1
fi

OS_TYPE=`perl -e "print $^O"`
export OS_TYPE

. $OMC_UNIX_INSTALL_DIR/lib/install.sh

ntp_file=/etc/ntp.conf
stop_oracle_cmd="$GRID_HOME/bin/crsctl stop has"
start_oracle_cmd="$GRID_HOME/bin/crsctl start has"

found=0
index=0

while [ 1 ]
do
	server=$(($index+1))
        echo "Give hostname/IP address of NTP server No.$server [Enter for none]:"
        read EXT_NTP

        if [ "x$EXT_NTP" = "x" ]
        then
		iparray[$index]=""
                index=$(($index+1))
        else
		check_RH_version
		if [ $? -ge 6 ]
        		then
		ntpdate -q $EXT_NTP | egrep -e "step time server" -e "adjust time server"
			else
			ntptrace $EXT_NTP | egrep "synch distance"
		fi
                
                if [ $? -eq 1 ]
                then
                        echo "$EXT_NTP  - ntp server not reachable"
	                iparray[$index]=""
                else
                        iparray[$index]="$EXT_NTP"
			found=$(($found+1))
                fi		
                index=$(($index+1))
        fi

	if [ $index -ge 4 ]
  		then
                break
	fi
done

awk -v var="$(echo ${iparray[*]})" 'BEGIN{split(var,list," ");counter=1}

                        list[counter]!="" && $1 ~ /server/ {print "server "  list[counter]
                        counter++
                        next
                        }{ print $0}' ${ntp_file} > ${ntp_file}.$$
mv ${ntp_file}.$$ ${ntp_file}

if [ $found -eq 0  ];then
echo "No valid NTP server found. Exiting... "
exit 0
fi

if [ $SERVER_TYPE = "NPO" ]
then
	if [ $OS_TYPE = "linux" ]
	then
		echo "Disable Oracle processes in PMON"
		echo "disable ora" > /alcatel/var/export/pub/MS/pmon/PMON_cmd.txt
		#wait (max 15min) for PMON to handle command file
		echo "$(date +"%Y-%m-%d %H:%M:%S") - Waiting for PMON to acknowledge \"disable ora\" command..."
		i=0
		while [ $i -lt 45 ] ; do
			i=$(($i+1))
			if [ -f /alcatel/var/export/pub/MS/pmon/PMON_cmd.txt ]; then
				echo "$i: Wait 20s"
				sleep 20
			else
				i=45
			fi
		done
		if [ -f /alcatel/var/export/pub/MS/pmon/PMON_cmd.txt ]; then
			echo "ERROR: Failed to disable Oracle process in PMON."
			echo "$(date +"%Y-%m-%d %H:%M:%S") - Exiting..."
			exit 1
		else
			echo "$(date +"%Y-%m-%d %H:%M:%S") - PMON acknowleged \"disable ora\" command"
		fi
	fi

	echo "Stopping Oracle using $stop_oracle_cmd"
	echo "Please wait..."
	$stop_oracle_cmd || exit 1
	echo ""
fi

service ntpd stop >/dev/null
sed -e "/^restrict.*noquery/s/^/#/" /etc/ntp.conf > /etc/ntp.conf.sed
mv /etc/ntp.conf.sed /etc/ntp.conf

index=0
while [ 1 ]
do
	value=${iparray[$index]}
        if [ "x$value" != "x" ]
        	then
		ntpdate -u $value

	fi
        if [ $index -ge 4 ]
        then
                break
        fi
        index=$(($index+1))
done

service ntpd start >/dev/null

#RCI: DCTPD01127611 - [WCDMA][M5.5][ifs] 'Post installation phase 1' failure: Core processes not started after configure NTP server (hour change)
/alcatel/MS/MS_PMON/scripts/pmon.sh stop
sleep 10
/alcatel/MS/MS_PMON/scripts/pmon.sh start
sleep 10

if [ $SERVER_TYPE = "NPO" ]
then
	echo ""
	echo "Starting Oracle using $start_oracle_cmd"
	echo "Please wait..."
	$start_oracle_cmd
	sleep 30

	if [ $OS_TYPE = "linux" ]
	then
		echo "Enable Oracle processes in PMON"
        	echo "enable ora" > /alcatel/var/export/pub/MS/pmon/PMON_cmd.txt
		#wait (max 15min) for PMON to handle command file
		echo "$(date +"%Y-%m-%d %H:%M:%S") - Waiting for PMON to acknowledge \"enable ora\" command..."
		i=0
		while [ $i -lt 45 ] ; do
			i=$(($i+1))
			if [ -f /alcatel/var/export/pub/MS/pmon/PMON_cmd.txt ]; then
				echo "$i: Wait 20s"
				sleep 20
			else
				i=45
			fi
		done
		if [ -f /alcatel/var/export/pub/MS/pmon/PMON_cmd.txt ]; then
			echo "ERROR: Failed to enable Oracle process in PMON."
		else
			echo "$(date +"%Y-%m-%d %H:%M:%S") - PMON acknowleged \"enable ora\" command"
		fi
	fi
fi
