#!/bin/sh

if [ -f /install/data/OMC_INSTALL_1 ]
then
	. /install/data/OMC_INSTALL_1
else
	. /install/data/OMC_INSTALL_2
fi

if [ x${IP_SERVER} = x${FLOATING_IP} ]
then
	echo " IP_SERVER and IP_FLOATING are the same"
	exit 0
fi

echo "FLOATING IP: $FLOATING_IP"
echo "CLUSTER NAME: $CLUSTER_NAME"

DIR="/alcatel/muse/MUSEADWEBSTART /alcatel/muse/MUSE_DIAGWEBSTART /alcatel/omc${OMC_INSTANCE} /opt/apache/htdocs/ /opt/apache-tomcat-5.5.20/webapps/ROOT/"
FILES=/tmp/files

echo "Directories to be updated: $DIR"

#################################################################
#Change floating IP in all impacted files
#################################################################
rm $FILES
echo "Finding all files that contain current IP:"
for dir in $DIR
do
	echo "Searching $dir..."
	find $dir  -type f \( ! -name "pkginfo" -a ! -name "*.trace*" -a ! -name "*.jar" -a ! -name "*.dbf" -a ! -name "*core" -a ! -name "*.log" \) -exec  egrep -l "${IP_SERVER}|${HOST_NAME}" {} \; >> $FILES
done

echo "Do noting in OMC_DBCF and traces!"
sed -e "/.*OMC_DBCF.*/d" -e "/.*\/traces\//d" < $FILES > $FILES.$$
sed -e "/\/alcatel\/omc${OMC_INSTANCE}\/MS_PMON\/config\/usm\/param.cfg/d" < $FILES.$$ > $FILES

set -x

sed "s#/alcatel/muse#/alcatel/temp/nfs/muse#" < /alcatel/muse/technologies/GSM/QoS/sql/CREATE_EXT_GSM_TABLE.sql > /alcatel/muse/technologies/GSM/QoS/sql/CREATE_EXT_GSM_TABLE.sql.$$
cp /alcatel/muse/technologies/GSM/QoS/sql/CREATE_EXT_GSM_TABLE.sql.$$ /alcatel/muse/technologies/GSM/QoS/sql/CREATE_EXT_GSM_TABLE.sql

sed "s#/alcatel/muse#/alcatel/temp/nfs/muse#" < /alcatel/muse/MUSE_QOS/offlinetool/scripts/sqlfiles/CREATE_EXT_MIPM_TABLE.sql > /alcatel/muse/MUSE_QOS/offlinetool/scripts/sqlfiles/CREATE_EXT_MIPM_TABLE.sql.$$
cp /alcatel/muse/MUSE_QOS/offlinetool/scripts/sqlfiles/CREATE_EXT_MIPM_TABLE.sql.$$ /alcatel/muse/MUSE_QOS/offlinetool/scripts/sqlfiles/CREATE_EXT_MIPM_TABLE.sql

sed "/_DIR/s#/alcatel/muse#/alcatel/temp/nfs/muse#" < /alcatel/muse/MUSE_QOS/loader/genericloader/GenericLoader.properties > /alcatel/muse/MUSE_QOS/loader/genericloader/GenericLoader.properties.$$
cp /alcatel/muse/MUSE_QOS/loader/genericloader/GenericLoader.properties.$$ /alcatel/muse/MUSE_QOS/loader/genericloader/GenericLoader.properties

sed "/OUTPUT_DIR_PATH/s#/alcatel/muse#/alcatel/temp/nfs/muse#" < /alcatel/muse/MUSE_QOS/config/Consolidation.properties > /alcatel/muse/MUSE_QOS/config/Consolidation.properties.$$
cp /alcatel/muse/MUSE_QOS/config/Consolidation.properties.$$ /alcatel/muse/MUSE_QOS/config/Consolidation.properties  


echo " Update /alcatel/muse/MUSE_COMMON/config/jacorb.properties "
sed "s/127.0.0.1/${FLOATING_IP}/" < /alcatel/muse/MUSE_COMMON/config/jacorb.properties > /alcatel/muse/MUSE_COMMON/config/jacorb.properties.$$
cp /alcatel/muse/MUSE_COMMON/config/jacorb.properties.$$ /alcatel/muse/MUSE_COMMON/config/jacorb.properties 

sed -e "s#/opt/crs/oracle/product/10.2.0/bin/olsnodes#/opt/app/oracle/crs/bin/olsnodes#" -e "s/ORACLE_HOST.*/ORACLE_HOST=${CLUSTER_NAME}/" < /alcatel/muse/MUSE_QOS/bin/getpid > /alcatel/muse/MUSE_QOS/bin/getpid.$$
cp /alcatel/muse/MUSE_QOS/bin/getpid.$$ /alcatel/muse/MUSE_QOS/bin/getpid

set +x

#-------------------------------------------------------------------------------
# USAGE         : substitute <file>
#-------------------------------------------------------------------------------
substitute()
{
    real_file=$1
    old_file=$1"_old"

	cp ${real_file} ${old_file}

    /bin/cat ${old_file} | /bin/sed -e "s/${IP_SERVER}/${FLOATING_IP}/g" -e "s/\<${HOST_NAME}\>/${CLUSTER_NAME}/g" -e "s/${HOST_NAME}_/${CLUSTER_NAME}_/g" > ${real_file}
	rm ${old_file}
    if [ $? -ne 0 ]; then
           echo "Substitution in file : ${real_file} failed ... Aborting"
           return ${_abort_installation}
    fi
} 

#for each file , apply the replace
for filename in `cat $FILES`
do
	wfile=${filename}
	echo "Substituting in $wfile"
	substitute $wfile	
done

#################################################################
# Remove SEC file server.ior
#################################################################
rm /alcatel/omc${OMC_INSTANCE}/OMC_ALMCF/sec/config/server.ior
#################################################################
# Update NPO DB table with new floating IP
#################################################################


exit 0
