#!/bin/bash

# Enable this line for debug porpose only!
#set -x

backup_csa_registry () {
        if [ -d $CSACF_BACKUP/csa_registry_backup ]; then
                ls -l $CSACF_BACKUP/csa_registry_backup/ | grep -v old | grep -v total | awk '{print $9}' >> /tmp/register_bkps
                while read line
                do
                        mv -f $CSACF_BACKUP/csa_registry_backup/$line $CSACF_BACKUP/csa_registry_backup/"$line""_old"
                done < /tmp/register_bkps

                rm -f /tmp/register_bkps
                if [ -f $NGSEC_DIR/bin/system/registry/exportRegistry.sh ]; then
                        logInfo "Performing CSA registry backup."
                        $NGSEC_DIR/bin/system/registry/exportRegistry.sh $CSACF_BACKUP/csa_registry_backup

                        checkErr $? "Failed to backup CSA registry!"
                else
                        logInfo "$NGSEC_DIR/bin/system/registry/exportRegistry.sh does not exists. CSA registry backup will not be performed."
                fi
        else
                logInfo "$CSACF_BACKUP/csa_registry_backup directory does not exist. CSA registry backup will not be performed."
        fi
}

logInfo () {
        INFO_MSG=$1
        echo "`date '+[%Y-%m-%d %H:%M:%S]'` - $INFO_MSG"
}

checkErr () {
    ERR_CODE=$1
    ERR_MSG=$2
    if [ $ERR_CODE -ne 0 ]; then
        logInfo "ERROR [INSTALL]: ${ERR_MSG}"
	umount ${MOUNT_DIR}
        exit $ERR_CODE
    fi
}

disable_current_repositories () {
    logInfo "Disabeling current active repositories ..."
    cd ${REPO_DIR}
    tar -cvf /alcatel/install/log/repos_$$.tar *
    rm *repo
}

restore_repos () {
    logInfo "Restoring yum repositories ..."
    cd ${REPO_DIR}
    tar -xvf /alcatel/install/log/repos_$$.tar
}

create_DVD1_repo() {
    echo -e "[upg_os]\nname=upg_os\nbaseurl=file://${MOUNT_DIR}\nenabled=1\ngpgcheck=0\npriority=1" > ${REPO_DIR}/upg_os.repo
}

#update/install rpms based on the content of given repository
update_rpm_from_repo () {
        REPO=$1
        logInfo "Get list of available rpms in $REPO repository"
        all_rpms=$(yum --disablerepo="*" --enablerepo=$REPO list available 2>/dev/null | awk '$3 ~ /'$REPO'/ {print $1}' )
        if [ "x${all_rpms}" = "x" ]; then
                logInfo "Got empty list. Retrying once."
                sleep 10
                all_rpms=$(yum --disablerepo="*" --enablerepo=$REPO list available 2>/dev/null | awk '$3 ~ /'$REPO'/ {print $1}' )
                if [ "x${all_rpms}" = "x" ]; then
                        logInfo "Available rpms list is empty!"
                else
                        logInfo "Got list of available rpms in $REPO repository:"
                        echo "+---------------------------------------------+"
                        echo "${all_rpms}"
                        echo "+---------------------------------------------+"
                fi
        else
                logInfo "Got list of available rpms in $REPO repository:"
                echo "+---------------------------------------------+"
                echo "${all_rpms}"
                echo "+---------------------------------------------+"
        fi
        logInfo "Updating rpms from $REPO repository."
        yum --disablerepo="*" --enablerepo=$REPO update -y -v
        checkErr $? "Failed to update rpms from $REPO repository!"
        logInfo "Successfully updated rpms from $REPO repository."
        yum clean all
        logInfo "Get list of all new rpms from $REPO repository to be installed."
        new_rpms_list=$(yum --disablerepo="*" --enablerepo=$REPO list available 2>/dev/null| awk '$3 ~ /'$REPO'/ {print $1}' )
        if [ "x${new_rpms_list}" = "x" ]; then
                # empty list => try again
                logInfo "Got empty list. Retrying once."
                sleep 10
                new_rpms_list=$(yum --disablerepo="*" --enablerepo=$REPO list available 2>/dev/null | awk '$3 ~ /'$REPO'/ {print $1}' )
                if [ "x${new_rpms_list}" = "x" ]; then
                        logInfo "No new rpms to be installed from $REPO repository."
                        return
                fi
        fi

        logInfo "New rpm list found in $REPO repository:"
        echo "+---------------------------------------------+"
        echo "${new_rpms_list}"
        echo "+---------------------------------------------+"
        logInfo "Installing all new rpms found in $REPO repository."
        yum install $new_rpms_list -y -v
        checkErr $? "Failed to install new rpms from $REPO repository!"
        logInfo "Successfully installed new rpms from $REPO repository."
	#RCA: in case of systemd update, /etc/sysconfig/clock is deleted, so we will recreate it
	logInfo "Restarting clock service ..."
	/bin/systemctl restart clock
}

###### Main part of the OS rpm upgrade ###############
MOUNT_DIR=$1/DVD1L
DVD1LISO=$2
REPO_DIR=/etc/yum.repos.d
OLD_OMC_HOME=/alcatel/MS
PMON_SCRIPT=$OLD_OMC_HOME/MS_PMON/scripts/pmon.sh
CSACF_BACKUP=$OLD_OMC_HOME/OMC_CSACF/data/backup
NGSEC_DIR=/alcatel/csa/ngsec/NGSEC
FULL_INSTALL_DIR=/alcatel/FULL_INSTALL_CSA
VENDOR=$(dmidecode -s system-manufacturer)

rh_version=`lsb_release -r | awk '{print \$2}' | awk -F'.' '{print \$1}'`

if [[ ${rh_version} -lt 7 ]]; then
    logInfo "Installed Red Hat version is older than 7.x. Skip OS update from DVD1!"
    exit 1
fi

DVD1LISO=`ls -l ${DVD1LISO}* | tail -1 | awk '{print $9}'`

mkdir -p ${MOUNT_DIR}
# ensure that the mount location is not used
umount ${MOUNT_DIR} > /dev/null 2>&1
mount -o loop,ro ${DVD1LISO} ${MOUNT_DIR} > /dev/null 2>&1

if [[ `ls -l ${MOUNT_DIR} | wc -l` -eq 0 ]]; then
    logInfo "DVD1 is not mounted. Skip OS update from DVD1!"
    exit 1
fi

echo "    ====  Start OS packages update  ===="

yum clean all

disable_current_repositories
create_DVD1_repo

logInfo "Checking enabled repositorries:"
enabled_repos=$(yum repolist 2> /dev/null | awk '$3 ~ /enabled/ {print $1}')
if [ "x$enabled_repos" != "x" ]; then
        echo "Got list of enabled repositories:"
        echo "+---------------------------------------------+"
        echo "$enabled_repos"
        echo "+---------------------------------------------+"
fi

logInfo "Update/Install rpms from DVD1 repository:"
#chattr -i /boot/grub/grub.conf
#RCA: missing dependency fix:
#for tracker 163390,remove the hardcode for xcb-util-wm
for p in apr apr-util;do
        rpm -q $p >/dev/null
        if [ $? -ne 0 ];then
                        yum --disablerepo="*" --enablerepo=upg_os install $p -y
        fi
done

logInfo "Verifying if openssl or openldap will be updated ..."
installed_csa=`rpm -q CSA`
yum --disablerepo="*" --enablerepo=upg_os list available 2>/dev/null |grep -e "openssl" -e "openldap" >/dev/null
if [ $? -eq 0 ] && [ ! -z $installed_csa ];then
        REMOVE_CSA=yes
fi

# if more packages will be removed
if [ "$REMOVE_CSA" == "yes" ]; then
        #openssl/openldap to be updated, but CSA no, forcibily reinstall CSA in order to get openssl/openldap installed
        echo "CSA will be reinstalled to have openssl/openldap successfully installed ..."
        backup_csa_registry
        sleep 2
        if [ -f ${PMON_SCRIPT} ]; then
                logInfo "Stopping PMON."
                ${PMON_SCRIPT} stop
        else
                echo "Warning: ${PMON_SCRIPT} not found."
        fi
        sleep 2
        if [ -f $OLD_OMC_HOME/OMC_CSACF/scriptscsa21/logs.sh ]; then
            # fix the error of cannot compress log
            cd $OLD_OMC_HOME/OMC_CSACF/scriptscsa21 
            cp logs.sh logs.sh_npo84D14_`date +%Y%m%d`
            sed -i '35s/^/  echo "su root root" >> $TEMP_FILE\n/' logs.sh 
            logInfo "Saving CSA logs."
            $OLD_OMC_HOME/OMC_CSACF/scriptscsa21/logs.sh
            fi
            if [ -f ${FULL_INSTALL_DIR}/uninstall_csa.sh ]; then
                cwd=`pwd`
		# fix the error of cannot ls /alcatel/csa/ngsec/server: No such file or directory
		if [ -f ${FULL_INSTALL_DIR}/NGSEC/srcinstall/csa-uninstaller.properties ]; then
                    cd ${FULL_INSTALL_DIR}/NGSEC/srcinstall
                    cp csa-uninstaller.properties csa-uninstaller.properties_npo84D14_`date +%Y%m%d`
	            sed -i '6a JBOSS_PATH=/alcatel/csa/ngsec/jboss' csa-uninstaller.properties
                    sed -i '6d' csa-uninstaller.properties	
		fi
                logInfo "Running csa uninstallation script: ${FULL_INSTALL_DIR}/uninstall_csa.sh"
                cd ${FULL_INSTALL_DIR}
                echo "y" | ${FULL_INSTALL_DIR}/uninstall_csa.sh
                checkErr $? "Failed to uninstall CSA!"
                cd $cwd
            fi
fi

yum clean all

update_rpm_from_repo upg_os
chattr +i /boot/grub/grub.conf

yum clean all

if [[ "$REMOVE_CSA" == "yes" ]]; then
    cwd=`pwd`
    if [ -d $FULL_INSTALL_DIR ]; then
        echo "Running CSA configuration script: ${FULL_INSTALL_DIR}/step_1_install_csa.sh"
        cd $FULL_INSTALL_DIR
        ldconfig -v 2> /dev/null|grep sasl
        ${FULL_INSTALL_DIR}/step_1_install_csa.sh
        checkErr $? "Failed to install/configure CSA!"
        logInfo "Running WEBSSO configuration script: ${FULL_INSTALL_DIR}/step_2_install_websso.sh"
        cd $FULL_INSTALL_DIR
        ${FULL_INSTALL_DIR}/step_2_install_websso.sh
        checkErr $? "Failed to install/configure WEBSSO!"
    else
        checkErr 1 "$FULL_INSTALL_DIR is missing! CSA installation failed!"
    fi
    cd $cwd
    if [ -f ${PMON_SCRIPT} ]; then
        logInfo "Starting PMON."
        ${PMON_SCRIPT} start
    fi
    sleep 3
fi
chattr +i /boot/grub/grub.conf

rm ${REPO_DIR}/*repo

restore_repos

umount ${MOUNT_DIR}
