#!/bin/sh
ntp_file=/etc/inet/ntp.conf
CLUSTER_CONF=/install/data/cluster.conf
stop_oracle_cmd="../oracle/cluster_processes.sh stop"
start_oracle_cmd="../oracle/cluster_processes.sh start"
CRS_HOME=/opt/app/grid/11.2.0.3
stop_crs_cmd="$CRS_HOME/bin/crsctl stop crs"
start_crs_cmd="$CRS_HOME/bin/crsctl start crs"

if [ -f ${CLUSTER_CONF} ]
then
        . ${CLUSTER_CONF}
else
        echo "ERROR ${CLUSTER_CONF} file not found!."
        exit 1
fi

CLUSTER_NAME=`awk '$1 ~ /^'"${FLOATING_IP}"'$/ {print $2}' /etc/hosts`

CLUSTER_NAME=`echo $CLUSTER_NAME | sed "s/-scan$//"`

while [ 1 ]
do
	echo "Give hostname/IP address of NTP server (Enter for none):"
	read EXT_NTP
	if [ "x$EXT_NTP" = "x" ]
	then
		break
	else
		ntptrace -t 2 $EXT_NTP | grep -v  127.127.1.1 | egrep "synch distance"
                if [ $? -eq 1 ]
                then
                        echo "ERROR: $EXT_NTP  - ntptrace timeout"
                        exit 1
                else
			echo "Stopping Oracle using $stop_oracle_cmd"
                	$stop_oracle_cmd || exit 1
			sleep 20
			echo "Stopping CRS using $stop_crs_cmd"	
			$stop_crs_cmd || exit 1
			sleep 20
                        break
                fi
	fi
done

case ${INSTANCE_NUMBER} in
        1)      NTP_SERVER=${CLUSTER_NAME}2
                ;;
        2)      NTP_SERVER=${CLUSTER_NAME}1
                ;;
        *)      echo "ERROR: INSTANCE_NUMBER=${INSTANCE_NUMBER} ; must be 1 or 2!"
                exit 1
                ;;
esac

SERVER=${NTP_SERVER}

cat <<- ! > ${ntp_file}
peer ${NTP_SERVER}
server 127.127.1.1             # undisciplined local clock
fudge 127.127.1.1 stratum 10
driftfile /etc/inet/ntp.drift
slewalways yes
disable pll
!

if [ "x$EXT_NTP" != "x" ]
then
sed -e '1i\
server '"$EXT_NTP"'
' ${ntp_file} > ${ntp_file}.$$
mv ${ntp_file}.$$ ${ntp_file}
SERVER=${EXT_NTP}
fi

svcadm disable ntp
ntpdate -u ${SERVER}
svcadm enable ntp

if [ "x$EXT_NTP" != "x" ]
then
	echo "Starting CRS using $start_crs_cmd"
	$start_crs_cmd || exit 1
	sleep 200

	echo "Starting Oracle using $start_oracle_cmd"
	$start_oracle_cmd || exit 1
	sleep 20
fi
