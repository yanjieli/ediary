#!/bin/bash
#set -x

NEW_LICENSE_SOURCE=/alcatel/var/home/axadmin
LICENSE_LOCATION_1=/install/data
LICENSE_LOCATION_2=/opt/apache/htdocs/omc/wibox/config
SETLICENSE_LOCATION=/alcatel/muse/MUSE_ADMIN/bin
DIM_DEST=/alcatel/MS/MUSE_DIM
LOG="activate_new_license_`date '+%d_%m_%y__%H-%M-%S'`.log"
LOGFILE=/alcatel/install/log/$LOG
SET_LICENSE_TRACE_DEST=/alcatel/temp/data/trace

echo "Verify if new license exists in /alcatel/var/home/axadmin" | tee -a $LOGFILE
if [ ! -f $NEW_LICENSE_SOURCE/license.xml ]
	then
        echo "New license cannot be found in $NEW_LICENSE_SOURCE"
	exit 1	
fi

#Confirmation for new license installation
echo "A License File is already installed. Do you want to over-write with new one(y/n)?"
echo "Type y or n and press Enter"
read answer

while [[ "$answer" != "y" && "$answer" != "n" ]]
	do 
	echo "Type again y or n"
	read answer 
done

if [ "$answer" = "y" ]
	then
	echo "Backup the old license" | tee -a $LOGFILE
	cp $LICENSE_LOCATION_1/license.xml $LICENSE_LOCATION_1/license.xml.bak

	echo "Copy the new license in all required directories" | tee -a $LOGFILE
	cp $NEW_LICENSE_SOURCE/license.xml $LICENSE_LOCATION_1/
	cp $NEW_LICENSE_SOURCE/license.xml $LICENSE_LOCATION_2/
	chmod +r $LICENSE_LOCATION_2/license.xml	

	echo "Activate new license" | tee -a $LOGFILE
	yes | $SETLICENSE_LOCATION/setLicense.sh $LICENSE_LOCATION_1/license.xml | tee -a $LOGFILE

	echo "Configure PMON" | tee -a $LOGFILE
	$DIM_DEST/MUSEdim_mon.sh 9959-MS-NPO | tee -a $LOGFILE

	echo "Check errors in $SET_LICENSE_TRACE_DEST/MUSE_LICENSE*_0.traces" | tee -a $LOGFILE 
	TRACE_BEGINING=`grep -n "TRACE BEGINNING" /alcatel/temp/data/trace/MUSE_LICENSE*_0.traces | tail -1 | cut -f1 -d:`
	ERROR_COUNT=`awk '$0 ~ /ERROR|error|Error/ {if( NR > '"$TRACE_BEGINING"') {print $0}}' /alcatel/temp/data/trace/MUSE_LICENSE*_0.traces`
	awk '$0 ~ /ERROR|error|Error/ {if( NR > '"$TRACE_BEGINING"') {print $0}}' /alcatel/temp/data/trace/MUSE_LICENSE*_0.traces | tee -a $LOGFILE
	if [ "$ERROR_COUNT" != "" ]
		then
		echo "For the related above errors refer to NPO Troubleshooting Guide" | tee -a $LOGFILE
		else
		echo "No errors found" | tee -a $LOGFILE
	fi

else
echo "No license will be updated"
exit 1
fi
