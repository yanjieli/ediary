#!/bin/ksh
#set -x

# Script to enable / disable IPV6 support on RedHat
# V1.0 MA55D45

OS=`uname`
ME=$(basename $0)
LOGFILE=/alcatel/install/log/set_ipv6_`date '+%Y%m%d_%H%M%S'`.log
ARGS=$#
LOCKFILE="/tmp/$(basename $0).lock"

checks()
{

	usage()
	{
        	echo ""
        	echo "USAGE: $ME enable" >&2
		echo "USAGE: $ME disable" >&2
        	echo ""
        	exit 1
	}

	#User check
	[ "$(id | awk -F\( '{print $2}' | awk -F\) '{print $1}')" = root ] || {
        	echo "ERROR: You must be logged in as root to run $ME" >&2
        	echo "       Log in as root and restart $ME execution." >&2
        	exit 1
	}

	#Process arguments check
	if [ $ARGS != 1 ]; then
		usage
		exit
	fi

	#OS check
	if [ ${OS} -ne "Linux" ]; then
		echo "$ME must be run on Linux systems only"
		exit 1
	fi

}

check_RH_version () 
{
	rh_version=`lsb_release -r | awk '{print \$2}'`
	rh_minor_ver=`echo $rh_version | awk -F. '{print $1}'`
	if [ ${rh_minor_ver} -ge 6 ]; then
		conf_file=/etc/modprobe.d/blacklist_ipv6.conf
		if [ ! -f ${conf_file} ]; then
                        ln -s /etc/modprobe.d/blacklist /etc/modprobe.d/blacklist_ipv6.conf 
                fi

	else
		conf_file=/etc/modprobe.d/blacklist	
	fi
}

ipv6_start()
{
	echo "`date '+%Y%m%d_%H%M%S'`"
        for f in $(ls /etc/modprobe.d/*preCIS 2>/dev/null);do
        	echo "Saving file $f under /alcatel/install/log ..."
        	mv $f /alcatel/install/log/
        done

	/sbin/lsmod | grep ipv6
	res=$?

	cat ${conf_file} | grep "^install ipv6 /bin/true$"
	res1=$?

	if [ $res != 0 ] || [ $res1 = 0 ]; then
        	echo "Enabling IPV6 support"
        	if [ $res1 = 0 ];then
                	echo "Commenting IPV6 in ${conf_file}"
                	sed -e 's/^install ipv6 \/bin\/true$/#install ipv6 \/bin\/true/g' < ${conf_file} > /tmp/blacklist.temp
                	mv /tmp/blacklist.temp ${conf_file}
        	else
                	echo "Uncommented IPV6 string not found in ${conf_file}"
        	fi
        	echo "Running modprobe for IPV6 modules"
        	/sbin/modprobe ipv6
	else
        	echo "IPV6 support is already enabled"
        	echo "No changes were made by $ME"
        	exit 0
	fi
}

create_lock () {

        echo $$ > ${LOCKFILE}
}

ipv6_stop()
{
	echo "`date '+%Y%m%d_%H%M%S'`"

	/sbin/lsmod | grep ipv6
	res=$?

	cat ${conf_file} | grep "^#install ipv6 /bin/true$"
	res1=$?

	if [ $res != 0 ] && [ $res1 != 0 ]; then
        	echo "IPV6 support is already disabled"
        	echo "No changes were made by $ME"
        	exit 0
	else
        	echo "Disabling IPV6 support"
        	if [ $res1 = 0 ];then
                	echo "Uncommenting IPV6 in ${conf_file}"
                	sed -e 's/^#install ipv6 \/bin\/true$/install ipv6 \/bin\/true/g' < ${conf_file} > /tmp/blacklist.temp
                	mv /tmp/blacklist.temp ${conf_file}
        	else
                	echo "Commented IPV6 string not found in ${conf_file}"
        	fi
        	echo "Rebooting the server"
		create_lock
		sleep 2
        	/sbin/shutdown -r now
	fi
}

#-------------------------------Main-------------------------------
(
	checks
	check_RH_version
	case "$1" in
        	enable) ipv6_start ;;
        	disable)  ipv6_stop ;;
        	*) usage ;;
	esac


) 2>&1 | /usr/bin/tee -a $LOGFILE
