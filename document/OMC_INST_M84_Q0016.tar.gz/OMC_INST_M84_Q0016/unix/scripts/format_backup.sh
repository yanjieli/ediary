#!/bin/bash
set -x

format_backup(){

	file=/etc/fstab
	alc_bkp_md=`df -h | grep /alcatel/backup | awk  '{print $1}' | grep "md" | wc -l`
	alc_bkp_sd=`df -h | grep /alcatel/backup | awk  '{print $1}' | grep "sd" | wc -l`
	alc_bkp_mapper=`df -h | grep /alcatel/backup | awk  '{print $1}' | grep "mapper" | wc -l`


	if [ ${alc_bkp_sd} -eq 1 ] || [ ${alc_bkp_mapper} -eq 1 ]; then
		bkp_part=`df -h | grep /alcatel/backup | awk  '{print $1}'`
		if [ ${alc_bkp_sd} -eq 1 ]
		then
			drive=`echo $bkp_part | sed 's/[0-9]*//g'`
		fi
		if [ ${alc_bkp_mapper} -eq 1 ]
		then
			drive=`echo $bkp_part | sed 's/p1$//g'`
		fi
	
		part_nr=`echo $bkp_part | sed 's/[^0-9]*//g'`
		size=`parted $drive print | tail -n2 | head -n1 | awk '{print $4}'`
	
		umount /alcatel/backup
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully unmounted /alcatel/backup "
		else
			echo "WARNING failed to unmount /alcatel/backup "
			fuser -k /alcatel/backup
			umount /alcatel/backup
			status=$?
				if [ ${status} -eq 0 ]
				then
					echo "Successfully unmounted /alcatel/backup "
				else
					echo "ERROR failed to unmount /alcatel/backup "
					exit ${status}
				fi
		fi

		parted $drive rm $part_nr
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully deleted $bkp_part partition "
		else
			echo "WARNING exit status of command : parted $drive rm $part_nr is $status "
		fi
	
		if [ ${alc_bkp_sd} -eq 1 ]
		then 
			parted -s -a optimal $drive mkpart primary ext4 0 $size
			status=$?
			if [ ${status} -eq 0 ]
			then
				echo "Successfully created $bkp_part partition "
			else
				echo "WARNING exit status of command : parted $drive mkpart primary ext4 1 $sizei is $status"
			fi
		fi

		if [ ${alc_bkp_mapper} -eq 1 ]
		then
			parted -s -a optimal $drive mkpart ext4 0 $size
			status=$?
			if [ ${status} -eq 0 ]
			then
				echo "Successfully created $bkp_part partition "
			else
				echo "WARNING exit status of command : parted $drive mkpart primary ext4 1 $sizei is $status"
			fi
		fi

	
		mkfs -t ext4 $bkp_part
		status=$?
		if [ ${status} -eq 0 ]
		then
                        echo "Successfully formatted $bkp_part partition "
                else
                        echo "ERROR failed to format $bkp_part partition "
                        exit ${status}
                fi
	
		mount $bkp_part /alcatel/backup
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully mounted /alcatel/backup. The partition is ready for use!"
		else
			echo "ERROR failed to mount /alcatel/backup "
			exit ${status}
		fi

	#edit fstab
	uuid_drive=`df -h | grep /alcatel/backup | awk  '{print $1}'`
	new_uuid=`tune2fs -l $uuid_drive| awk '/Filesystem UUID/{print $NF}'`
	sed -i "s,UUID=.*/alcatel/backup.*,UUID=$new_uuid /alcatel/backup\text4\tdefaults\t 1 2,g" $file
	status=$?
	if [ ${status} -eq 0 ]
	then
		echo "Successfully edited fstab with /alcatel/backup ext4 filesystem"
	else
		echo "ERROR failed to edit fstab "
		exit ${status}
	fi

	elif [ ${alc_bkp_md} -eq 1 ]; then
		bkp_md=`df -h | grep /alcatel/backup | awk  '{print $1}'`
		mdadm --detail $bkp_md | sed -n -e '/Number/,$p'| sed 1d | awk '{print $7}' > /tmp/mdstat.txt
		mirror_dev=`sed ':a;N;$!ba;s/\n/ /g' /tmp/mdstat.txt`

		umount /alcatel/backup
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully unmounted /alcatel/backup "
		else
			echo "WARNING failed to unmount /alcatel/backup "
			fuser -k /alcatel/backup
			umount /alcatel/backup
			status=$?
			if [ ${status} -eq 0 ]
			then
				echo "Successfully unmounted /alcatel/backup "
			else
				echo "ERROR failed to unmount /alcatel/backup "
				exit ${status}
			fi
		fi

		mdadm --stop $bkp_md
		if [ ${status} -eq 0 ]
		then
			echo "Successfully stopped $bkp_md"
		else
			echo "ERROR: failed to stop $bkp_md"         
			exit ${status}
		fi
		ls -lah $bkp_md
		status=$?
		if [ ${status} -eq 0 ]
		then
			mdadm --remove $bkp_md
			status=$?
			if [ ${status} -eq 0 ]
			then
				echo "Successfully removed $bkp_md"
			else
				echo "ERROR: failed to remove $bkp_md"
				exit ${status}
			fi
		fi
		
		mdadm --zero-superblock $mirror_dev
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully filled with zeros the superblocks for all partitions "
		else
			echo "ERROR failed to fill with zeros the superblocks for all partitions "
			exit ${status}
		fi

		while read line
		do
			bkp_part=$line
			drive=`echo $bkp_part | sed 's/[0-9]*//g'`
			part_nr=`echo $bkp_part | sed 's/[^0-9]*//g'`
			size=`parted $drive print | grep primary | awk '{print $4}' | awk "NR==$part_nr, NR==$part_nr"`

			parted $drive rm $part_nr
			status=$?
			if [ ${status} -eq 0 ]
			then
				echo "Successfully deleted $bkp_part partition "
			else
				echo "WARNING exit status of command : parted $drive rm $part_nr is $status "
			fi

			parted -s -a optimal $drive mkpart primary ext4 0 $size
			status=$?
			if [ ${status} -eq 0 ]
			then
				echo "Successfully created $bkp_part partition "
			else
				echo "WARNING exit status of command : parted -s -a optimal $drive mkpart primary ext4 0 $size is $status"
			fi

			mkfs -t ext4 $bkp_part
			status=$?
			if [ ${status} -eq 0 ]
			then
				echo "Successfully formatted $bkp_part partition "
			else
				echo "ERROR failed to format $bkp_part partition "
				exit ${status}
			fi

		done</tmp/mdstat.txt
	
		dev_nr=`cat /tmp/mdstat.txt | wc -l`
		yes|mdadm --create $bkp_md --chunk=512K --metadata=1.1 --level=0 --raid-devices=$dev_nr $mirror_dev
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully assembled $bkp_md "
		else
			echo "ERROR failed to assemble $bkp_md"
			exit ${status}
		fi

		mkfs -t ext4 $bkp_md
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully formatted $bkp_md partition "
		else
			echo "ERROR failed to format $bkp_md partition "
			exit ${status}
		fi

		mount $bkp_md /alcatel/backup
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully mounted /alcatel/backup. The partition is ready for use!"
		else
			echo "ERROR failed to mount /alcatel/backup "
			exit ${status}
		fi

		mdadm -Es > /etc/mdadm.conf
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully edited /etc/mdadm.conf"
		else
			echo "ERROR failed to edit /etc/mdadm.conf"
			exit ${status}
		fi

		#edit fstab
		uuid_drive=`df -h | grep backup | awk  '{print $1}'`
		new_md_uuid=`tune2fs -l $uuid_drive | awk '/Filesystem UUID/{print $NF}'`
		sed -i "s,UUID=.*/alcatel/backup.*,UUID=$new_md_uuid /alcatel/backup\text4\tdefaults\t 1 2,g" $file
		status=$?
		if [ ${status} -eq 0 ]
		then
			echo "Successfully edited fstab with /alcatel/backup ext4 filesystem"
		else
			echo "ERROR failed to edit fstab "
			exit ${status}
		fi
	fi
}

#-------------------------------MAIN---------------------------------------

	BACKUP_FILE=/root/DVD1L_install/backup_part

	if [ -f $BACKUP_FILE ]
	then
		. $BACKUP_FILE
	else
		echo "ERROR: $BACKUP_FILE file not present "
		exit 1
	fi

	OS_TYPE=`uname`
	if [ ${OS_TYPE} = "Linux" ]
	then
		rh_ver=`lsb_release -r | awk '{print $2}' | awk -F. '{print $1}'`
		if [ ${rh_ver} -gt 5 ]
		then
			tty -s && {
		        echo "This script will erase all content from /alcatel/backup partition and format it with ext4 filesystem"
			echo "Do you want to continue? (y/n)"

			read answer
        	
			case $answer in
			Y|y|Yes|yes|YES)    ;;
			*)                  exit;;
			esac
			}

			format_backup
			rm -rf /tmp/mdstat.txt
		else
		        echo "ERROR: This script is intended for use with RedHat Enterprise Linux 6 or higher version. This version is not supported!!!"
		fi
	else
		echo "ERROR: This script is intended for use with RedHat Enterprise Linux 6 or higher version. $OS_TYPE is not supported !!"
	fi
