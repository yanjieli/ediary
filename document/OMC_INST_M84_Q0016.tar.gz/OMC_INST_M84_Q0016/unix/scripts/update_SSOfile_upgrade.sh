#!/bin/sh
#set -x

logfile=`ls -asltr /alcatel/install/log/ | grep server_instal | tail -1 | awk -F" " '{print $10}'`

dir_htdocs="/opt/apache/htdocs"
if [ -f ${dir_htdocs}/active_spare.cfg ]; then
        rm ${dir_htdocs}/active_spare.cfg
fi

if [ -f ${dir_htdocs}/active_*.cfg ]; then
        nfile=`ls ${dir_htdocs} | grep active.*.cfg`
fi
if [ -f ${dir_htdocs}/spare_*.cfg ]; then
        nfile=`ls ${dir_htdocs} | grep spare.*.cfg`
fi

if [ -f ${dir_htdocs}/${nfile} ]; then
        file=/opt/apache/csa-agent/CacheManager/SSOAgent.properties
        if [ -f $file ]; then
                echo "Check if $nfile is in $file"
                grep "$nfile" $file >/dev/null 2>&1
                check_file=$?
                if [ $check_file -ne 0 ]; then
                        echo "Updating $file for active/spare configuration" | tee -a $logfile
                        sed -e "s:^\(com.alu.cnm.csa.ssoagent.enforcedURLs=.*\)$:\1 \/${nfile}:" ${file} > ${file}.$$
                        mv ${file}.$$ ${file}
			chmod 644 ${file}
			sleep 5
                fi
        fi
fi
