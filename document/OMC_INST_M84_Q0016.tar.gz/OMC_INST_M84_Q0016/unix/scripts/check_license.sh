#!/bin/ksh
#set -x
PLATFORM_HOSTID=`hostid`
LICENSE_FILE="/install/data/license.xml"
PROFILE="/var/tmp/server.profile"
VENDOR=$(dmidecode -s system-product-name)



basic(){
if [[ -f $LICENSE_FILE ]]
then
	print " License file is $LICENSE_FILE"
	/usr/bin/dos2unix $LICENSE_FILE $LICENSE_FILE
else
	print " ERROR [License]: License file not present in directory /install/data" >&2
	exit 1
fi

print " Checking license version in $LICENSE_FILE..."
ver=`cat ${PROFILE} | grep CD3S_ | awk '{ print $2 }' | awk -F_ '{print $3}' | awk -F"A" '{print $2}' | awk -F"D" '{print $1}' | sed 's/^\(.\{1\}\)/\1./'`
grep "MUSE_version>$ver<" $LICENSE_FILE  >/dev/null

if [ $? -ne 0 ]
then
        print " ERROR [License]: Invalid license file, it must have version $ver" >&2
        return 1
fi

print " License file contains version : $ver"

print " Checking license hostid in $LICENSE_FILE..."
grep "hostid>$PLATFORM_HOSTID<" $LICENSE_FILE  >/dev/null

if [ $? -ne 0 ]
then
        hostidstar=`grep "hostid>\*<" $LICENSE_FILE`
        expdate=$(awk '/ExpiryDate/{split($2,a,"\"");split(a[2],b,"/");c=b[2]"/"b[1]"/"b[3];print c;exit}' ${LICENSE_FILE})
        echo " Expiry date: ${expdate} "
        dt=`date +%m/%d/%Y`
        print "Current date: $dt"
        expdate_tmp=$(date -d "${expdate}" "+%s")
        dt_tmp=$(date -d "${dt}" "+%s")
        if [ ! -z $hostidstar  ]; then
                if [ ${expdate_tmp} -gt ${dt_tmp} ]; then
                        print "License file contains hostid * and EXPIRY_DATE is greater than current date"
                else
                         print "ERROR [ License ] EXPIRY_DATE is not greater than current date"
                         return 1
                fi
        else
                print " ERROR [License]: Invalid license file, it must contain hostid $PLATFORM_HOSTID or *" >&2
                return 1
        fi
else
        print " License file contains hostid : $PLATFORM_HOSTID"
fi
echo " Verifying machine type environment in license file ... "

echo $VENDOR|egrep -i "kvm|vmware|openstack" >/dev/null
if [ $? -eq 0 ];then VM=yes;else VM=no;fi

grep "Feature"  $LICENSE_FILE|grep VIRTUALIZED_ENVIRONMENT >/dev/null
if [ $? -eq 0 ];then LICENSE_VM=yes;else LICENSE_VM=no;fi

if [ "$VM" = "$LICENSE_VM" ];then
	echo " Machine type environment passed.(virtualized environment: $VM)"
else
	echo " Machine type environment failed:"
	echo " Hardware found: $VENDOR; license virtualized environment: $LICENSE_VM"
	return 1
fi



}

advanced () {

JAVA_LOCATION=/usr/jdk/bin/java
if [ ! -f ${JAVA_LOCATION} ]; then
   echo "ERROR [INSTALL]: Java not installed"
   return 1

else
 LIC_STRCT_VAL=$OMC_UNIX_INSTALL_DIR/lib
 #license structure validator jar
 XML_STRUCT_VAL_JAR="${LIC_STRCT_VAL}/license-structure-validator.jar"
 CLASSPATH="$CLASSPATH:${XML_STRUCT_VAL_JAR}"
 export CLASSPATH

 echo "Running $JAVA_LOCATION LicenseStructureValidator $licensefile"
 string=`$JAVA_LOCATION -jar $XML_STRUCT_VAL_JAR $LICENSE_FILE`
 status=`echo $string | grep -i "Invalid" | wc -l`

 if [ $status -ne 0 ]; then
	echo "ERROR [License]: Invalid structure for license file!" 
	return 1
 else
	echo "Valid structure for license file!"
	return 0
 fi
fi
}

n=$1
case $n in
    BASIC) basic ;;
    ADVANCED) advanced;;
    *) echo "invalid license check option";return 1;;
esac

