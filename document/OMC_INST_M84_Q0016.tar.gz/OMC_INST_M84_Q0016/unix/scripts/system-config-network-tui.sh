#!/bin/sh
#############################
##Change IP of the server  ##
##Date: 21.04.2017         ##
##Author: Bront Paul-Virgil##
#############################
#set -x
interface=$1
OLD_IPADDR=$(ifconfig $interface |awk '{for(i=1;i<NF;i++){if($i=="inet"){print $(i+1);exit}}}')
OLD_NETMASK=$(ifconfig $interface |awk '{for(i=1;i<NF;i++){if($i=="netmask"){print $(i+1);exit}}}')
file=/etc/sysconfig/network-scripts/ifcfg-$interface
tmpFile=/tmp/ifcfg-${interface}.tmp
tmpFile2=/etc/ssh/sshd_config
NETWORK_INFO=/tmp/network-info.$$

get_oam_params ()

{
# open fd
exec 3>&1
# Store data to variables
VALUES=$(dialog  --ok-label "Submit" \
        --backtitle "Linux Network Management" \
        --title "Change IP" \
        --form "Please define the networks below for OAM interface of $HOSTNAME:" \
        0 0 0 \
        "IP address: $OLD_IPADDR"               1 1     ""          1 30 15 0 \
        "Netmask:    $OLD_NETMASK"              2 1     ""          2 30 15 0 \
        "Gateway:    $OLD_GATEWAY"              3 1     ""          3 30 15 0 \
2>&1 1>&3)
echo $? >/tmp/ip_exit_code.$$
#close fd
exec 3>&-
br_exit=`cat /tmp/ip_exit_code.$$`
echo $VALUES>$NETWORK_INFO
		OAM_IPADDR=`awk '{print $1}' $NETWORK_INFO`
                OAM_NETMASK=`awk '{print $2}' $NETWORK_INFO`
                OAM_GATEWAY=`awk '{print $3}' $NETWORK_INFO`

rm -rf $NETWORK_INFO

}
check_var () 
{
if [ $br_exit -ne 0 ];then
                        exit 1
                else
			while [ ! "$OAM_IPADDR" -o ! "$OAM_NETMASK" -o ! "$OAM_GATEWAY" ];do
                                if [ $br_exit -ne 0 ];then
					exit 1
				else
				dialog --title "Missing info - OAM network interface" --msgbox "One or all of the following IP/NETMASK/GATEWAY are not set for eth0  \n\nPress OK to continue" 0 0
                                get_oam_params
				fi 
                       done

                        sed -i "/^IPADDR=/d" $tmpFile
                        sed -i "/^GATEWAY=/d" $tmpFile
                        sed -i "/^NETMASK=/d" $tmpFile
                        sed -i "$ a IPADDR=\"$OAM_IPADDR\"" $tmpFile
                        sed -i "$ a NETMASK=\"$OAM_NETMASK\"" $tmpFile
			sed -i "$ a GATEWAY=\"$OAM_GATEWAY\"" $tmpFile

			mac_address=$(ifconfig eth0 | grep -w "inet6" | awk '{n=split($2,a,".");print a[n]}')
			sed -i "/^ListenAddress=/d" $tmpFile2
			sed -i "$ a ListenAddress \"$mac_address\"" $tmpFile2
                        sed -i "$ a ListenAddress \"$OAM_IPADDR\"" $tmpFile2
                        sed -i "$ a ListenAddress ::1" $tmpFile2
                        sed -i "$ a ListenAddress 127.0.0.1" $tmpFile2

                        /bin/cp -pf /tmp/ifcfg-${interface}.tmp        $file
			systemctl restart network.service
                        systemctl restart sshd

fi

}

if [ ! "$interface" ]; then
echo "Basic usage: ./network.sh \$interface "
else
 /bin/cp -pf $file /tmp/ifcfg-${interface}.tmp
 OLD_GATEWAY=`cat /etc/sysconfig/network-scripts/ifcfg-$interface |grep -i GATEWAY | grep -o '[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}'`
 get_oam_params
 check_var
fi
