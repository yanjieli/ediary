#!/bin/ksh
#script used temporary for /alcatel/temp/nfs share/mount
#set -x

#check if /alcatel/temp is mounted, else exit script
check_temp=`mount | awk  '$1 ~ /^\/alcatel\/temp$/ {print "OK"}'`
if [ "x${check_temp}" = xOK ]
then
	echo "/alcatel/temp partition is mounted" | tee -a /dev/msglog
else
	echo "ERROR: /alcatel/temp NOT MOUNTED!!!" | tee -a /dev/msglog
	echo "ERROR: can not share/mount /alcatel/temp/nfs directory!!!"  | tee -a /dev/msglog
	exit 1
fi

. /install/data/cluster.conf

if [ "$CLUSTER_TYPE" = MASTER ]
then
	echo "Checking if /alcatel/temp/nfs directory is shared" | tee -a /dev/msglog
	dfshares |grep /alcatel/temp/nfs
	answer=$?
	if [ "$answer" -ne 0 ]
	then 
		echo "Sharing /alcatel/temp/nfs/ directory" | tee -a /dev/msglog
		#SUBNET=`ifconfig -a | awk '$2 ~ /^'"$FLOATING_IP"'$/ {print $6}'`
		share -o rw /alcatel/temp/nfs
		answer=$?
		if [ "$answer" -ne 0 ]
		then
			echo "ERROR: /alcatel/temp/nfs was not shared" | tee -a /dev/msglog
			echo "Exiting script..."
			exit 1
		fi
	fi
elif [ "$CLUSTER_TYPE" = SLAVE ]
then
	echo "Checking if /alcatel/temp/nfs directory is shared on master node" | tee -a /dev/msglog
	#wait maximum 5 minutes for MASTER
	i=20
        while [ $i -gt 0 ]
        do
                dfshares $MASTER_PRIV |grep /alcatel/temp/nfs
                answer=$?
                if [ "$answer" -eq 0 ]
                then
                        break
                fi
                echo "Waiting for the MASTER ..." | tee -a /dev/msglog
                sleep 15
                i=$(($i-1))
        done
        if [ "$answer" -ne 0 ]
	then
		echo "ERROR: /alcatel/temp/nfs is not shared on MASTER node" | tee -a /dev/msglog
		echo "Exiting script..."
		exit 1
	fi
	echo "Mounting /alcatel/temp/nfs from master node"
	mount -o rw -F nfs $MASTER_PRIV:/alcatel/temp/nfs /alcatel/temp/nfs
	answer=$?
	if [ "$answer" -ne 0 ]
	then
		echo "ERROR: /alcatel/temp/nfs was not mounted" | tee -a /dev/msglog
		echo "Exiting script..."
		exit 1
	fi
fi
