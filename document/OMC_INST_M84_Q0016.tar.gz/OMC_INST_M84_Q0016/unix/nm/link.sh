#!/bin/ksh
#set -x
. /install/data/cluster.conf

#CR 218521

echo "Creating /alcatel/muse/data directory"
	mkdir -p /alcatel/muse/data/
	chmod -R a+w /alcatel/muse/data/

if [ "$RAC" = 1 ]
then
        echo "Cluster installation detected"
        check_temp=`mount | awk  '$1 ~ /^\/alcatel\/temp$/ {print "OK"}'`
        if [ "x${check_temp}" = xOK ]
        then
                echo "Creating /alcatel/temp/nfs directory"
                mkdir -p /alcatel/temp/nfs
                chmod -R 777 /alcatel/temp/nfs
        else
                echo "ERROR: /alcatel/temp NOT MOUNTED!!!"
                echo "ERROR: /alcatel/temp/nfs directory NOT created and NOT shared/mounted!!!"
		echo "ERROR: /alcatel/temp/data structure NOT created!!!"
		exit 1
        fi
fi

if [ "$RAC" = 0 ]
then
	mkdir -p /alcatel/temp/nfs
	chmod -R 777 /alcatel/temp/nfs
fi

echo "Creating /alcatel/temp/data/hist directory" 
        mkdir -p /alcatel/temp/data/hist
        chmod -R 777 /alcatel/temp/data/hist

echo "Creating /alcatel/temp/data/trace directory"
	mkdir -p /alcatel/temp/data/trace
	chmod -R 777 /alcatel/temp/data/trace

echo "Linking files"
if [ -h /alcatel/muse/data/trace ]
        then
        echo "/alcatel/muse/data/trace link already exists"
        else
        ln -s /alcatel/temp/data/trace /alcatel/muse/data/trace
fi
if [ -h /alcatel/muse/data/hist ]
        then
        echo "/alcatel/muse/data/hist link already exists"
	else
        ln -s /alcatel/temp/data/hist /alcatel/muse/data/hist
fi
