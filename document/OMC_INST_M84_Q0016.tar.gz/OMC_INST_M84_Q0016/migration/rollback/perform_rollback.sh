#!/bin/bash

if [ "$(id -u)" != "0" ]; then
echo "This procedure must be run as root user. Exiting script"
exit 1
fi

. ../scripts/functions

check_oracle

#--------------------------- main MAIN ------------------------------#

{

echo "`date` $0 started ..."

#some prechecks here ...
if [ `uname` = "Linux" ];then
	
	check_server_type
	check_mirroring
        check_rollback

        if [ "$enable_rollback" == "no" ];then
                echo "Rollback is not enabled (all mirrors have 2 submirrors), no need to disable it"
                exit 0
        fi
	mirroring_status
fi


echo -e "\nATTENTION - this script will rollback the system to OLD software version!"
while true;do
        echo "Do you want to continue (y/n)?"
        read answer
        case $answer in
                Y|y|Yes|yes|YES)
                                break
                ;;
                N|n|No|NO|no)
                                exit
                ;;

                *)
                                continue
                ;;

        esac
done

echo "***********************************************************"
echo "This script will flashback Oracle database, rebuild software raid1 and disable flashback."
echo "Operations are performed only if needed for the HW configuration you are using."
echo "Please check the log files in /alcatel/MS/data/traces/ directory."

./flashback_database.sh
status=$?
if [ $status -ne 0 ]
then
	echo "ERROR : flashback database failed, please check the log file!"
	exit 1
fi

if [ `uname` = "SunOS" ];then
	./rollback_stage1
fi

if [ `uname` = "Linux" ];then
        if [ "$RHEL_RELEASE" -eq 5 ];then
                ./linux_rollback_stage1
        else
                ./linux6_rollback_on
        fi
fi
status=$?

if [ $status -ne 0 ]
then
        echo "ERROR : rollback of mirroring failed, please check the log file!"
        exit 1
fi

} 2>&1 |tee -a $LOG

echo_line
echo "Log file: $LOG"
echo_line

