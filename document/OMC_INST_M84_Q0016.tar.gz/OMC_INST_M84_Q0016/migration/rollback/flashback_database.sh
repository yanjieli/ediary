#!/bin/ksh

#
#set -x
export logfile=/alcatel/MS/data/traces/$(basename $0 .sh)_$(date '+%Y-%m-%d_%H:%M:%S')
export tablespaces=/tmp/tablespace.txt
export clusterconf=/install/data/cluster.conf
export OMC_UNIX_INSTALL_DIR=$(pwd)/../../unix


echo "Logfile is : $logfile"

scr_location=$(dirname $0)

install_file="${scr_location}/../../unix/lib/install.sh"
        if [ ! -f $install_file ];then
                echo "[`date '+%d-%m-%y %H:%M'`] ERROR INSTALL: $install_file file not found" >&2
                exit 1
        fi
. $install_file


if [ $(uname) = "SunOS" ]
then
        OS_TYPE="solaris"
        orafile=/var/opt/oracle/oratab
else
        OS_TYPE="linux"
        orafile=/etc/oratab
fi

if [ -f $orafile ]
then
        ORACLE_HOME=$(awk -F: '$1 ~/^SNM$/ {print $2}' $orafile)
        export ORACLE_HOME
        log_message "INFO" " ORACLE_HOME = $ORACLE_HOME" | tee -a $logfile
else
        log_message "ERROR" " ERROR $orafile does not exists" | tee -a $logfile
        exit 0
fi

GRID_HOME=$(echo $ORACLE_HOME|sed "s/product/grid/g")

if [ ! -d $ORACLE_HOME ]
then
        log_message "ERROR" " Oracle version defined in $orafile is invalid." | tee -a $logfile
        exit 1
fi

if [ ! -d $GRID_HOME ]
then
        log_message "ERROR" " Oracle version defined in $orafile is invalid." | tee -a $logfile
        exit 1
fi


if [ -f $clusterconf ]
then
	ASM_TYPE=0
	. $clusterconf
	if [ $ASM -eq 0 ]
        then
                undofile1=/alcatel/oracle/oradata/SNM/undotbs01.dbf
                undofile2=/alcatel/oracle/oradata/SNM/undotbs02.dbf
		export SPFILE="$ORACLE_HOME/dbs/spfileSNM.ora"
        else
		export SPFILE="+DATA/SNM/spfileSNM.ora"
                if [ $ASM_TYPE -eq 4 ]; then
                                undofile1="+REDO"
                                undofile2="+RECOVERY"
                elif [ $ASM_TYPE -eq 3 ]; then
                                undofile1="+REDO"
                                undofile2="+RECOVERY"
                elif [ $ASM_TYPE -eq 2 ]; then
                                undofile1="+RECOVERY"
                                undofile2="+RECOVERY"
                else
                                undofile1="+DATA"
                                undofile2="+DATA"
                fi
        fi
        if [ $RAC -eq 1 ]; then
		export SPFILE="+DATA/SNM/spfileSNM.ora"
                export ORACLE_SID=SNM1
                undofile1="+DATA"
                undofile2="+DATA"
        else
                export ORACLE_SID=SNM
        fi
else
	log_message "ERROR" "$clusterconf file does not exists!" | tee -a $logfile
	exit 1
fi

if [ $OS_TYPE = "solaris" ]
then
        #in case of solaris, check if storedge is connected
        check_storedge
        nrse=$?
        if [ $nrse -eq 0 ]
        then
                log_message "INFO" "NO storedge detected. NOT needed to activate flashback!" | tee -a $logfile
                exit 0
        fi
else
        # in case of linux check number of logical devices
	# find out which RHEL version is running
        RH_VERSION=$(lsb_release -r | awk '{print $2}' | awk -F. '{print $1}')

        # count the LD's on the internal disks (SAN devices excluded)
        if [ $RH_VERSION -eq 5 ]; then
                NB_OF_ACTUAL_LDS=`/sbin/parted -l | sort | grep "Disk.*cciss" | wc -l`

                if [ $NB_OF_ACTUAL_LDS -eq 2 ]; then

                        # current server configuration is Blade MAIN?

                        if [ $SAN -eq 1 ] && [ "$server_type" = "ProLiant BL660c Gen8" ]; then
                                log_message "INFO" "Detected server configuration ProLiant BL660c Gen8."
                        else
                                log_message "INFO" "Not a ProLiant BL660c Gen8 configuration, no need to activate flashback!" | tee -a $logfile
                                exit 5
                        fi
                fi
	fi

fi

export oraprofile="~oracle/.profile"
export oraprofile_old="~oracle/.profile.old"

log_message "INFO" "Comment line cleanup_arch.sh in root crontab" | tee -a $logfile
EDITOR=ed
export EDITOR
crontab -e <<- ! > /dev/null
        g/\/cleanup_arch.sh/s/^/#/
        .
        w
        q
!

# stop NPO pmon:
if [ ${OS_TYPE} = "solaris" ]
then
        initfile=/etc/inittab
        log_message "INFO" "Comment pmon line $initfile" | tee -a $logfile
        sed -e "/bin\/pmon/s/^/#/" $initfile > $initfile.$$
        mv $initfile.$$ $initfile
        init q
else
        if [ $RH_VERSION -eq 5 ]; then

                # disable NPO pmon on RH5
                initfile=/etc/inittab
                log_message "INFO" "Comment pmon line $initfile" | tee -a $logfile
                sed -e "/bin\/pmon/s/^/#/" $initfile > $initfile.$$
                mv $initfile.$$ $initfile
                init q

        else

                # disable NPO pmon on RH6
                /sbin/stop pmon
        fi
fi

mkdir -p $(dirname $logfile)
touch $logfile.lst
chown oracle:oinstall $logfile.lst
chown oracle:oinstall $logfile

set +e
wait_for_oracle

if [ -f /install/data/tuning_server.pm_BEFOREFB ]
then
	. /install/data/tuning_server.pm_BEFOREFB
else
	log_message "ERROR" "/install/data/tuning_server.pm_BEFOREFB not found!" | tee -a $logfile
	exit 1
fi

UNDO_TBS=$(perl -e '$UNDO_size="'$UNDO_TBS'"; $aux=int($UNDO_size * 1024);print $aux.M;')
UNDO_MAX_SIZE=$(perl -e '$UNDO_MAX_size="'$UNDO_MAX_SIZE'"; $aux=int($UNDO_MAX_size * 1024);print $aux.M;')
export UNDO_TBS
export UNDO_MAX_SIZE
export UNDO_RETENTION
export number_ora_versions=$(ls /opt/app/oracle/product/ | wc -l)

if [ $number_ora_versions -ge 3 ]
then
	log_message "ERROR" " found $number_ora_versions oracle versions in /opt/app/oracle/product/ directory!" | tee -a $logfile
	exit 1
fi

/sbin/stop oracle-ohasd 

check_db_state
if [ $? -ne 0 ]; then
        log_message "ERROR" " Exiting ...Data base not mounted!"
        exit 1
else
        log_message "INFO" "Data base mounted"
fi

su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba
        select tablespace_name, file_name, online_status from dba_data_files;
        exec dbms_stats.gather_fixed_objects_stats;
        exec dbms_stats.gather_dictionary_stats;
        execute dbms_stats.gather_schema_stats('SYS');
        alter system flush shared_pool;
        alter system flush shared_pool;
        alter system flush shared_pool;
        spool off
        exit
EOF
"
oracle_stop | tee -a $logfile

su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
        spool $logfile append
        connect sys/orapower as sysdba
	startup mount exclusive pfile='/alcatel/var/home/oracle/pfile_before';
	WHENEVER SQLERROR EXIT SQL.SQLCODE;
	flashback database to restore point before_migration;
	drop restore point BEFORE_MIGRATION;
	WHENEVER SQLERROR CONTINUE;
	disconnect
        spool off
        exit
EOF
"
oracle_stop | tee -a $logfile

if [ $? -ne 0 ];then exit 1;fi

if [ $number_ora_versions -eq 2 ]; then
        log_message "INFO" "Found 2 oracle versions, continue with old version" | tee -a $logfile

	if [ -f ${orafile}.orig ]
        then
                log_message "INFO" "Copy ${orafile}.orig to ${orafile} " | tee -a $logfile
                cp ${orafile}.orig ${orafile}
        else
                log_message "WARNING" " ${orafile}.orig not found " | tee -a $logfile
        fi

        if [ -f ~oracle/.profile.old ]
        then
                log_message "INFO" "Copy ~oracle/.profile.old to ~oracle/.profile " | tee -a $logfile
                grep -v newtask ~oracle/.profile.old > ~oracle/.profile
        else
                log_message "ERROR" " ~oracle/.profile.old not found " | tee -a $logfile
        fi

        . ~oracle/.profile

        log_message "INFO" "Oracle home is: $ORACLE_HOME" | tee -a $logfile

	log_message "INFO" "spfile is: $SPFILE" | tee -a $logfile

        if [ ! -d $ORACLE_HOME ]
        then
                log_message "ERROR" " $ORACLE_HOME does not exists " | tee -a $logfile
                exit 1
        fi
fi

 
su - oracle -c "
. ~oracle/.profile

echo \"Oracle home: $ORACLE_HOME\"
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
        spool $logfile append
        connect / as sysdba
	startup mount exclusive pfile='/alcatel/var/home/oracle/pfile_before';
	alter database open resetlogs;
	alter database flashback off;
        create spfile='"$SPFILE"' from pfile='/alcatel/var/home/oracle/pfile_before';
        alter system set undo_retention=0 scope=memory;
        create undo tablespace UNDOTBS2 datafile '"$undofile2"' size 100M AUTOEXTEND ON NEXT 10240 MAXSIZE 32767M;
        alter system set undo_tablespace=UNDOTBS2;
        !/alcatel/MS/OMC_DBCF/dba_scripts/check_segments.sh UNDOTBS1
        drop tablespace UNDOTBS1 including contents and datafiles;
        create undo tablespace UNDOTBS1 datafile '"$undofile1"' size $UNDO_TBS AUTOEXTEND ON NEXT 5120K MAXSIZE $UNDO_MAX_SIZE;
        alter system set undo_tablespace=UNDOTBS1;
	shutdown immediate;
	startup;
        !/alcatel/MS/OMC_DBCF/dba_scripts/check_segments.sh UNDOTBS2
        drop tablespace UNDOTBS2 including contents and datafiles;
        alter system set undo_retention=$UNDO_RETENTION scope=spfile;
        select tablespace_name, file_name, online_status from dba_data_files;
        spool off
        set head off
        set lines 150
        set pages 999
        set feed off
        column  c1 heading 'X' FORMAT A20
        column  c2 heading 'Y' FORMAT A70
        column  c3 heading 'Y' FORMAT A10

        spool $tablespaces
        select
        tablespace_name c1,
        file_name c2,
        online_status c3
        from dba_data_files;

        disconnect
        spool off
        exit

EOF
"

# enable NPO pmon on RH6
/sbin/start pmon

grep "Flashback complete." $logfile.lst
if [ $? -ne 0 ]
then
        log_message "ERROR" " Flashback database failed!" | tee -a $logfile
        exit 1
fi

if [ -f $tablespaces ]
then
	grep -i "offline" $tablespaces
	status=$?
	if [ $status = 0 ]
	then
		log_message "ERROR" " offline tablespace check the log files!" | tee -a $logfile
		cat $tablespaces | tee -a $logfile
		exit 2
	fi
else
	log_message "WARNING" "$tablespaces file missing, check of tablespaces not performed." | tee -a $logfile
	exit 1
fi

if [ -f /alcatel/temp/nfs.tar ]
then
	rm -fr /alcatel/temp/nfs
	log_message "INFO" "Restoring /alcatel/temp/nfs directory" | tee -a $logfile
	(cd / ; tar xvf /alcatel/temp/nfs.tar)
else
	log_message "ERROR" " /alcatel/temp/nfs.tar file not found" | tee -a $logfile
fi	

grep ERR $logfile > /dev/null
exit 0
