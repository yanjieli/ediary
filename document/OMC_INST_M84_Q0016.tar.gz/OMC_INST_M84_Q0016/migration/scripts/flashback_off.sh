#!/bin/ksh

#set -x
logfile=/alcatel/MS/data/traces/$(basename $0 .sh)_$(date '+%Y-%m-%d_%H:%M:%S')
flashback_txt=/tmp/FLASHBACK.txt

echo "Logfile is : $logfile"

export OMC_UNIX_INSTALL_DIR=$(pwd)/../../unix

. ../../unix/lib/install.sh

if [ $(uname) = "SunOS" ]
then
        OS_TYPE="solaris"
        orafile=/var/opt/oracle/oratab
	grid_base=/opt/app/grid
else
        OS_TYPE="linux"
        orafile=/etc/oratab
	grid_base=/opt/app/oracle/grid
fi

if [ -f /install/data/cluster.conf ]
then
        . /install/data/cluster.conf
else
        log_message "ERROR" " /install/data/cluster.conf file not found, setting ASM=0" | tee -a $logfile
        export ASM=0
        export RAC=0
fi

if [ $OS_TYPE = "solaris" ]
then
        #in case of solaris, check if storedge is connected
        check_storedge
        nrse=$?
        if [ $nrse -eq 0 ]
        then
                log_message "INFO" "NO storedge detected. NOT needed to deactivate flashback!" | tee -a $logfile
                exit 0
        fi
else
	# in case of linux, check number of logical devices
	# find out which RHEL version is running
	RH_VERSION=$(lsb_release -r | awk '{print $2}' | awk -F. '{print $1}')
	
	# count the LD's on the internal disks (SAN devices excluded)
	if [ $RH_VERSION -eq 5 ]; then
		NB_OF_ACTUAL_LDS=`/sbin/parted -l | sort | grep "Disk.*cciss" | wc -l`
	
		if [ $NB_OF_ACTUAL_LDS -eq 2 ]; then
		
			# current server configuration is Blade MAIN?

			server_type=`/usr/sbin/dmidecode | grep "Product Name" | cut -d: -f2 | head -1 | sed -e 's/^ //g'`
			
			if [ $SAN -eq 1 ] && [ "$server_type" = "ProLiant BL660c Gen8" ]; then
				log_message "INFO" " Detected server configuration ProLiant BL660c Gen8."
			else
				log_message "INFO" " Not a ProLiant BL660c Gen8 configuration, no need to deactivate flashback!" | tee -a $logfile
				exit 5
			fi
			
		fi
	fi
fi

if [ $RAC -eq 1 ]; then
        export ORACLE_SID=SNM1
else
        export ORACLE_SID=SNM
fi

if [ -f $orafile ]
then
	ORACLE_HOME=$(awk -F: '$1 ~/^SNM$/ {print $2}' $orafile)
	if [ ! -d $ORACLE_HOME ]
	then
		log_message "ERROR" " can not determine ORACLE_HOME" | tee -a $logfile
		exit 1
	else
		log_message "INFO" "ORACLE_HOME = $ORACLE_HOME" | tee -a $logfile
		export ORACLE_HOME
	fi
else
        log_message "ERROR" " $orafile does not exists" | tee -a $logfile
fi

log_message "INFO" " Uncomment line cleanup_arch.sh in root crontab" | tee -a $logfile
EDITOR=ed
export EDITOR
crontab -e <<- ! > /dev/null
        g/\/cleanup_arch.sh/s/^#*//
        .
        w
        q
!


if [ ${OS_TYPE} = "solaris" ]
then
        initfile=/etc/inittab
        log_message "INFO" "Comment pmon line $initfile" | tee -a $logfile
        sed -e "/bin\/pmon/s/^/#/" $initfile > $initfile.$$
        mv $initfile.$$ $initfile
        init q
else
        if [ $RH_VERSION -eq 5 ]; then

                # disable NPO pmon on RH5
                initfile=/etc/inittab
                log_message "INFO" " Comment pmon line $initfile" | tee -a $logfile
                sed -e "/bin\/pmon/s/^/#/" $initfile > $initfile.$$
                mv $initfile.$$ $initfile
                init q

        else

                # disable NPO pmon on RH6
                /sbin/stop pmon
        fi
fi

mkdir -p $(dirname $logfile)
touch $logfile.lst
chown oracle:oinstall $logfile.lst

set +e
wait_for_oracle

su - oracle -c "
ORACLE_VERSION=`$ORACLE_HOME/OPatch/opatch lsinventory | awk ' $0 ~ /^Oracle Database/ {print $NF}'`
log_message "INFO" " Setting database compatible to $ORACLE_VERSION" | tee -a $logfile.lst
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF
        spool $logfile append
        connect sys/orapower as sysdba
        alter system set compatible=\"$ORACLE_VERSION\" scope=spfile;
        disconnect
        spool off
        exit
EOF
"

if [ $ORACLE_HOME != "/opt/app/oracle/product/11.2.0" ]
then
  #only if ASM or RAC is used
  if [ $RAC -eq 1 ] || [ $ASM -eq 1 ]
  then
	log_message "INFO" " Setting diskgroup compatible.asm parameter" | tee -a $logfile.lst
	export asm_diskgroup='\$asm_diskgroup'
	export ORACLE_VERSION='${ORACLE_VERSION}'
su - oracle -c "
	ORACLE_VERSION=\`$ORACLE_HOME/OPatch/opatch lsinventory | awk ' \$0 ~ /^Oracle Database/ {print \$NF}'\`

        . ~/.grid_profile
        $ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect / as sysasm

	SET SERVEROUTPUT ON
	declare
	V_sql varchar2(500);
	cursor c is select name from v$asm_diskgroup;
	begin
        	for i in c
        	loop
                	dbms_output.put_line ( 'Alter diskgroup :' || i.name );
                	V_sql := 'ALTER DISKGROUP ' || i.name || ' SET ATTRIBUTE ''compatible.asm'' = ''' || '${ORACLE_VERSION}' || '''';
                	dbms_output.put_line ( V_sql );
                	execute immediate V_sql;
        	end loop;
	end;
	/
        disconnect
        spool off
        exit
EOF
"
  fi
fi

if [ $ASM -eq 0 ]
then
        if [ -f /install/data/tuning_server.pm ]
        then
                . /install/data/tuning_server.pm
        else
                log_message "ERROR" " /install/data/tuning_server.pm file missing" | tee -a $logfile
                RECOVERY_SIZE=20000
        fi
        RECOVERY_SIZE=$(perl -e 'print "'$RECOVERY_SIZE'".M;')
su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba

        alter system set db_recovery_file_dest_size=$RECOVERY_SIZE scope=spfile;

        shutdown immediate;

        disconnect
        spool off
        exit
EOF
"
#end ASM=0
else
#start ASM=1
su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba
        disconnect
        spool off
        exit
EOF
"

oracle_stop | tee -a $logfile

#end ASM=1
fi

su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba

        startup mount exclusive;

        disconnect
        spool off
        exit
EOF
"
check_db_state
if [ $? -ne 0 ]; then
        log_message "ERROR" " Exiting ...Data base not mounted!"
        exit 1
else
        log_message "INFO" " Data base mounted"
fi

su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba

	alter database flashback off;

	drop restore point before_migration;
 
        alter database open;
	
        disconnect
        spool off
        exit
EOF
"


if [ ${OS_TYPE} = "solaris" ]
then
        initfile=/etc/inittab
        log_message "INFO" " Uncomment pmon line $initfile" | tee -a $logfile
        sed -e "/bin\/pmon/s/^#*//" $initfile > $initfile.$$
        mv $initfile.$$ $initfile
        init q
else
        if [ $RH_VERSION -eq 5 ]; then
                initfile=/etc/inittab
                # enable NPO pmon on RH5
                log_message "INFO" " Uncomment pmon line $initfile" | tee -a $logfile
                sed -e "/bin\/pmon/s/^#*//" $initfile > $initfile.$$
                mv $initfile.$$ $initfile
                init q

        else

                 # enable NPO pmon on RH6
                 /sbin/start pmon
        fi
fi

if [ -f /alcatel/temp/nfs.tar ]
then
	log_message "INFO" " Delete /alcatel/temp/nfs.tar" | tee -a $logfile
	rm /alcatel/temp/nfs.tar
fi

log_message "INFO" " FLASHBACK_STATUS=NO" > $flashback_txt
chmod 777 $flashback_txt
if [ $? -ne 0 ]
then
        log_message "ERROR" " creating $flashback_txt file" | tee -a $logfile
        exit 1
else
        log_message "INFO" " $flashback_txt file created" | tee -a $logfile
fi

number_ora_versions=$(ls /opt/app/oracle/product/ | egrep "^1[0-9]\." | wc -l)

if [ $number_ora_versions -ge 3 ]
then
        log_message "ERROR" " found $number_ora_versions oracle versions in /opt/app/oracle/product/ directory!" | tee -a $logfile
        exit 1
fi

if [ $number_ora_versions -eq 2 ]
then
        log_message "INFO" " Found 2 oracle versions" | tee -a $logfile
	old_oracle=$(ls /opt/app/oracle/product | egrep "^1[0-9]\." | head -1)
	log_message "INFO" " Delete old Oracle : /opt/app/oracle/product/${old_oracle} (y/n)?" | tee -a $logfile
	read answer
	case $answer in
            Y|y|Yes|yes|YES)   	if [ ! -h /opt/app/oracle/product/${old_oracle} ]
				then	
					log_message "INFO" " Deleting /opt/app/oracle/product/${old_oracle} directory" | tee -a $logfile	
					rm -fr /opt/app/oracle/product/${old_oracle} 
				else
					#must follow the link to old oracle dir
                                        dir=$(ls -l /opt/app/oracle/product/${old_oracle} | sed -e's/.*-> //')
                                        unlink /opt/app/oracle/product/${old_oracle} 
                                        log_message "INFO" "Deleting ${dir} directory" | tee -a $logfile
                                        rm -fr $dir
				fi
				;;
            *)                 	log_message "WARNING" " old oracle directory not deleted" | tee -a $logfile 
				;;
        esac
fi

number_grid_versions=$(ls $grid_base 2>/dev/null | egrep "^1[0-9]\." | wc -l)

if [ $number_grid_versions -ge 3 ]
then
        log_message "ERROR" " found $number_grid_versions grid versions in $grid_base directory!" | tee -a $logfile
        exit 1
fi

if [ $number_grid_versions -eq 2 ]
then
        log_message "INFO" " Found 2 oracle grid versions" | tee -a $logfile
        old_grid=$(ls $grid_base | egrep "^1[0-9]\." | head -1)
        log_message "INFO" " Delete old Oracle grid: ${grid_base}/${old_grid} (y/n)?" | tee -a $logfile
        read answer
        case $answer in
            Y|y|Yes|yes|YES)   	if [ ! -h ${grid_base}/${old_grid} ]
				then 
					log_message "INFO" " Deleting ${grid_base}/${old_grid} directory" | tee -a $logfile
                                	rm -fr ${grid_base}/${old_grid}
				else
					#must follow the link to old oracle grid dir
					dir=$(ls -l ${grid_base}/${old_grid} | sed -e's/.*-> //')
					unlink ${grid_base}/${old_grid}
					log_message "INFO" " Deleting ${dir} directory" | tee -a $logfile
					rm -fr $dir
				fi
                                ;;
            *)                  log_message "WARNING" " old oracle grid directory not deleted" | tee -a $logfile
                                ;;
        esac
fi


grep ERR $logfile > /dev/null
if [ $? -ne 0 ]
then
	exit 0
else 
	log_message "ERROR" " find ERR in $logfile,please check" | tee -a $logfile
	exit 1
fi
