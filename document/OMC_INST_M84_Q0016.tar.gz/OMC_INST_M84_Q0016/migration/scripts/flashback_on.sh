#!/bin/ksh

#set -x
logfile=/alcatel/MS/data/traces/$(basename $0 .sh)_$(date '+%Y-%m-%d_%H:%M:%S')
flashback_txt=/tmp/FLASHBACK.txt
chmod 777 /alcatel/temp/data
nfs_exclusion_list=$(dirname $0)/nfs_exclusion.lst

echo "Logfile is : $logfile"

export OMC_UNIX_INSTALL_DIR=$(pwd)/../../unix

. ../../unix/lib/install.sh

if [ $(uname) = "SunOS" ]
then
        OS_TYPE="solaris"
	orafile=/var/opt/oracle/oratab
	flash_recovery=/alcatel/oracle/oradata/
else
        OS_TYPE="linux"
	orafile=/etc/oratab
	flash_recovery=/alcatel/temp/
fi

export orafile

if [ -f /install/data/cluster.conf ]
then
        . /install/data/cluster.conf
else
	log_message "ERROR" " /install/data/cluster.conf file not found, setting ASM=0" | tee -a $logfile
	export ASM=0
	export RAC=0
fi

if [ $OS_TYPE = "solaris" ]
then
	#in case of solaris, check if storedge is connected
	check_storedge
	nrse=$?
	if [ $nrse -eq 0 ]
	then
		log_message "INFO" "NO storedge detected. NOT needed to activate flashback!" | tee -a $logfile
		exit 0
	fi
else

	# in case of linux, check number of logical devices
	# find out which RHEL version is running
	RH_VERSION=$(lsb_release -r | awk '{print $2}' | awk -F. '{print $1}')



	#RCA: in case of RH6, all tests are already passed by now: server_type (NPO/SON), mirroring (LD nr), raw mirrors not dettached, so no issue ... in case of RH5, see bellow :
	
	if [ $RH_VERSION -eq 5 ]; then

		# count the LD's on the internal disks (SAN devices excluded)
                NB_OF_ACTUAL_LDS=`/sbin/parted -l | sort | grep "Disk.*cciss" | wc -l`
	
	
		if [ $NB_OF_ACTUAL_LDS -eq 2 ]; then
			
			# current server configuration is Blade MAIN?, otherwise raw on mirror, not supported ...
			
			server_type=`/usr/sbin/dmidecode | grep "Product Name" | cut -d: -f2 | head -1 | sed -e 's/^ //g'`
			
			if [ $SAN -eq 1 ] && [ "$server_type" = "ProLiant BL660c Gen8" ]; then
				log_message "INFO" "Detected server configuration ProLiant BL660c Gen8."
			else
				log_message "INFO" "Not a ProLiant BL660c Gen8 configuration, no need to activate flashback!" | tee -a $logfile
				exit 5
			fi
		fi		
	fi
fi

if [ $RAC -eq 1 ]; then
        export ORACLE_SID=SNM1
	flash_recovery=/alcatel/temp/
else
        export ORACLE_SID=SNM
fi

if [ -f /install/data/tuning_server.pm ]
then
	cp /install/data/tuning_server.pm /install/data/tuning_server.pm_BEFOREFB
fi

if [ -f $orafile ]
then
        ORACLE_HOME=$(awk -F: '$1 ~/^SNM$/ {print $2}' $orafile)
	export ORACLE_HOME
	log_message "INFO" "ORACLE_HOME = $ORACLE_HOME" | tee -a $logfile
	cp ${orafile} ${orafile}.orig
	log_message "INFO" "Copy ${orafile} to ${orafile}.orig " | tee -a $logfile
else
        log_message "ERROR" " $orafile does not exists" | tee -a $logfile
fi

mkdir -p $(dirname $logfile)
touch $logfile.lst
chown oracle:oinstall $logfile.lst
chown oracle:oinstall $logfile

log_message "INFO" "Comment line cleanup_arch.sh in root crontab" | tee -a $logfile
EDITOR=ed
export EDITOR
crontab -e <<- ! > /dev/null
        g/\/cleanup_arch.sh/s/^/#/
        .
        w
        q
!

if [ ${OS_TYPE} = "solaris" ]
then
	initfile=/etc/inittab
	log_message "INFO" "Comment pmon line $initfile" | tee -a $logfile
	sed -e "/bin\/pmon/s/^/#/" $initfile > $initfile.$$
	mv $initfile.$$ $initfile
	init q
else
	if [ $RH_VERSION -eq 5 ]; then
	
		# disable NPO pmon on RH5
		initfile=/etc/inittab
		log_message "INFO" "Comment pmon line $initfile" | tee -a $logfile
		sed -e "/bin\/pmon/s/^/#/" $initfile > $initfile.$$
		mv $initfile.$$ $initfile
		init q
	
	else
	
		# disable NPO pmon on RH6
		/sbin/stop pmon
	fi
fi

set +e

wait_for_oracle

if [ $ASM -eq 0 ]
then
        disksize=$(df -k $flash_recovery | awk '/alcatel/ {print $4}')
        RECOVERY_SIZE=$(perl -e 'print eval(int('"$disksize"'/1330)-10240).M')
        log_message "INFO" " Setting db_recovery_file_dest_size=$RECOVERY_SIZE " | tee -a $logfile
su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba

        alter system set db_recovery_file_dest_size=$RECOVERY_SIZE scope=spfile;

        disconnect
        spool off
        exit
EOF
"
fi #end ASM=0

ORACLE_GRID=$(awk -F: '$1 ~/^+ASM$/ {print $2}' $orafile)
export ORACLE_GRID

su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba

	create pfile='/alcatel/var/home/oracle/pfile_before' from spfile;

        SET LINESIZE 130
        select file_name, tablespace_name, status, bytes /1048576  as MB from dba_data_files;
        select username, temporary_tablespace, default_tablespace from dba_users ;
        select tablespace_name, status, contents, extent_management from dba_tablespaces;
        select count(*) from dba_all_tables where tablespace_name = 'MUSE';
        select count(*) from dba_all_tables where tablespace_name = 'MUSE_PLUGS';
        select count(*) from dba_all_tables where tablespace_name = 'USERS';
        disconnect
        spool off
        exit
EOF
"


oracle_stop | tee -a $logfile
ps -ef | egrep "[o]ra_pmon_$ORACLE_SID" && {
	log_message "ERROR"   " Oracle is still running!"
	log_message "ERROR"   " Enable rollback is not performed"
	log_message "INFO"    " PMON is disabled (/sbin/stop pmon)"
	log_message "INFO"    " cleanup_arch.sh is disabled (crontab)"
	log_message "INFO"    " Kill active oracle session and rerun enable rollback"
	exit 1
}

su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba

        startup mount exclusive;
	
	disconnect
        spool off
        exit
EOF
"
check_db_state
if [ $? -ne 0 ]; then
        log_message "ERROR" " Exiting ...Data base not mounted!"
        exit 1
else
        log_message "INFO" "Data base mounted"
fi

su - oracle -c "
export ORACLE_SID=$ORACLE_SID
$ORACLE_HOME/bin/sqlplus /nolog <<- EOF

        spool $logfile append
        connect sys/orapower as sysdba

	alter database archivelog;
	
	alter system set DB_FLASHBACK_RETENTION_TARGET=2880 SCOPE=BOTH;

	alter database flashback on;

	create restore point before_migration GUARANTEE FLASHBACK DATABASE;
 
        alter database open;
 
        disconnect
        spool off
        exit
EOF
"

if [ ${OS_TYPE} = "solaris" ]
then
        initfile=/etc/inittab
        log_message "INFO" "Uncomment pmon line $initfile" | tee -a $logfile
        sed -e "/bin\/pmon/s/^#*//" $initfile > $initfile.$$
        mv $initfile.$$ $initfile
        init q
else
        if [ $RH_VERSION -eq 5 ]; then
                initfile=/etc/inittab
                # enable NPO pmon on RH5
                log_message "INFO" "Uncomment pmon line $initfile" | tee -a $logfile
                sed -e "/bin\/pmon/s/^#*//" $initfile > $initfile.$$
                mv $initfile.$$ $initfile
                init q

        else

                 # enable NPO pmon on RH6
                 /sbin/start pmon
        fi
fi


log_message "INFO" "Creating $flashback_txt" | tee -a $logfile
log_message "INFO" "FLASHBACK_STATUS=YES" > $flashback_txt
chmod 777 $flashback_txt
if [ $? -ne 0 ]
then
	log_message "ERROR" " creating $flashback_txt file" | tee -a $logfile
	exit 1
else
	log_message "INFO" " $flashback_txt file created" | tee -a $logfile
fi
log_message "INFO" " cat $flashback_txt = $(cat $flashback_txt) " | tee -a $logfile


### RCI: DCTPD01260525 - [MA61D17][LS] Flashback duration - begin
if [ -d /alcatel/temp/nfs ]
then
	log_message "INFO" " Creating /alcatel/temp/nfs.tar" | tee -a $logfile
	tar cvf /alcatel/temp/nfs.tar -X ${nfs_exclusion_list} /alcatel/temp/nfs > /dev/null
else
	log_message "ERROR" " /alcatel/temp/nfs directory not found" | tee -a $logfile
fi
### RCI: end

grep ERR $logfile > /dev/null
if [ $? -ne 0 ]
then
	exit 0
else 
	log_message "ERROR" " find ERR in $logfile,please check" | tee -a $logfile
	exit 1
fi
