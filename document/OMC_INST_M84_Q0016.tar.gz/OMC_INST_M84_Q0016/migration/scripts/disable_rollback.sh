#!/bin/bash

if [ "$(id -u)" != "0" ]; then
echo "This procedure must be run as root user. Exiting script"
exit 1
fi

. functions

check_oracle

#--------------------------- main MAIN ------------------------------#

{
 
echo "`date` $0 started ..."

#some prechecks here ...
if [ `uname` = "Linux" ];then


	check_rollback

	#RCA: I know, we don't really need bellow tests, already passed during enable_rollback ...
	check_server_type

	if [ "$enable_rollback" == "no" ];then
		echo "Rollback is not enabled (all mirrors have 2 submirrors), no need to disable it" 
		exit 0
	fi
	mirroring_status
	
fi

echo "ATTENTION - it is not possible to rollback to OLD software version after running this script!"
while true;do
	echo "Do you want to continue (y/n)?"
	read answer
       	case $answer in
        	Y|y|Yes|yes|YES)    
				break
		;;
		N|n|No|NO|no)
				exit
		;;
			
           	*)
				continue
                ;;
	
       	esac
done

echo "***********************************************************"
echo "This script will disable Oracle flashback and attach back software raid1 devices."
echo "Operations are performed only if needed for the HW configuration you are using."
echo "Please check the log files in /alcatel/temp/data directory."

./flashback_off.sh

status=$?
if [ $status -eq 5 ]; then
        echo "No need to disable rollback on this server!"
        exit 0
elif [ $status -ne 0 ]; then
        echo "The script flashback_off.sh exited with errors. disable rollback will exit!"
		exit 1
fi

if [ `uname` = "SunOS" ];then
	./attach_submirrors
fi

if [ `uname` = "Linux" ];then
        if [ "$RHEL_RELEASE" -eq 5 ];then
                ./linux_attach_submirrors
        else
                ./linux6_rollback_off
        fi
fi


} 2>&1 |tee -a $LOG

global_exit_code=${PIPESTATUS[0]}
if [ $global_exit_code -ne 0 ]; then
        exit $global_exit_code
fi

echo_line
echo "Log file: $LOG"
echo_line

sh ./../../unix/oracle/info_flashback.sh
result=$?
if [ $result -ne 0 ]; then
	log_message "ERROR" "The script info_flashback.sh exited with errors" | tee -a $LOG
	echo "The script info_flashback.sh exited with errors."
	exit $result
fi


while read line; do
if [ "${line:17:3}" == "YES" ]; then
echo_line
echo "Flashback is activated."
echo_line
else
echo_line
echo "Flashback is not activated."
echo_line
fi
done < /tmp/FLASHBACK.txt
