#!/bin/bash

if [ "$(id -u)" != "0" ]; then
echo "This procedure must be run as root user. Exiting script"
exit 1
fi

echo "This script will enable Oracle flashback and demirror software raid1 devices."
echo "Operations are performed only if needed for the HW configuration you are using."
echo "Please check the log files in /alcatel/temp/data directory."

. ./functions
if [ $? -ne 0 ];then
	echo "Please go to migration/scripts directory and run again this script !"
	exit 1
fi

check_oracle

#--------------------------- main MAIN ------------------------------#
{

echo "`date` $0 started ..."

if [ `uname` = "Linux" ];then

	check_server_type
	machine_info
	if [ "$errors" == 1 ];then
		echo "Found faulty physical drive, cannot continue !"
		exit 1
	fi
	check_files
	machine_load
	check_mirroring
	check_rollback
	if [ "$enable_rollback" == "yes" ];then
		echo_line
		echo "Rollback is already enabled (all relevant mirrors have exact one submirror)"
		exit 0
	fi
	if [ "$enable_rollback" == "unknown" ];then
		echo_line
		echo "Not all mirrors have same number of submirrors "
		exit 1
	fi
	mirroring_status
fi
#if we got there, above tests passed ..

./flashback_on.sh || {
	echo_line
	echo "flashback_on.sh failed"
	exit 1
}

status=$?
if [ $status -eq 5 ]; then
	echo "No need to enable rollback on this server!"
        exit 0
elif [ $status -ne 0 ]; then
        echo "The script flashback_on.sh exited with errors. Rollback will exit!"
	exit 1
fi

if [ `uname` = "SunOS" ];then
	./detach_submirrors
fi
if [ `uname` = "Linux" ];then
	if [ "$RHEL_RELEASE" -eq 5 ];then
		./linux_detach_submirrors
	else
		./linux6_rollback
	fi
fi

} 2>&1 |tee -a $LOG
global_exit_code=${PIPESTATUS[0]}
if [ $global_exit_code -ne 0 ]; then
        exit $global_exit_code
fi

echo_line
echo "Log file: $LOG"
echo_line

sh ./../../unix/oracle/info_flashback.sh
result=$?
if [ $result -ne 0 ]; then
	log_message "ERROR" "The script info_flashback.sh exited with errors" | tee -a $LOG
	echo "The script info_flashback.sh exited with errors."
	exit $result
fi

while read line; do
if [ "${line:17:3}" == "YES" ]; then
echo_line
echo "Flashback is activated."
echo_line
else
echo_line
echo "Flashback is not activated."
echo_line
fi
done < /tmp/FLASHBACK.txt
