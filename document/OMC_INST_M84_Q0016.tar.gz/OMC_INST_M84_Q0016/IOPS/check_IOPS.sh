#!/bin/bash
#set -x

me=$(basename $0)
scr_location=$(dirname $0)
logfile=${scr_location}/${me}.log_$(date '+%Y%m%d_%H%M%S')
workDir=`pwd`
{
function checkOracle
{
#echo " in function checkOracle"
# -=-=-=-=-
#  Oracle
# -=-=-=-=-
#
. ~oracle/.profile >/dev/null 2>&1
[ -d "$ORACLE_HOME" ] || {
	echo "ERROR: ORACLE_HOME unknown" >&2
	exit 1
}
export ORACLE_SID=$(ps -ef | perl -lne 'print $1 if /[o]ra_pmon_(\S+)/')
[ -z "$ORACLE_SID" ] && {
	echo "ERROR: ORACLE_SID unknown" >&2
	exit 1
}
export PATH="${PATH}:$ORACLE_HOME/bin"


echo 'select status from v$instance;' | \
	su - oracle -c "export ORACLE_SID=$ORACLE_SID;sqlplus -s / as sysdba" | \
	grep OPEN > /dev/null || {
		echo "ERROR: database not OPEN" >&2
		exit 1
	}

echo "
	set pages 0
	set lines 160
	show parameter timed_statistic
" | su - oracle -c "export ORACLE_SID=$ORACLE_SID;sqlplus -s / as sysdba" | \
	grep TRUE > /dev/null || {
		echo "timed_statistic must be set to TRUE"
		exit 1
	}

echo "
	set pages 0
	set lines 160
	col name for a100
	select	d.name,
		i.asynch_io
	from	v\$datafile d,
		v\$iostat_file i
	where	d.file#=i.file_no
	and	i.filetype_name='Data File';
" | su - oracle -c "export ORACLE_SID=$ORACLE_SID;sqlplus -s / as sysdba" | \
	grep ASYNC_ON > /dev/null || {
		echo "Datafiles must be accessed using asynchronous I/O"
		exit 1
	}

# Estimate the number of disks used for the database
#  - remove the 2 system disks
#  - 75% of the remaining disks
#
[ -z "$nb_database_physical_disks" ] && {
	nb_database_physical_disks=$(echo "$hpacucli" | grep 'physicaldrive' | wc -l | sed s'/ //g')
	[ -z "$nb_database_physical_disks" ] || [ "$nb_database_physical_disks" -gt 1 ] && {
		(( nb_database_physical_disks-=2 ))
		(( nb_database_physical_disks=nb_database_physical_disks*75/100 ))
	}
}
[ -z "$nb_database_physical_disks" ]    && nb_database_physical_disks=1
[ "$nb_database_physical_disks" -lt 1 ] && nb_database_physical_disks=1

# 20ms? 50ms? 100ms?
#
max_acceptable_latency=10

echo -e "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` Start IOPS check for Oracle. It will take about 15 minutes to complete the Oracle part. Please wait."

echo
echo "==> Running \"dbms_resource_manager.calibrate_io\"... ($nb_database_physical_disks physical disks, max acceptable latency==${max_acceptable_latency}ms)"
echo

calibrate_io=$(su - oracle -c "
	export ORACLE_SID=$ORACLE_SID
	sqlplus -s / as sysdba <<- !
		set serveroutput on
		declare
		  l_latency  pls_integer;
		  l_iops     pls_integer;
		  l_mbps     pls_integer;
		begin
		  dbms_resource_manager.calibrate_io (num_physical_disks => $nb_database_physical_disks, 
						       max_latency        => $max_acceptable_latency,
						       max_iops           => l_iops,
						       max_mbps           => l_mbps,
						       actual_latency     => l_latency);
		  dbms_output.put_line('max IOPS = ' || l_iops);
		  dbms_output.put_line('max mbps = ' || l_mbps || ' MB/s');
		  dbms_output.put_line('latency  = ' || l_latency || ' ms');
		end;
		/
	!
"|awk '/^max IOPS/||/^max mbps/||/^latency/{for(i=1;i<=NF;i++){if($i=="="){printf $(i+1)" "}}}')

max_IOPs=$(echo $calibrate_io|awk '{print $1}')
max_MBs=$(echo $calibrate_io|awk '{print $2}')
latency=$(echo $calibrate_io|awk '{print $3}')

oracle_iops=$(getHashKey ${iops_conf}[@] "O_IOPS")
o_latency=$(getHashKey ${iops_conf}[@] "latency")
o_mb=$(getHashKey ${iops_conf}[@] "MB")

date +" Date: %m-%d-%Y Time: %k:%M:%S"

if [ "$max_IOPs" -ge "$oracle_iops" ];then
	echo -e "\n\t\e[32mMax IOPS for Oracle DB passed: required: $oracle_iops ; actual: $max_IOPs \e[0m"
else
	echo -e "\n\t\e[31mWARNING: Max IOPS for Oracle DB: $max_IOPs is lower than expected: $oracle_iops ! \e[0m"
fi

if [ "$max_MBs" -ge "$o_mb" ];then
        echo -e "\n\t\e[32mMax MBs for Oracle DB passed: required: $o_mb ; actual: $max_MBs \e[0m"
else
        echo -e "\n\t\e[31mWARNING: Max MBs for Oracle DB: $max_MBs is lower than expected: $o_mb ! \e[0m"
fi

if [ "$latency" -le "$o_latency" ];then
        echo -e "\n\t\e[32mIO latency for Oracle DB passed: required: $o_latency ; actual: $latency \e[0m"
else
        echo -e "\n\t\e[31mWARNING: IO latency for Oracle DB: $latency is lower than expected: $o_latency ! \e[0m"
fi	
	

su - oracle -c "
	export ORACLE_SID=$ORACLE_SID
	sqlplus -s / as sysdba <<- !
		set head off pagesize 0 feed off
		set lines 160
		select 'from               = '||to_char(min(begin_time),'yyyy/mm/dd hh24:mi:ss')  from dba_hist_sysmetric_summary;
		select 'to                 = '||to_char(max(end_time),  'yyyy/mm/dd hh24:mi:ss')  from dba_hist_sysmetric_summary;
		select 'max_iops_avg_read  = '||max(average) from dba_hist_sysmetric_summary where metric_name='Physical Read Total IO Requests Per Sec';
		select 'max_iops_max_read  = '||max(maxval)  from dba_hist_sysmetric_summary where metric_name='Physical Read Total IO Requests Per Sec';
		select 'max_iops_avg_write = '||max(average) from dba_hist_sysmetric_summary where metric_name='Physical Write Total IO Requests Per Sec';
		select 'max_iops_max_write = '||max(maxval)  from dba_hist_sysmetric_summary where metric_name='Physical Write Total IO Requests Per Sec';
		select 'max_bps_avg_read   = '||max(average) from dba_hist_sysmetric_summary where metric_name='Physical Read Total Bytes Per Sec';
		select 'max_bps_max_read   = '||max(maxval)  from dba_hist_sysmetric_summary where metric_name='Physical Read Total Bytes Per Sec';
		select 'max_bps_avg_write  = '||max(average) from dba_hist_sysmetric_summary where metric_name='Physical Write Total Bytes Per Sec';
		select 'max_bps_max_write  = '||max(maxval)  from dba_hist_sysmetric_summary where metric_name='Physical Write Total Bytes Per Sec';
	!
" | perl -lne '
	next if not /(\S+)\s*=\s*(.*)/;
	($var,$val)=($1,$2);
	$from=$val	if $var eq "from";
	$to=$val	if $var eq "to";
	@v=split(/_/,$var);
	next if scalar @v !=4;
	$max{$v[1]}{$v[2]}{$v[3]}=int($val);
	$max{$v[1]}{$v[2]}{$v[3]}/=(1024*1024) if $v[1] eq "bps";
	END {printf "\n==> Data from Oracle DB snapshot (dba_hist_sysmetric_summary)\n";
		printf "     Period:  $from  ->  $to\n\n";
		printf "%-36s %12s %12s %8s %12s %12s %8s\n",
			"",
			"read IOPS","write IOPS","IOPS",
			"read MB/s","write MB/s","MB/s";
		printf "%-36s %12d %12d %8d %12d %12d %8d\n",
			"Maximum average values (for 1 hour)",
			$max{iops}{avg}{read},$max{iops}{avg}{write},$max{iops}{avg}{read}+$max{iops}{avg}{write},
			$max{bps}{avg}{read},$max{bps}{avg}{write},$max{bps}{avg}{read}+$max{bps}{avg}{write};
		printf "%-36s %12d %12d %8d %12d %12d %8d\n",
			"Maximum values",
			$max{iops}{max}{read},$max{iops}{max}{write},$max{iops}{max}{read}+$max{iops}{max}{write},
			$max{bps}{max}{read},$max{bps}{max}{write},$max{bps}{max}{read}+$max{bps}{max}{write};		
				
	}
'
}


function hostInfo
{

me=$(basename $0)

# -=-=-=-=-=-=-
#  Host info
# -=-=-=-=-=-=-
#
hostname=$(hostname -s)
product=$(/usr/sbin/dmidecode -t system | perl -lne '
	push @t,$2 if /(Manufacturer|Product Name):\s+(.*)/;
	END {
		$product=join (" ",@t) if scalar @t>0;
		$product=~s/Hewlett-Packard/HP/g;
		$product=~s/(HP\s*)*HP/HP/ig;
		$product=~s/Microsystems//ig;
		$product=~s/(sun\s*)*sun/Sun/ig;
		$product=~s/FIRE/Fire/g;
		$product=~s/\s*Inc\.//g;
		$product=~s/\s*$//;
		$product=~s/workstation/Workstation/i;
		$product=~s//\2 \1/     if $product=~m/(workstation)\s+(xw\d+)/i;
		print $product;
	}
')

if [ -f "/etc/redhat-release" ]; then
	line="$(cat /etc/redhat-release)"
	vdistrib="$(echo $line | perl -lne 'print $1 if /(\d+\.*\d*)/')"
	case "$line" in
	    Red*Enterprise*)	distrib="$(uname -s) RHEL $vdistrib" ;;
	    Fedora*)		distrib="$(uname -s) Fedora $vdistrib" ;;
	    Red*)		distrib="$(uname -s) RedHat $vdistrib" ;;
	    *)			distrib="$line" ;;
	esac
elif [ -f "/etc/debian_version" ]; then
	distrib="$(uname -s) Debian $(cat /etc/debian_version)" 
else
	distrib="$(uname -a)"
fi


cpu="$(cat /proc/cpuinfo | perl -lne '
	if(/model name\s+:\s*(.*)/){
		$model=$1;
		$model=~s/Intel//g;
		$model=~s/\(R\)//g;
		$model=~s/\(TM\)//g;
		$model=~s/\s\d\s+@/@/g;
		$model=~s/tium\s+/tium/g;
		$model=~s/Hz.*/Hz/g;
		$model=~s/CPU//g;
		$model=~s/\@\s*/@/g;
		$model=~s/\s*\@/@/g;
		$model=~s/\-\s*/-/g;
		$model=~s/\s+/ /g;
		$model=~s/^\s*//;
		$model=~s/\s*$//;
		$model=~s/ ([\.\d]+.Hz)/@\1/;
	}
	if(/physical id\s+:\s+(\S+)/) {
		$phid=$1;
		if(not defined $p{$phid}) {
			$nbph++;
			$p{$phid}=1;
		}
	}
	if(/core id\s+:\s+(\S+)/) {
		$cid=$1;
		if(not defined $c{$phid}{$cid}) {
			$nbc++;
			$c{$phid}{$cid}=1;
		}
	}
	if(/processor\s+:\s+(\S+)/) {
		$nbpr++;
	}
	END {
		$nbph=1				if not $nbph;
		printf "%d",$nbph		if $nbph;
		printf " %s",$model		if $model;
		if($nbc>=1 and $nbph>=1) {
			$nbcpph=$nbc/$nbph;
			printf " (%d core%s)",$nbcpph,$nbcpph>1?"s":"";
		}
	}
')"

/usr/sbin/dmidecode -t system | egrep -i 'Product Name:.*(VM|Virtual)' > /dev/null
if [ $? -eq 0 ]; then
	mem="$(free | perl -lne '
		BEGIN{use POSIX qw(ceil);}
		if(/Mem:\s+(\d+)/){
			printf "%dGB\n", ceil($1/1024/1024)
		}'
	)"
else
	mem="$(/usr/sbin/dmidecode -t memory | perl -lne '
		$s+=$1 if /Size:\s*(\d+)/;
		END {
			printf "%dGB\n",$s/1024 if defined $s;
		}'
	)"
fi

/usr/sbin/dmidecode -t system | egrep -i 'ProLiant' > /dev/null && {
	while true
	do
		hpacucli=$(hpssacli ctrl all show config 2>&1)
		echo "$hpacucli" | grep "is running" > /dev/null || break
		sleep 5
	done
	echo "$hpacucli" | grep Smart > /dev/null && {
		disks="$(echo "$hpacucli" | perl -lne '
			next if not /physicaldrive.*,\s+(.*),\s+([\.\d]+)\s+GB/;
			$type=$1;
			$size=$2;
			$type="SSD" if $type eq "Solid State SATA";
			$d{$type}{$size}++;
			END {
				for $type (keys %d) {
					for $size (keys %{$d{$type}}) {
						push @r,"$d{$type}{$size} $type${size}GB";
					}
				}
				print join(", ",@r);
			}
		'
		)"
	}
}

# NPO
#
file="/etc/MUSE.signature"
[ -f "$file" ] && {
	type=$(perl -lne 'print $1 if /^TYPE\s+(.*)/' "$file" 2>/dev/null)
	[ -z "$type" ] || {
		[ "$type" = "NPO" ] && {
			type="MAIN"
			omc_conf=$(perl -lne 'if(/^OMC_CONF=(.*)/){print $1;exit;}' /install/data/OMC_INSTALL* 2>/dev/null)
			[ -z "$omc_conf" ] || type="$type/$omc_conf"
		}
	}
	techno=""
	for t in GSM UMTS LTE FEMTO
	do
		egrep "CD4.$t"   /etc/MUSE.signature > /dev/null && {
			[ -z "$techno" ] || techno="$techno/"
			techno="${techno}$t" ;
		}
	done
	type="$type"
	if   [ -z "$type" ]; then
		type="$techno"
	elif [ ! -z "$techno" ]; then
		type="$type-$techno"
	fi
	version=$(perl -lne '$v=$1 if /(NPO\d+\S+).* on/;END{print $v}' /etc/MUSE.signature 2>/dev/null)
	case "$type" in
	    MAIN*)
		[ -s /alcatel/RRD/logs/npoinfo ] && \
			info=$(perl -lane 'push @aux,"$F[1] ($F[0])";END{print "AUX: ",join(", ",@aux) if scalar @aux>0}' /alcatel/RRD/logs/npoinfo 2>/dev/null)
		if [ -z "$version" -a -z "$info" ]; then
			type=""
		fi
		;;
	
	    AUX*)
	    	ip=""
		s=""
		[ -f /install/data/MUSE_INSTALL ] && \
			ip="$ip "$(perl -lne 'print $1 if/DB_IP_ADDR=(\S+)/' /install/data/MUSE_INSTALL)
		[ -f /install/data/WCT_INSTALL ] && \
			ip="$ip "$(perl -lne 'print $1 if/CONTROLLER_IP=(\S+)/' /install/data/WCT_INSTALL)
		[ -f /install/data/PCMD_INSTALL ] && \
			ip="$ip "$(perl -lne 'print $1 if/CONTROLLER_IP=(\S+)/' /install/data/PCMD_INSTALL)
		[ -f /install/data/MUSE_INSTALL ] && \
			ip="$ip "$(perl -lne 'print $1 if/^CORBA_IP_ADDRESS=(\S+)/' /install/data/MUSE_INSTALL)
		for i in $(echo $ip | xargs -n1 echo | sort -u)
		do
			[ "$i" = "127.0.0.1" ] && continue
			h=$(perl -lne 'print $1 if /^\s*'$i'\s+(\S+)/' /etc/hosts)
			[ -z "$h" ] && h=$i
			s="$s $h"
		done
		if [ -z "$s" ]; then
			type=""
		else
			info="MAIN:$s"
		fi
		;;
	esac
}

# KVM
#
service libvirtd status > /dev/null 2>&1 && {
	vm=$(virsh list --all | perl -lne '
		push @vm,"$1 ($2)" if /^\s*\d+\s+(\S+)\s+(\S+)/;
		END {print join(", ",@vm);}
	')
	[ -z "$vm" ] || {
		[ -z "$type" ] || type="$type - "
		type="${type}KVM"
		info="$info $(virsh version | perl -F: -lane 'if(/hypervisor/){($s=$F[1])=~s/^\s*//;print $s}'): $vm"
	}
}

printf "%-14s: %s\n" "Hostname" "$hostname"
printf "%-14s: %s\n" "Product"  "$product"
printf "%-14s: %s\n" "CPU"      "$cpu"
printf "%-14s: %s\n" "Memory"   "$mem"
[ -z "$disks" ]    || printf "%-14s: %s\n" "Disks"    "$disks"
printf "%-14s: %s\n" "Distrib"  "$distrib"
[ -z "$type" ]    || printf "%-14s: %s\n" "Type"    "$type"
[ -z "$version" ] || printf "%-14s: %s\n" "Version" "$version"
[ -z "$info" ]    || printf "%-14s: %s\n" "Info"    "$info"



}

function usage 
{

	echo "usage: ./$me  "
	echo "usage: ./$me  [ -a { OS | Oracle | guest | host } ] [ -b 8k-512k ] [ -c NPO_S ] [ -d 1 ] [ -e libaio ] [ -f randrw ] [ -i 1000 ] [ -j 16 ] [ -o 3000 ] [ -p {/alcatel/temp | /mnt/storage_pool1} ] [ -s 1G ] [ -t 60 ] [ -v vm_name ]"
	echo -e "Default parameters :"
	echo -e "action : ${action} "
	echo -e "fio block size range : ${bs_range}"
	echo -e "fio direct : ${direct}"
	echo -e "fio engine : ${engine}"
	echo -e "fio execution : ${fio_action}"
	echo -e "fio iodepth : ${io_depth}"  
	echo -e "fio number of jobs : ${nr_jobs} "
	echo -e "location on which to check IOPS :\n${fio_location}"
	echo -e "fio file size : ${size}"
	echo -e "fio execution time on each partition : ${run_time}"
    exit 1

}


function getHashKey
{
        declare -a hash=("${!1}")
        local key
        local lookup=$2

        for key in "${hash[@]}" ; do
                KEY=${key%%:*}
                VALUE=${key#*:}

                if [[ "$KEY" == "$lookup" ]]; then
                        echo $VALUE
                fi
        done
 }
 
 
 getHashKeys()
{
        declare -a hash=("${!1}")
        local KEY
        local VALUE
        local key
        local lookup=$2

        for key in "${hash[@]}" ; do
                KEY=${key%%:*}
                VALUE=${key#*:}
                keys+="${KEY} "
        done

        echo $keys
}

function install_required_rpm
{

echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` Checking if the rpms needed to run IO tool are installed ..."

new_fio=`rpm -qap $workDir/fio* --qf "%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}\n" --nosignature`
installed_fio=`rpm -qa |grep fio`
install_list=`ls $workDir | grep -i rpm |sort -r`
blacklist="libibverbs1 fio"

if [ ! $installed_fio ];
then
for b in $blacklist
do
      rpm -qi $b >/dev/null
      if [ $? -eq 0 ]; then
        rpm -e $b --nodeps
      fi
done
	for c in $install_list
	do
     rpm -ivh $c --nosignature
     if [ $? -ne 0 ]; then
        echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` ERROR: Failed to install rpm $c"
        exit 1
     fi
done
else
echo -e "$installed_fio\n$new_fio"|sort -VCu
   if [ $? -eq 0 ];
   then
       echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` WARNING:The installed verision of fio on your server $installed_fio is older  than the required version $new_fio for the IO tool to run properly "
       for b in $blacklist
       do
           rpm -qi $b >/dev/null
           if [ $? -eq 0 ]; then
              rpm -e $b --nodeps
           fi
       done
       for c in $install_list
       do
         rpm -ivh $c --nosignature
         if [ $? -ne 0 ]; then
            echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` ERROR: Failed to install rpm $c"
            exit 1
         fi
       done
   fi
fi

}

function basic_script_checks 
{

	script_execution=`ps -eaf | grep "check_IOPS.sh"| grep -v "vi" | grep -v "tail"|grep -v "grep" | grep -v "tee"|wc -l`
	if [ ${script_execution} != 3 ]
	then
		echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`  Another instance of $me is running. Installation already in progress... Exiting"
		exit 1
	fi

	[ "$(id | awk -F\( '{print $2}' | awk -F\) '{print $1}')" = root ] || {
		echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` ERROR: You must be logged in as ROOT to run $me!!!" >&2
		echo "       Log in as ROOT and restart $me execution." >&2
		exit 1
	}

}

function check_fio
{

	install_required_rpm
	
	if [ ${nr_jobs} -eq 0 ]
	then
		if [ ${action} == "host" ]
		then
			nr_jobs=$(getHashKey MIN_CPU[@] "${iops_conf}")
		else
			nr_jobs=`cat /proc/cpuinfo | grep processor | wc -l`
		fi
	fi
	
	i=1
	
	if [ x${fio_location} == "x" ]
	then
		if [ ${action} == "host" ]
		then
			virsh dumpxml ${vm_name} > ${iops_conf}.xml
			fio_location=`sed -n '/\<disk/,/<\/disk\>/p' ${iops_conf}.xml | grep "source file" | awk -F "'" '{print $2}' | sed 's/\(.*\)\/.*.img/\1/'`
		else
			fio_location=`cat /etc/fstab|grep UUID|awk '{print $2}'|egrep -v "Filesystem|shm|boot|var|swap"`
		fi
	else
		if [ ${action} == "host" ]
		then
			if [ x${vld} == "x" ]
			then	
				echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`ERROR the virtual disk number was not provided for location ${fio_location}. Please add the -d argument to the script."
				exit 1
			else
				i=$vld
			fi
		fi
	fi	
	
	temp_dir="fio_test_dir"
	nr_part=`echo ${fio_location} | awk --field-separator=" " "{ print NF }"`	
	fio_time=$(( nr_part * run_time / 60 ))
	exec_time=$(( fio_time + nr_part ))	
	
	echo -e "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` Start IOPS check. It will take about ${exec_time} minutes to complete. Please wait"

	for f in ${fio_location}
	do
	
		if [ ${def_iops} -ne 0 ]
		then 
			iops_to_check=${def_iops}
		else
			if [ ${action} == "host" ]
			then
				iops_to_check=$(getHashKey ${iops_conf}[@] "VLD${i}")
			else
				iops_to_check=$(getHashKey ${iops_conf}[@] "${f}")
			fi
		fi
			
		if [ x${iops_to_check} == "x" ]
        then
                echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` ERROR: maximum file system IOPS can not be determined. Please execute ${me} and add -i option to provide the maximum IOPS to be checked"
                exit 1
        fi
		
		if [[ "$size" =~ "G" ]]
		then
			size_value=`echo ${size} | sed s'/G//g'`
			needed_free_space=$(( nr_jobs * size_value * 1024 * 1024 ))
		elif [[ "$size" =~ "M" ]]
		then
			size_value=`echo ${size} | sed s'/M//g'`
			needed_free_space=$(( nr_jobs * size_value * 1024 ))
		elif [[ $size = +([0-9]) ]]
		then	
			needed_free_space=$(( nr_jobs  * size ))
		else
			echo "ERROR can not determine the fio file size"
			exit 1
		fi
		
		###check free space
		free_space=`df -P ${f} | egrep -v "Filesystem" | awk '{print $4}'`
		if [ ${free_space} -lt ${needed_free_space} ]
		then
			echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` WARNING : Free space on ${f} is lower then required ${needed_free_space}"
		else	
			if [ ${action} == "host" ]
			then
				str=" VLD ${i} on"
			else
				str=""
			fi
			
			echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` Checking IOPS for${str} ${f} "
			mkdir -p ${f}/${temp_dir}
			(cd ${f}/${temp_dir};fio --name=${f}/${temp_dir}/randreadwrite --ioengine=${engine} --iodepth=${io_depth} --rw=${fio_action} --bsrange=${bs_range} --direct=${direct} --size=${size} --numjobs=${nr_jobs} --runtime=${run_time} --group_reporting --time_based > ${f}/${temp_dir}/fio_output)	
			read_iops=`cat ${f}/${temp_dir}/fio_output | egrep "read : " | awk '{print $5}' | awk -F"=" '{print $2}'|sed 's/,//'`
			write_iops=`cat ${f}/${temp_dir}/fio_output | egrep " write: " | awk '{print $4}' | awk -F"=" '{print $2}'|sed 's/,//'`
			total_iops=$(( read_iops + write_iops ))
			echo -e "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` result: IOPS : ${total_iops}   ; read=${read_iops}  write=${write_iops} "
			if [ ${total_iops} -lt ${iops_to_check} ]
			then
				echo -e "\e[31m`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` WARNING: Total IOPS : ${total_iops}  calculated for${str} ${f} is lower then ${iops_to_check} \e[0m"
			else
				echo -e "\e[32m`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` IOPS check passed for${str} ${f}  Total IOPS : ${total_iops} > ${iops_to_check} \e[0m"
			fi
			rm -Rf ${f}/${temp_dir}
		
		fi
		let i++
	done
}


function detect_server_type
{

if [ ${action} == "guest" ] || [ ${action} == "OS" ] || [ ${action} == "Oracle" ]
then	
	actual_cpu=`cat /proc/cpuinfo | grep processor | wc -l`
	actual_ram=`free -m |grep Mem|awk '{print$2}'`
	server_type=`cat /etc/MUSE.signature |grep TYPE | awk '{print $2}'`
	cpu_list=$(getHashKeys MAX_CPU[@])
	for i in $cpu_list
	do
		echo $i | grep ${server_type} > /dev/null
		result=$?
		if [ ${result} -eq 0 ]
		then
	
			potential_max_cpu=$(getHashKey MAX_CPU[@] "${i}")
			cpu_conf=${i}
			if [ ${potential_max_cpu} -gt ${actual_cpu} ]
			then
				break
			fi
		fi
	done

	ram_list=$(getHashKeys MAX_RAM[@])
	for i in $ram_list
	do
        echo $i | grep ${server_type} > /dev/null
        result=$?
        if [ ${result} -eq 0 ]
        then

                potential_max_ram=$(getHashKey MAX_RAM[@] "${i}")
                ram_conf=${i}
                if [ ${potential_max_ram} -gt ${actual_ram} ]
                then
                        break
                fi
        fi
	done

	if [ ${cpu_conf} == ${ram_conf} ]
	then
		echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` Server TYPE detected is ${cpu_conf} "
		iops_conf=${cpu_conf}
	else
		echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'`ERROR : Can not determine server type based on CPU and RAM"
		exit 1
	fi
elif [ ${action} == "host" ]
then
	if [ x${vm_name} == "x" ]
	then
		echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` ERROR: The virtual machine name was not provided. Please execute ${me} and add -v option to provide the name of the virtual machine"
		exit 1
	fi
	if [ x${iops_conf} == "x" ]
	then
		echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` ERROR: The virtual machine configuration type was not provided. Please execute ${me} and add -c option to provide the type of the virtual machine"
		exit 1
	fi
	echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` Checking host IOPS for ${vm_name} virtual machine. The IOPS should be according to a ${iops_conf} configuration "
else
	echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` ERROR : Can not determine server type."
	exit 1
fi

}


function initialize 
{
	nr_jobs=0
	run_time=60
	action=OS
	fio_location=""
	engine=libaio
	io_depth=1
	bs_range=8k-512k
	direct=0
	size=1G
	fio_action=randrw
	def_iops=0
	while getopts :a:b:c:d:e:f:i:j:o:p:s:t:v: opt
	do
	        case $opt in
			a)  action=$OPTARG;;
			b)  bs_range=$OPTARG;;
			c)  iops_conf=$OPTARG;;
			d)  vld=$OPTARG;;
			e)  engine=$OPTARG;;
			f)  fio_action=$OPTARG;;
			i)  def_iops=$OPTARG;;
			j)  nr_jobs=$OPTARG;;
			o)  oracle_iops=$OPTARG;;
			p)  fio_location=$OPTARG;;
			s)  size=$OPTARG;;
			t)  run_time=$OPTARG;;
			v)  vm_name=$OPTARG;;
			*)  usage;;
		esac
	done
	shift $(($OPTIND-1))

}


#####MAIN 

. ${scr_location}/CONFIG.SPEC
initialize "$@"
detect_server_type
basic_script_checks
hostInfo

if [ ${action} == "Oracle" ]
then
	checkOracle
elif [ ${action} == "OS" ]
then
	check_fio
elif [ ${action} == "guest" ]
then
	check_fio
	checkOracle
elif [ ${action} == "host" ]
then
	check_fio
else
	echo "`date '+DATE: %m/%d/%g TIME: %H:%M:%S'` ERROR : Can not determine what kind of IOPS you want to check "
	exit 1
fi
} 2>&1 | tee -a ${logfile}

