#!/bin/bash
#set -x
#####################################################
## Backup unix users profile
#####################################################

OMC_HOME="/alcatel/MS"
server_file="/var/tmp/server.profile"
LOG_FILE=${OMC_HOME}/data/traces/backup_aux_user.log_`date '+%Y-%m-%d_%H-%M-%S'`

#####get main server IP address
get_main_server_IP()
{
         main_param=`grep $key_word $server_file`
         get_main_ip=`echo $main_param |cut -d'=' -f2`
         main_ip=`echo $get_main_ip`
         return 0
}

##### main()
##check OS and server type
os=$(uname -s)
sun=false
linux=false
case "$os" in
    SunOS)      sun=true        ;;
    Linux)      linux=true      ;;
esac
type=$(perl -lne 'print $1 if /^\s*TYPE\s+(\S+)/' /etc/MUSE.signature)
[ -z "$type" ] && {
        echo "ERROR: can't determine which type is (NPO/AUX/...)" >&2 | tee -a ${LOG_FILE}
        exit 1
}
echo "SERVER_TYPE is: $type" | tee -a ${LOG_FILE}

if [ "$type" != "AUX_PCMD" ] && [ "$type" != "AUX_GL2" ] && [ "$type" != "AUX_WCT" ] && [ "$type" != "AUX_SON" ];
then
   echo "The script run only on AUX servers!" | tee -a ${LOG_FILE}
   exit 1
fi

## Get main server IP
if [ ! -f ${server_file} ]
then
   echo "File ${server_file} does not exist! Try to find other configuration file" | tee -a ${LOG_FILE}
   case "$type" in
      AUX_PCMD)
         echo "PCMD server"
         server_file="/install/data/PCMD_INSTALL"
         key_word="^CONTROLLER_IP"
         get_main_server_IP
         echo "Found $type MAIN server IP is $main_ip" | tee -a ${LOG_FILE}
         ;;
      AUX_WCT)
         echo "WCT server"
         server_file="/install/data/WCT_INSTALL"
         key_word="^CONTROLLER_IP"
         get_main_server_IP
         echo "Found $type MAIN server IP is $main_ip" | tee -a ${LOG_FILE}
         ;;
      *)
         server_file="/install/data/MUSE_INSTALL"
         key_word="^CORBA_IP_ADDRESS"
         get_main_server_IP
         echo "Found $type MAIN server IP is $main_ip" | tee -a ${LOG_FILE}
   esac
else
  main_line=`grep '^CONTROLLER_IP' ${server_file} |wc -l`
  if [ $main_line -eq 0 ]
    then
    echo "=== Can't get MAIN server IP from ${server_file} file" | tee -a ${LOG_FILE}
    exit 1
  fi
  echo "Get MAIN IP from ${server_file}" | tee -a ${LOG_FILE}
  main_param=`grep '^CONTROLLER_IP' ${server_file}`
  para_len=`echo $main_param|awk '{print length($0)}'`
  get_main_ip=`echo $main_param |cut -c 14-29`
  main_ip=`echo $get_main_ip`
  echo "MAIN server ip is: $main_ip" | tee -a ${LOG_FILE}
fi

if [ "${main_ip}" = "" ]
then
   echo "Can't find main server IP!!" | tee -a ${LOG_FILE}
   exit
fi

## backup 
export UGIDLIMIT=2502
home=/alcatel/var/home
user=axadmin
dotssh=${home}/${user}
savdir=${dotssh}/sav-aux-users-$(hostname)

/bin/rm -ifr ${savdir} && mkdir ${savdir}
/bin/rm -irf ${savdir}.zip
awk -v LIMIT=$UGIDLIMIT -F: '($3>=LIMIT) && ($3!=65534)' /etc/passwd > ${savdir}/passwd_$(hostname)
awk -v LIMIT=$UGIDLIMIT -F: '($3>=LIMIT) && ($3!=65534)' /etc/group > ${savdir}/group_$(hostname)
grep -v 'bin\:\|daemon\:\|adm\:\|lp\:\|sync\:\|shutdown\:\|halt\:\|mail\:\|news\:\|uucp\:\|operator\:\|games\:\|gopher\:\|ftp\:\|nobody\:\|nscd\:\|vcsa\:\|ntp\:\|pcap\:\|dbus\:\|avahi\:\|rpc\:\|mailnull\:\|smmsp\:\|sshd\:\|rpcuser\:\|nfsnobody\:\|xfs\:\|haldaemon\:\|avahi-autoipd\:\|gdm\:\|sabayon\:\|oracle\:\|ftplog' /etc/shadow > ${savdir}/shadow_$(hostname)

main_hostname=`su - axadmin -c "ssh -q -l axadmin $main_ip 'hostname'"`
echo "MAIN hostname is: $main_hostname" | tee -a ${LOG_FILE}
grep -v "${user}@${main_hostname}" ${dotssh}/.ssh/authorized_keys > ${savdir}/authorized_keys_$(hostname)

echo "Creating archive file ..." | tee -a ${LOG_FILE}
tar --exclude '.sh_history' --exclude '.mozilla' --exclude 'Desktop' --exclude 'sav-aux-users*' --exclude 'oracle' --exclude '*.iso.*' -zcvpf ${savdir}/home_$(hostname).tar.gz ${home} | tee -a ${LOG_FILE}

cp /etc/sysconfig/network-scripts/route-eth* ${savdir}/ >/dev/null 2>&1

zip -j ${savdir}.zip ${savdir}/* | tee -a ${LOG_FILE}
chmod u+r ${savdir}.zip
/bin/rm -fr ${savdir}

echo "User directory is: ${dotssh}" | tee -a ${LOG_FILE}
ls -l ${dotssh}/sav-aux-users-$(hostname).zip

echo "Saving backup file to MAIN server, in /alcatel/backup/backup_AUX directory" | tee -a ${LOG_FILE}
su - axadmin -c "scp -p ${dotssh}/sav-aux-users* ${user}@$main_ip:/alcatel/backup/backup_AUX" | tee -a ${LOG_FILE}

