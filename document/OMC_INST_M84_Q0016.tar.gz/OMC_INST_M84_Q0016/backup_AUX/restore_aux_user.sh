#!/bin/bash
#set -x

OMC_HOME="/alcatel/MS"
server_profile="/var/tmp/server.profile"
LOG_FILE=${OMC_HOME}/data/traces/restore_aux_user.log_`date '+%Y-%m-%d_%H-%M-%S'`

##check OS and server type
os=$(uname -s)
sun=false
linux=false
case "$os" in
    SunOS)      sun=true        ;;
    Linux)      linux=true      ;;
esac
type=$(perl -lne 'print $1 if /^\s*TYPE\s+(\S+)/' /etc/MUSE.signature)
[ -z "$type" ] && {
        echo "ERROR: can't determine which type is (NPO/AUX/...)" >&2 | tee -a ${LOG_FILE}
        exit 1
}
echo "SERVER_TYPE is: $type" | tee -a ${LOG_FILE}


if [ "$type" != "AUX_PCMD" ] && [ "$type" != "AUX_GL2" ] && [ "$type" != "AUX_WCT" ] && [ "$type" != "AUX_SON" ];
then
   echo "This script run only on AUX servers" | tee -a ${LOG_FILE}
   exit 1
fi


## Get main server IP
if [ ! -f ${server_profile} ]
then
   echo "File ${server_profile} does not exist!" | tee -a ${LOG_FILE}
   echo "${server_profile} file must be generated again!" | tee -a ${LOG_FILE}
   exit 1
fi

## Get main server IP
main_line=`grep '^CONTROLLER_IP' $server_profile |wc -l`
if [ $main_line -eq 0 ]
then
   echo "=== Can't get main server IP from $server_profile file! Exiting..." | tee -a ${LOG_FILE}
   exit 1
fi

main_param=`grep '^CONTROLLER_IP' $server_profile`
para_len=`echo $main_param|awk '{print length($0)}'`
get_main_ip=`echo $main_param |cut -c 14-29`
main_ip=`echo $get_main_ip`
echo "MAIN server ip is: $main_ip" | tee -a ${LOG_FILE}


## Check if there is a same file at ~axadmin locally
file_name="sav-aux-users-$(hostname).zip"
home=/alcatel/var/home
user=axadmin

test -f ${home}/${user}/$file_name
if [ $? -ne 1 ];
then
   echo " -- There is a $file_name file locally. It will be moved to other file name."  | tee -a ${LOG_FILE}
   mv ${home}/${user}/$file_name ${home}/${user}/bk_$file_name.bk_`date +%Y-%m-%d` | tee -a ${LOG_FILE}
fi


## Get file from main server
echo "Copy backup file from MAIN server" | tee -a ${LOG_FILE}
scp -p -o StrictHostKeychecking=no axadmin@$main_ip:/alcatel/backup/backup_AUX/$file_name ~axadmin/ | tee -a ${LOG_FILE}

test -f ${home}/${user}/$file_name
if [ $? -eq 1 ];
then
   echo "--- Can't get $file_name from main server!!!! ---" | tee -a ${LOG_FILE}
   exit
fi

chmod a-rwx ${home}/${user}/$file_name

## Back up original user password files
test -d ${home}/${user}/bkp_aux_user
if [ $? -eq 1 ];
then
   mkdir ${home}/${user}/bkp_aux_user
fi

cp -p /etc/passwd /etc/group /etc/shadow ${home}/${user}/bkp_aux_user
cp -rf ${home}/${user}/.ssh ${home}/${user}/bkp_aux_user

## Restore user password
(cd ${home}/${user}; unzip $file_name)
mv ${home}/${user}/route-eth* /etc/sysconfig/network-scripts/ >/dev/null 2>&1
cat ${home}/${user}/passwd_$(hostname) >> /etc/passwd
cat ${home}/${user}/group_$(hostname) >> /etc/group
sed -i "/^root:/d" /etc/shadow
sed -i "/^$user:/d" /etc/shadow
cat ${home}/${user}/shadow_$(hostname) >> /etc/shadow
cd /
tar -zxvf ${home}/${user}/home_$(hostname).tar.gz | tee -a ${LOG_FILE}
cp ${home}/${user}/authorized_keys_$(hostname) ${home}/${user}/.ssh/authorized_keys
rm -f ${home}/${user}/passwd_* ${home}/${user}/group_* ${home}/${user}/shadow_* ${home}/${user}/authorized_keys_* ${home}/${user}/home_*

