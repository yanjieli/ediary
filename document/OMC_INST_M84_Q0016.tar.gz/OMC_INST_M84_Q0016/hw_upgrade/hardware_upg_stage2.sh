#!/bin/sh
#Hardware upgrade script stage 2

#set -x

CUR_DIR=`pwd`
export OMC_UNIX_INSTALL_DIR="$CUR_DIR/../unix"
install_file=$OMC_UNIX_INSTALL_DIR/lib/install.sh
if [ ! -f $install_file ]; then
                echo "[`date '+%d-%m-%y %H:%M:%S'`] ERROR: $install_file file not found" >&2
                exit 1
        fi
. $install_file

LOGFILE=__LOGFILE__
export LOGFILE
. /tmp/omc_conf_modified
echo "Run Hardware upgrade script stage 2 at  `date` " | tee -a $LOGFILE

if [ -f /install/data/OMC_INSTALL ]; then
	ln -s /install/data/OMC_INSTALL /tmp/OMC_INSTALL
	. /tmp/OMC_INSTALL
fi

ORACLE_HOME=${DB_HOME}
export ORACLE_HOME

while true
do
        mon=`ps -ef | grep ora_pmon | grep -v grep | wc -l | awk '{print $1}'`
        if [ $mon -ne 0 ]; then
           break
        fi
        sleep 1
done

echo "Stopping PMON" | tee -a $LOGFILE
${OMC_HOME}/MS_PMON/scripts/pmon.sh stop


if [ -f /install/data/tuning_server.pm ]; then
	. /install/data/tuning_server.pm
fi

echo "Update MUSE_INSTALL file" | tee -a $LOGFILE
wfile=/install/data/MUSE_INSTALL
sed -e "s#PARALLEL_DEGREE=.*#PARALLEL_DEGREE=${PARALLEL_DEGREE}#g" \
    -e "s#REC_CONSO_DEGREE=.*#REC_CONSO_DEGREE=${REC_CONSO_DEGREE}#g" \
	-e "s#NORM_CONSO_DEGREE=.*#NORM_CONSO_DEGREE=${NORM_CONSO_DEGREE}#g" \
$wfile > $wfile.$$
mv $wfile.$$ $wfile
ln -s $wfile /tmp/MUSE_INSTALL

sleep 5

echo "Run configure_tuning_pm.sh script" | tee -a $LOGFILE
su - oracle -c "/alcatel/MS/OMC_DBCF/dba_scripts/configure_tuning_pm.sh" || {
	echo "\n ERROR: Can't configure oracle tuning"
}

echo "Restart Oracle Database" | tee -a $LOGFILE
if [ $ASM -eq 0 ]; then
	su - oracle -c $ORACLE_HOME/bin/dbshut | tee -a $LOGFILE
	sleep 10
	su - oracle -c $ORACLE_HOME/bin/dbstart | tee -a $LOGFILE
else
	oracle_stop | tee -a $LOGFILE
	su - oracle -c "
        $DB_HOME/bin/srvctl start db -d $DB_NAME > /dev/null 2>&1
        "
fi
sleep 200

echo "Starting PMON" | tee -a $LOGFILE
${OMC_HOME}/MS_PMON/scripts/pmon.sh start

sleep 15


if [ $OMC_CONF_modified -eq 0 ];then
	echo "Updating PARALLEL_DEGREE, REC_CONSO_DEGREE, NORM_CONSO_DEGREE..." | tee -a $LOGFILE
	file_to_modify=/alcatel/muse/MUSE_MAAT/dataaccess/rsc/com/alcatel/muse/maat/dataaccess/DataAccessResourceFile.cfg
	sed -e "s#PARALLEL_DEGREE=.*#PARALLEL_DEGREE=${PARALLEL_DEGREE}#g" \
		-e "s#NORM_CONSO_DEGREE=.*#NORM_CONSO_DEGREE=${NORM_CONSO_DEGREE}#g" \
	$file_to_modify > $file_to_modify.$$
	mv $file_to_modify.$$ $file_to_modify

	file_to_modify=/alcatel/muse/MUSE_QOS/config/Consolidation.properties
	sed -e "s#PARALLELDEGREE=.*#PARALLELDEGREE=${PARALLEL_DEGREE}#g" \
		-e "s#REC_CONSO_DEGREE=.*#REC_CONSO_DEGREE=${REC_CONSO_DEGREE}#g" \
		-e "s#NORM_CONSO_DEGREE=.*#NORM_CONSO_DEGREE=${NORM_CONSO_DEGREE}#g" \
	$file_to_modify > $file_to_modify.$$
	mv $file_to_modify.$$ $file_to_modify
fi

cmd=`grep CD4 /etc/MUSE.signature | grep LTE`
if [ $? -eq 0 ] && [ $OMC_CONF_modified -eq 0 ];then
	echo "OMC_CONF modified; Running /alcatel/muse/technologies/LTE/scripts/runprepare.sh and /alcatel/muse/technologies/LTE/scripts/runmerge.sh " | tee -a $LOGFILE
	if [ -f /alcatel/muse/technologies/LTE/scripts/runprepare.sh ] && [ -f /alcatel/muse/technologies/LTE/scripts/runmerge.sh ]; then
		/alcatel/muse/technologies/LTE/scripts/runprepare.sh
		ret1=$?
		/alcatel/muse/technologies/LTE/scripts/runmerge.sh
		ret2=$?
		if [ $ret1 -ne 0 ] || [ $ret2 -ne 0 ];then
			echo "ERROR: runprepare.sh or  runmerge.sh FAILED!!! " | tee -a $LOGFILE
		fi
	else
		echo "ERROR: runprepare.sh and runmerge.sh not found !!!" | tee -a $LOGFILE
	fi
fi
rm -f /tmp/omc_conf_modified

tune_location=/alcatel/muse/tune_server
cmd=`grep tune /etc/MUSE.signature`
if [ $? -eq 0 ]; then
	NPO_ver=`sed -e 's/[ ]*-=(//' -e 's/)=-//'  /etc/MUSE.signature | grep tune | tail -1 | awk -F" " '{print $1}'`
	tune_ver=`sed -e 's/[ ]*-=(//' -e 's/)=-//'  /etc/MUSE.signature | grep tune | tail -1 | awk -F" " '{print $2}'`
	tune_dir=${NPO_ver}_${tune_ver}

	cmd2=`ls  ${tune_location}/${tune_dir} | grep tune | grep tar | grep gz | wc -l`
	if [ $cmd2 -eq 1 ]; then
		arch=`ls  ${tune_location}/${tune_dir} | grep tune | grep tar | grep gz `
		tar zxfv  ${tune_location}/${tune_dir}/$arch -C /${tune_location}/${tune_dir}
		tune_server=`find  ${tune_location}/${tune_dir}/ -name tune_server`
		if [ $tune_server != "" ];then
			echo "$tune_server found. Running it..." | tee -a $LOGFILE
			chmod 766 $tune_server
			$tune_server
			if [ $? -ne 0 ]; then
				"ERROR: $tune_server failed!!!" | tee -a $LOGFILE
				exit 1
			fi
		else
			echo "ERROR:tune_server  script not found!!!"| tee -a $LOGFILE
			exit 1
		fi
	elif [ $cmd2 -eq 0 ];then
		echo "ERROR: $tune_dir archive not found!!!" | tee -a $LOGFILE
		exit 1
	else
		echo "ERROR: more than one tune_server archives found!!!" | tee -a $LOGFILE
		exit 1
	fi
	
else
	echo "Warning: No tune_server version found in /etc/MUSE.signature" | tee -a $LOGFILE
fi


if [ -f /alcatel/MS/OMC_DBCF/scripts/os_stability.sh  ]; then
	echo "Executing /alcatel/MS/OMC_DBCF/scripts/os_stability.sh ..." | tee -a $LOGFILE
	/alcatel/MS/OMC_DBCF/scripts/os_stability.sh
	if [ $? -ne 0 ]; then
		"ERROR: /alcatel/MS/OMC_DBCF/scripts/os_stability.sh failed !" | tee -a $LOGFILE
	fi
else
	echo "ERROR: /alcatel/MS/OMC_DBCF/scripts/os_stability.sh doesn't exist!" | tee -a $LOGFILE	
fi
echo "Finish Hardware Upgrade script at `date` " | tee -a $LOGFILE

