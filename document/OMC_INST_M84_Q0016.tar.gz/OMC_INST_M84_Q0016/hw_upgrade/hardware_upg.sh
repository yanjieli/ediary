#!/bin/ksh

#Hardware upgrade script

#set -x
date_log=`date '+%Y-%m-%d_%H:%M:%S'`
mkdir -p /alcatel/install/log
export LOGFILE=/alcatel/install/log/HW_upgrade.log_$date_log
touch $LOGFILE
. /install/data/OMC_INSTALL
old_OMC_CONF=$OMC_CONF
if [ `uname` = "Linux" ]; then
        OS_TYPE="Linux"
else
        echo "Unsupported OS detected" | tee -a $LOGFILE
	exit 1
fi

echo "Run Hardware upgrade script `date` " | tee -a $LOGFILE
TYPE=`cat /etc/MUSE.signature | grep -i type | awk '{print $2}'`
RAM_SIZE_KB=`free | grep -i "Mem:" | awk '{print $2}'`
RAM_SIZE=`expr $RAM_SIZE_KB \* 1024`
nb_of_cpu=`cat /proc/cpuinfo | grep "^processor" | wc -l`
memsize=`free -g | grep Mem | awk -F" "  '{print $2}'`
product=`dmidecode | grep Product | egrep -i "kvm|openstack" | wc -l`;


echo "Setting shmmax param in /etc/sysctl.conf" | tee -a $LOGFILE

shmmax=`expr \( $RAM_SIZE / 100 \) \* 75`

echo "Setting shmall param in /etc/sysctl.conf" | tee -a $LOGFILE
shmall=`expr $shmmax / 4096`

SYSCTL_FILE_ORIG=/etc/sysctl.conf
SYSCTL_FILE_TMP=/etc/sysctl.conf.tmp

cmd=`grep shmall $SYSCTL_FILE_ORIG`
if [ $? -eq 0 ]; then
	sed -e "s/^kernel.shmall.*/kernel.shmall = $shmall/" -e "s/^kernel.shmmax.*/kernel.shmmax = $shmmax/" $SYSCTL_FILE_ORIG > $SYSCTL_FILE_TMP
	mv $SYSCTL_FILE_TMP $SYSCTL_FILE_ORIG
else
	echo "kernel.shmall = $shmall" >> $SYSCTL_FILE_ORIG
	echo "kernel.shmmax = $shmmax" >> $SYSCTL_FILE_ORIG
fi

echo "Propagating the new parameters to the kernel" | tee -a $LOGFILE
sysctl -p | tee -a $LOGFILE

if [[ $product -eq 1 ]]; then
	#KVM or OpenStack environment 
	echo "Identified environment: `dmidecode | grep Product | egrep -i \"kvm|openstack\" | awk '{print $3 }'`" | tee -a $LOGFILE
	if [[ $TYPE = "NPO" ]]; then
		echo "Identified type: $TYPE" | tee -a $LOGFILE
		if [[ $nb_of_cpu -ge 64 && $memsize -ge 230 ]]; then
			OMC_CONF="XLARGE"
		elif [[ $nb_of_cpu -ge 32 && $memsize -ge 115 ]]; then
			OMC_CONF="MEDIUM"
		elif [[ $nb_of_cpu -ge 16 && $memsize -ge 28 ]]; then
			OMC_CONF="SMALL"
		elif [[ $nb_of_cpu -ge 8 && $memsize -ge 14 ]]; then
			OMC_CONF="MINI"
		else
			OMC_CONF="MINI"
        		echo "ERROR! Number of CPU or RAM is below allowed threshold." | tee -a $LOGFILE
		fi
	elif [[ $TYPE = "AUX_GL2" ]]; then
		if [[ $nb_of_cpu -ge 64 && $memsize -ge 115 ]]; then
			OMC_CONF="SMALL"
		elif [[ $nb_of_cpu -ge 8 && $memsize -ge 14 ]]; then
			OMC_CONF="MINI"
		else
			OMC_CONF="MINI"
                        echo "ERROR! Number of CPU or RAM is below allowed threshold." | tee -a $LOGFILE
		fi
	elif [[ $TYPE = "AUX_PCMD" ]]; then
		if [[ $nb_of_cpu -ge 32 && $memsize -ge 115 ]]; then
			OMC_CONF="SMALL"
		elif [[ $nb_of_cpu -ge 8 && $memsize -ge 14 ]]; then
			OMC_CONF="MINI"
		else
			OMC_CONF="MINI"
                        echo "ERROR! Number of CPU or RAM is below allowed threshold." | tee -a $LOGFILE
		fi
	fi
echo " Old OMC_CONF: $old_OMC_CONF " | tee -a $LOGFILE
echo " New OMC_CONF: $OMC_CONF " | tee -a $LOGFILE
wfile="/install/data/OMC_INSTALL"
sed -e "s#OMC_CONF=.*#OMC_CONF=${OMC_CONF}#g" < $wfile > $wfile.$$
mv $wfile.$$ $wfile
fi

if [ $old_OMC_CONF = $OMC_CONF ]; then
	echo "OMC_CONF_modified=1" > /tmp/omc_conf_modified
else
	echo "OMC_CONF_modified=0" > /tmp/omc_conf_modified
fi

if [ $TYPE = "NPO" ] ; then
	echo "Save old tuning_server.pm file" | tee -a $LOGFILE
	mv /install/data/tuning_server.pm /install/data/BEFOREUPG.tuning_server.pm

	echo "Run printSettings.pl script" | tee -a $LOGFILE
	/alcatel/MS/INDSxp/XMLParser/printSettings.pl | tee -a $LOGFILE

	STAGE2=hardware_upg_stage2.sh
	STAGE2_TMP=hardware_upg_stage2.sh.tmp
	sed -e "s#LOGFILE=.*#LOGFILE=${LOGFILE}#g" $STAGE2 > $STAGE2_TMP 
	mv $STAGE2_TMP $STAGE2
	chmod +x $STAGE2

	echo "Running part 2 of the configuration" | tee -a $LOGFILE

	./$STAGE2

else
	echo "Finish Hardware Upgrade script for AUX `date` "  | tee -a $LOGFILE	
fi
